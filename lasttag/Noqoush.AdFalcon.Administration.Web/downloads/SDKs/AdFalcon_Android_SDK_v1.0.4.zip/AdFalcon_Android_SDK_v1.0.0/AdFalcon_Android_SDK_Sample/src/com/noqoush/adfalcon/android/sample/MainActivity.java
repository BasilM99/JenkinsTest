package com.noqoush.adfalcon.android.sample;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.noqoush.adfalcon.android.sdk.ADFListener;
import com.noqoush.adfalcon.android.sdk.ADFTargetingParams;
import com.noqoush.adfalcon.android.sdk.ADFView;
import com.noqoush.adfalcon.android.sdk.constant.ADFAdSize;
import com.noqoush.adfalcon.android.sdk.constant.ADFErrorCode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainActivity extends Activity implements ADFListener {

    ADFView adFalconView;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.main);

            //create new instance of ADFView
            adFalconView = new ADFView(this);

            //create reference to singleton  ADFTargetingParams class. all params are optional
            //ADFTargetingParams params = new ADFTargetingParams();

            //Add age or birthdate
            //params.setAge(27);
            //params.setBirthdate(new SimpleDateFormat("dd.MM.yyyy").parse("21.11.1984"));

            //params.setGender(ADFTargetingParams.GENDER_MALE);
            //params.setLanguage("en");

            //params.setAreaCode("962");
            //params.setPostalCode("11121");
            //params.setCountryCode("JO");

            //if you set location permission, the SDK will get location info automatically.
            //in case you want to pass location info manually, use the following methods
            //params.setLocationLatitude(31.956641);
            //params.setLocationLongitude(35.847037);

            //Add keywords of ad
            //Vector<String> keywords = new Vector<String>();
            //keywords.add("Sport");
            //params.setKeywords(keywords);
            
            //Set test mode when your application is under developement
            adFalconView.setTestMode(true);

            //initialize the view by pass publisher id, ad unit size, params, listener and enable auto refresh.
            //then load first ad
            adFalconView.initialize("xxxxxxxxxxxxxxxxxxxxx", ADFAdSize.AD_UNIT_320x48, /*params*/null, this, true);

            ((LinearLayout) findViewById(R.id.linearLayout)).addView(adFalconView);
        
            
        } catch (Exception ex) {
            
        }

    }

    private void tracingLog(String log) {
        TextView textView = (TextView) findViewById(R.id.tracing);
        textView.setText(new SimpleDateFormat("hh:mm:ss").format(new Date()) + ":" + log + "\n" + textView.getText());
    }

    public void willLoadAd(ADFView view) {
        tracingLog("willLoadAd");
    }

    public void didLoadAd(ADFView view) {
        tracingLog("didLoadAd");
    }

    public void onError(ADFView view, ADFErrorCode error, String message) {
        tracingLog("Error:" + error.name() + "\nmessage:" + message);
    }

    public void willPresentAdScreen(ADFView view) {
        tracingLog("willPresentAdScreen");
    }

    public void didPresentAdScreen(ADFView view) {
        tracingLog("didPresentAdScreen");
    }

    public void willDismissAdScreen(ADFView view) {
        tracingLog("willDismissAdScreen");
    }

    public void didDismissAdScreen(ADFView view) {
        tracingLog("didDismissAdScreen");
    }

    public void applicationWillEnterBackground() {
        tracingLog("applicationWillEnterBackground");
    }

	
}
