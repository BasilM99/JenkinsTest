//
//  AdFalcon_iOS_SDK_iPhone_SampleViewController.h
//  AdFalcon_iOS_SDK_iPhone_Sample
//
//  Created by Emad Ziyad on 8/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ADFAdViewDelegate.h"
#import "ADFAdView.h"
#import "ADFUserInfo.h"
#import "ADFTargetingParams.h"

@interface AdFalcon_iOS_SDK_iPhone_SampleViewController : UIViewController<ADFAdViewDelegate> {
    ADFAdView * adView;
    IBOutlet UITextView * textView;
}

@property (retain, nonatomic) IBOutlet UITextView * textView;

-(void) logFeedback:(NSString*) str;
@end
