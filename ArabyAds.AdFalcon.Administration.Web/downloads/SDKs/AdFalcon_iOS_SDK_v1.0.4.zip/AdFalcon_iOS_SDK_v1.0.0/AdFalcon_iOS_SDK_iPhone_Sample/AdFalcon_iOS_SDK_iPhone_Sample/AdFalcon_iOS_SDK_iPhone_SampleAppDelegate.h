//
//  AdFalcon_iOS_SDK_iPhone_SampleAppDelegate.h
//  AdFalcon_iOS_SDK_iPhone_Sample
//
//  Created by Emad Ziyad on 8/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AdFalcon_iOS_SDK_iPhone_SampleViewController;

@interface AdFalcon_iOS_SDK_iPhone_SampleAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet AdFalcon_iOS_SDK_iPhone_SampleViewController *viewController;

@end
