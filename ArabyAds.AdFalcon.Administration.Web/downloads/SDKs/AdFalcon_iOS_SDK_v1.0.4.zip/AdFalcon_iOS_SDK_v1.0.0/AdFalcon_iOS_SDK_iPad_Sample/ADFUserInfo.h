//
//  ADFUserInfo.h
//  AdFalcon SDK
//
//  Created by Emad Ziyad on 5/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum
{
    kADFUserInfoGenderNone = -1,
    kADFUserInfoGenderMale = 0,
    kADFUserInfoGenderFemale
}ADFUserInfoGender;

@interface ADFUserInfo : NSObject {
    NSString * language;
    NSString * postalCode;
    NSString * areaCode;
    int age;
    ADFUserInfoGender gender;
    NSString * countryCode;
    NSDate * birthdate;
    float locationLatitude;
    float locationLongitude;
    float locationAccuracyInMeters;

}
@property (nonatomic, assign) NSString * language;
@property (nonatomic, assign) ADFUserInfoGender gender;
@property (nonatomic, assign) int age;
@property (nonatomic, retain) NSString * postalCode;
@property (nonatomic, retain) NSString * areaCode;
@property (nonatomic, retain) NSString * countryCode;
@property (nonatomic, copy) NSDate * birthdate;
@property (nonatomic, assign) float locationLatitude;
@property (nonatomic, assign) float locationLongitude;
@property (nonatomic, assign) float locationAccuracyInMeters;
@end
