//
//  ADFAdView.h
//  AdFalcon SDK
//
//  Created by Emad Ziyad on 5/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ADFTargetingParams.h"
#import "ADFAdViewDelegate.h"

typedef enum{
    kADFAdViewAdUnitSize320x48 = 0,
    kADFAdViewAdUnitSize300x250,
    kADFAdViewAdUnitSize468x60,
    kADFAdViewAdUnitSize728x90,
    kADFAdViewAdUnitSize120x600
    
}ADFAdViewAdUnitSize;

typedef enum{
    kADFAdViewErrorInternalServer = -1,
    kADFAdViewErrorNoAdAvailabe = 1,
    kADFAdViewErrorInvalidParam = 2,
    kADFAdViewErrorMissingParam = 3,
    kADFAdViewErrorGenericSDK = 4,
    kADFAdViewErrorCommunication = 5
}ADFAdViewError;



@interface ADFAdView : UIView {
    
    int refreshDuration;
    NSObject<ADFAdViewDelegate> * delegate;
    BOOL testing;
    BOOL logging;

  }
/*
 *Determine the auto refresh duration in second
 */
@property(assign,   nonatomic) int refreshDuration;
/*
 *Feedback of SDK 
 */
@property(retain,   nonatomic) NSObject<ADFAdViewDelegate> * delegate;
/*
 *SDK will be in a test mode
 */
@property(assign,   nonatomic) BOOL testing;
/*
 *Display tracing for SDK
 */
@property(assign,   nonatomic) BOOL logging;


/*
 Add adView to root view with specific size base on adUnitSize, and start getting ad from adfalcon network 
 */
-(void) initializeWithAdUnit:(ADFAdViewAdUnitSize) adUnit
                      siteId:(NSString*) siteId
                      params:(ADFTargetingParams*) params
          rootViewController:(UIViewController*) rootViewController
           enableAutorefresh:(BOOL) enableAutorefresh
                    delegate:(NSObject<ADFAdViewDelegate> *) delegate;

/*
 pause auto refresh timer, which responsible about getting ad
 */
-(void) pauseAutoRefresh;

/*
 resume auto refresh timer, which responsible about getting ad
 */
-(void) resumeAutoRefresh;

/*
 refresh the current ad
 */
-(void) refreshAd;

+(NSString*) adFalconSDKVersion;

@end
