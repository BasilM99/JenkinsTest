//
//  ADFTargetingParams.h
//  AdFalcon_iOS_SDK10
//
//  Created by Noqoush on 8/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ADFUserInfo.h"


@interface ADFTargetingParams : NSObject 
{
    ADFUserInfo * userInfo;
    NSMutableArray * keywords;
    NSString * search;
    NSMutableDictionary * additionalInfo;
}

@property (nonatomic, retain) ADFUserInfo * userInfo;
@property (nonatomic, retain) NSMutableArray * keywords;
@property (nonatomic, retain) NSString * search;
@property (nonatomic, retain) NSMutableDictionary * additionalInfo;
@end
