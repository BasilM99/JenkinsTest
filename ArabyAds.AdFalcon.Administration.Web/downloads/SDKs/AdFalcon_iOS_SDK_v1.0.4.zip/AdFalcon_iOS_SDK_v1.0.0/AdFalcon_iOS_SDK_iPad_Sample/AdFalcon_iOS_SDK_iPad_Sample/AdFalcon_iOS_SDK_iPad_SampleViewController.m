//
//  AdFalcon_iOS_SDK_iPad_SampleViewController.m
//  AdFalcon_iOS_SDK_iPad_Sample
//
//  Created by Noqoush on 8/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AdFalcon_iOS_SDK_iPad_SampleViewController.h"

@implementation AdFalcon_iOS_SDK_iPad_SampleViewController
@synthesize textView;

- (void)dealloc
{
    [super dealloc];
    [adView release];
    [textView release];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    //initialize ADFalcon view and set size of the view base on ad unit size
    adView = [[ADFAdView alloc] initWithFrame:CGRectMake(0, 0, 320, 48)];
    
    //Create instance of ADFTargetingParams to store all needed info about user and application, all this informations are optional
    ADFTargetingParams * params = [[[ADFTargetingParams alloc] init] autorelease];
    //Determine ad keywords i.e. if you set sport, AdFalcon network will retreive ads related to sport
    params.keywords = [[[NSArray alloc] initWithObjects:@"Sport", @"Music", nil] autorelease];
    params.search = @"";//Not supported
    
    //Create intanse of ADFUserInfo 
    ADFUserInfo * user = [[[ADFUserInfo alloc] init] autorelease];
    params.userInfo = user;
    user.gender = kADFUserInfoGenderMale;
    
    //This property used to determine a language of ad
    user.language = @"ar";
    
    //Convert NSString date to NSDate
    NSString *dateString = @"21.11.1984";
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormatter setDateFormat:@"dd.MM.yyyy"];
    NSDate *dateFromString = [[[NSDate alloc] init] autorelease];
    dateFromString = [dateFormatter dateFromString:dateString];
    
    //Add birthdate or Age
    user.birthdate = dateFromString;
    user.age = 27;
    
    //Location information
    user.countryCode = @"JO";
    user.areaCode = @"962";
    user.postalCode = @"11121";
    
    //If you uses gps location you could pass user location information
    user.locationLatitude = 31.956641;
    user.locationLongitude = 35.847037;
    user.locationAccuracyInMeters = 100;
    
    
    //If you want to enable logging
    adView.logging = YES;
    
    //If you want to use test mode
    adView.testing = YES;
    
    //If you want to modify refresh duration 
    //the minimum available duration is 15 seconds
    adView.refreshDuration = 15;
    
    //initialize AdFalcon view and loading ads
    [adView initializeWithAdUnit:kADFAdViewAdUnitSize120x600 //Size of ad if you set a size for adView not match to the Ad unit size; the SDK will modify it to actual size
     
                     siteId:@"xxxxxxxxxxxxxxxxxxxxxxxxxxx" //sit ID from AdFalcon web site
     
                          params:params //User information
     
              rootViewController:self //rootViewController
     
               enableAutorefresh:NO //if you want to auto refresh for add set this value to YES other wise you will do this operation manully using refreshAd method
     
                        delegate:self //Optional
     
     ];
    
    //Add AdFalcon view
    [self.view addSubview:adView];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

-(void) logging:(NSString*) str
{
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    NSDate *date = [[[NSDate alloc] init] autorelease];
    NSString *dateString = [dateFormatter stringFromDate:date];
    
    textView.text = [NSString stringWithFormat:@"%@-%@\n%@", dateString ,str, textView.text];
}

-(void) logFeedback:(NSString*) str
{
    [self performSelectorOnMainThread:@selector(logging:) withObject:str waitUntilDone:YES];
    
}

/*
 *SDK will load ad from AdFalcon network
 */
-(void)adViewWillLoadAd:(ADFAdView*) adView
{
    [self logFeedback:@"Will Load Ad"];
}

/*
 *SDK did load ad from AdFalcon network
 */
-(void)adViewDidLoadAd: (ADFAdView*) adView
{
    [self logFeedback:@"Did Load Ad"];
}

/*
 *when SDK faces error during running; raise this method which has three parameters
 *adView: ADFAdView
 *code: Error code which exists in ADFAdViewError
 *message: description of error
 */
-(void)adView: (ADFAdView*) adView didFailWithErrorCode:(int) code message:(NSString*)message
{
    [self logFeedback:[NSString stringWithFormat:@"Error\nCode:%i\nMessage:%@", code, message]];
}

/*
 *User clicks at ad and will present ad screen
 */
-(void)adViewWillPresentScreen: (ADFAdView*) adView
{
    [self logFeedback:@"Will Present Screen"];
}

/*
 *Ad screen is presented
 */
-(void)adViewDidPresentScreen: (ADFAdView*) adView
{
    [self logFeedback:@"Did Present Screen"];
}

/*
 *User clicks to close an ad
 */
-(void)adViewWillDismissScreen: (ADFAdView*) adView
{
    [self logFeedback:@"Will Dismiss Screen"];
}

/*
 *Ad screen has closed
 */
-(void)adViewDidDismissScreen: (ADFAdView*) adView
{
    [self logFeedback:@"Did Dismiss Screen"];
}

/*
 *Application will terminate
 */
-(void)applicationWillTerminate:(UIApplication *)application
{
    [self logFeedback:@"Application Will Terminate"];
}

/*
 *Application will enter to background
 */
-(void)applicationWillEnterBackground:(UIApplication *)application
{
    [self logFeedback:@"Application Will Enter Background"];
}

@end
