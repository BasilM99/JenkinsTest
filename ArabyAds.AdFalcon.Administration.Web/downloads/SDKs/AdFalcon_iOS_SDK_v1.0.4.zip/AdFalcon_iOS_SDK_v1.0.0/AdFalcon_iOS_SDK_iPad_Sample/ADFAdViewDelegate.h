//
//  ADFAdViewDelegate.h
//  AdFalcon SDK
//
//  Created by Emad Ziyad on 5/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKIT/UIKIT.h>

@class ADFAdView;
@protocol ADFAdViewDelegate <NSObject>
/*
 *SDK will load ad from AdFalcon network
 */
-(void)adViewWillLoadAd:(ADFAdView*) adView;
/*
 *SDK did load ad from AdFalcon network
 */
-(void)adViewDidLoadAd: (ADFAdView*) adView;
/*
 *when SDK faces error during running; raise this method which has three parameters
 *adView: ADFAdView
 *code: Error code which exists in ADFAdViewError
 *message: description of error
 */
-(void)adView: (ADFAdView*) adView didFailWithErrorCode:(int) code message:(NSString*)message;
/*
 *User clicks at ad and will present ad screen
 */
-(void)adViewWillPresentScreen: (ADFAdView*) adView;
/*
 *Ad screen is presented
 */
-(void)adViewDidPresentScreen: (ADFAdView*) adView;
/*
 *User clicks to close an ad
 */
-(void)adViewWillDismissScreen: (ADFAdView*) adView;
/*
 *Ad screen has closed
 */
-(void)adViewDidDismissScreen: (ADFAdView*) adView;
/*
 *Application will terminate
 */
-(void)applicationWillTerminate:(UIApplication *)application;
/*
 *Application will enter to background
 */
-(void)applicationWillEnterBackground:(UIApplication *)application;
@end
