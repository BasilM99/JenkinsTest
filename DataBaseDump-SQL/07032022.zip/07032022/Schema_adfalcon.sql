-- MariaDB dump 10.17  Distrib 10.5.5-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: adfalcon
-- ------------------------------------------------------
-- Server version	10.5.5-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_trace_news_apps`
--

DROP TABLE IF EXISTS `_trace_news_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_trace_news_apps` (
  `name` text CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_countries`
--

DROP TABLE IF EXISTS `_user_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_countries` (
  `CountryId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`CountryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_manufacturers`
--

DROP TABLE IF EXISTS `_user_manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_manufacturers` (
  `ManufacturerId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`ManufacturerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_models`
--

DROP TABLE IF EXISTS `_user_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_models` (
  `ModelId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`ModelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_operators`
--

DROP TABLE IF EXISTS `_user_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_operators` (
  `OperatorId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`OperatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_platforms`
--

DROP TABLE IF EXISTS `_user_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_platforms` (
  `PlatformId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`PlatformId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_user_regions`
--

DROP TABLE IF EXISTS `_user_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_user_regions` (
  `RegionId` int(11) NOT NULL,
  `Count` int(11) NOT NULL,
  PRIMARY KEY (`RegionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PrimaryUserId` int(11) NOT NULL,
  `DefaultRevenuePercentage` float DEFAULT NULL,
  `UserAgreementVersion` varchar(45) NOT NULL DEFAULT '1.0',
  `AllowAPIAccess` bit(1) NOT NULL DEFAULT b'0',
  `Account_Biz_Id` int(11) NOT NULL DEFAULT 0,
  `BuyerId` int(11) DEFAULT NULL,
  `AccountRole` int(11) DEFAULT NULL,
  `TaxNo` varchar(300) DEFAULT NULL,
  `TaxRegistrationId` int(11) DEFAULT NULL,
  `AgencyCommissionModel` tinyint(4) DEFAULT NULL,
  `AgencyCommissionModelValue` decimal(21,12) DEFAULT NULL,
  `ODCZoneName` varchar(200) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `UserIdForeignKey_idx` (`PrimaryUserId`),
  KEY `account_buyer_fk_idx` (`BuyerId`),
  KEY `account_taxregistration_idx` (`TaxRegistrationId`),
  CONSTRAINT `UserIdForeignKey` FOREIGN KEY (`PrimaryUserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_buyer_fk` FOREIGN KEY (`BuyerId`) REFERENCES `buyers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_taxregistration` FOREIGN KEY (`TaxRegistrationId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=353836 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_apiaccess`
--

DROP TABLE IF EXISTS `account_apiaccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_apiaccess` (
  `AccountId` int(11) NOT NULL,
  `APIClientId` varchar(32) NOT NULL,
  `APISecretKey` varchar(32) NOT NULL,
  PRIMARY KEY (`AccountId`),
  CONSTRAINT `AccountId` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_bid_config`
--

DROP TABLE IF EXISTS `account_bid_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_bid_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `AppsiteId` int(11) DEFAULT NULL,
  `TypeId` tinyint(4) NOT NULL,
  `AdEventDefinitionId` int(11) DEFAULT NULL,
  `TargetingId` int(11) DEFAULT NULL,
  `Value` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  PRIMARY KEY (`Id`),
  KEY `accountbidconfig_adeventsdefinition_idx` (`AdEventDefinitionId`),
  CONSTRAINT `accountbidconfig_adeventsdefinition` FOREIGN KEY (`AdEventDefinitionId`) REFERENCES `ad_events_definition` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_cost_element`
--

DROP TABLE IF EXISTS `account_cost_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_cost_element` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Enabled` bit(1) DEFAULT b'1',
  `AccountId` int(11) NOT NULL,
  `CostElementId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `BeneficiaryPartyId` int(11) DEFAULT NULL,
  `CostValue` decimal(21,12) DEFAULT NULL,
  `DataProviderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CostElementId_account_cost_element` (`CostElementId`),
  KEY `AccountIdaccount_cost_element` (`AccountId`),
  KEY `Party_account_cost_element_idx` (`BeneficiaryPartyId`),
  KEY `dataprovidert_cost_element_idx` (`DataProviderId`),
  CONSTRAINT `AccountIdaccount_cost_element` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CostElementId_account_cost_element` FOREIGN KEY (`CostElementId`) REFERENCES `cost_elements` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Party_account_cost_element` FOREIGN KEY (`BeneficiaryPartyId`) REFERENCES `party` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dataprovidert_cost_element` FOREIGN KEY (`DataProviderId`) REFERENCES `dp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=607 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_discount`
--

DROP TABLE IF EXISTS `account_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_discount` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `Discount` decimal(21,12) NOT NULL,
  `DiscountFromDate` datetime NOT NULL,
  `DiscountToDate` datetime DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `IX_AccountId` (`AccountId`)
) ENGINE=InnoDB AUTO_INCREMENT=50905 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_dsp_request`
--

DROP TABLE IF EXISTS `account_dsp_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_dsp_request` (
  `Id` int(11) NOT NULL,
  `EmailAddress` varchar(255) NOT NULL,
  `FirstName` varchar(32) NOT NULL,
  `LastName` varchar(32) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `CountryId` int(11) NOT NULL,
  `Address1` varchar(255) DEFAULT NULL,
  `Company` varchar(255) DEFAULT '',
  `Phone` varchar(32) DEFAULT '',
  `RequestDate` datetime NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ActionDate` datetime DEFAULT NULL,
  `ActionNote` varchar(1000) DEFAULT NULL,
  `Note` varchar(1000) DEFAULT NULL,
  `RequestCode` varchar(36) DEFAULT NULL,
  `ApproverId` int(11) DEFAULT NULL,
  `IsAllowNotifications` bit(1) DEFAULT NULL,
  `CompanyTypeId` int(11) DEFAULT NULL,
  `StatusId` int(4) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `EmailAddress_account_dsp_request` (`EmailAddress`),
  KEY `CountryId_account_dsp_request` (`CountryId`),
  KEY `AccountIdRelation_dsp_request` (`AccountId`),
  KEY `CompanyTypeId_account_dsp_request_idx` (`CompanyTypeId`),
  CONSTRAINT `AccountRelation_dsp_request` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CompanyTypeId_account_dsp_request` FOREIGN KEY (`CompanyTypeId`) REFERENCES `companytypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CountryId_account_dsp_request` FOREIGN KEY (`CountryId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_events`
--

DROP TABLE IF EXISTS `account_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_events` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `Code` varchar(6) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `IsConversion` bit(1) NOT NULL DEFAULT b'0',
  `IsDeleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_features`
--

DROP TABLE IF EXISTS `account_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_features` (
  `Id` int(11) NOT NULL,
  `FeatureId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `DateNotify` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Account_Features_Account_idx` (`AccountId`),
  KEY `Account_Features_Account_idx1` (`UserId`),
  KEY `Account_Features_Features_idx` (`FeatureId`),
  CONSTRAINT `Account_Features_Account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Account_Features_Features` FOREIGN KEY (`FeatureId`) REFERENCES `features` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Account_Features_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fee`
--

DROP TABLE IF EXISTS `account_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fee` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Enabled` bit(1) DEFAULT b'1',
  `AccountId` int(11) NOT NULL,
  `FeeId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `BeneficiaryPartyId` int(11) DEFAULT NULL,
  `CostValue` decimal(21,12) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FeeId_account_Fee` (`FeeId`),
  KEY `AccountIdaccount_Fee` (`AccountId`),
  KEY `Party_account_Fee_idx` (`BeneficiaryPartyId`),
  CONSTRAINT `AccountIdaccount_Fee` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FeeId_account_Fee` FOREIGN KEY (`FeeId`) REFERENCES `fees` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Party_account_fee` FOREIGN KEY (`BeneficiaryPartyId`) REFERENCES `party` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1213 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_pgw`
--

DROP TABLE IF EXISTS `account_fund_pgw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_pgw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `integration_page_url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `api_resolver` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `return_page_url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `name_id` int(11) DEFAULT NULL,
  `config_data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_fund_pgw_localized_string_id` (`name_id`),
  CONSTRAINT `account_fund_pgw_localized_string_id` FOREIGN KEY (`name_id`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_history`
--

DROP TABLE IF EXISTS `account_fund_trans_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_history` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Amount` decimal(19,4) NOT NULL,
  `VATAmount` decimal(19,4) NOT NULL DEFAULT 0.0000,
  `UserId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `account_trans_type_Id` int(11) NOT NULL,
  `TransactionDate` datetime NOT NULL,
  `StatusId` int(11) NOT NULL COMMENT '0:Submitted\n1:Approved\n2:Cancled\n4:Rejected',
  `TransactionId` varchar(45) DEFAULT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `ReceiptNumber` varchar(30) DEFAULT NULL,
  `AttachmentId` int(11) DEFAULT NULL,
  `Comment` varchar(512) DEFAULT NULL,
  `CurrencyId` int(11) DEFAULT NULL,
  `OriginalAmount` decimal(19,4) DEFAULT NULL,
  `ObjectRelatedId` int(11) DEFAULT NULL,
  `account_fund_type_Id` int(11) DEFAULT 1,
  PRIMARY KEY (`Id`),
  KEY `AccountIdForeign` (`AccountId`),
  KEY `account_trans_type_IdForeign` (`account_trans_type_Id`),
  KEY `account_fund_trans_history__documents` (`AttachmentId`),
  KEY `account_fund_trans_history_Currencies` (`CurrencyId`),
  KEY `account_fund_trans_history_account_fund_type_Id_idx` (`account_fund_type_Id`),
  CONSTRAINT `AccountIdForeign` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`),
  CONSTRAINT `account_fund_trans_history_Currencies` FOREIGN KEY (`CurrencyId`) REFERENCES `currencies` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history__documents` FOREIGN KEY (`AttachmentId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history_account_fund_type_Id` FOREIGN KEY (`account_fund_type_Id`) REFERENCES `account_fund_type` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_trans_type_IdForeign` FOREIGN KEY (`account_trans_type_Id`) REFERENCES `account_fund_trans_type` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=55552 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_history_bchecks`
--

DROP TABLE IF EXISTS `account_fund_trans_history_bchecks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_history_bchecks` (
  `ID` int(11) NOT NULL,
  `Check_no` varchar(45) DEFAULT NULL,
  `issuer_name` varchar(45) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `issuer_bank_name` varchar(45) DEFAULT NULL,
  `issuer_bank_Branch` varchar(45) DEFAULT NULL,
  `Collected` int(1) DEFAULT 0,
  `system_payment_detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `account_payment_trans_history_bchecks__account_payment_details` (`system_payment_detail_id`),
  CONSTRAINT `account_payment_trans_history_bchecks__account_payment_details` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_history_paypal`
--

DROP TABLE IF EXISTS `account_fund_trans_history_paypal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_history_paypal` (
  `Id` int(11) NOT NULL,
  `system_payment_detail_id` int(11) NOT NULL,
  `account_payment_detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `account_payment_trans_history_paypal__system_paypal_account_id` (`system_payment_detail_id`),
  KEY `account_payment_trans_history_wire__account_payment_details` (`account_payment_detail_id`),
  KEY `system_payment_trans_history_wire__account_payment_details` (`system_payment_detail_id`),
  CONSTRAINT `account_fund_trans_history_paypal_ibfk_1` FOREIGN KEY (`account_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history_paypal_ibfk_2` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_history_pgw`
--

DROP TABLE IF EXISTS `account_fund_trans_history_pgw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_history_pgw` (
  `id` int(11) NOT NULL,
  `pgw_status` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `response_date` datetime DEFAULT NULL,
  `error_code` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extra_info` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_fund_pgw_id` int(11) NOT NULL,
  `receipt_number` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `system_payment_detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_fund_pgw_id` (`account_fund_pgw_id`),
  KEY `account_fund_trans_history_id` (`id`),
  KEY `account_fund_trans_history_wire_copy_System_account` (`system_payment_detail_id`),
  CONSTRAINT `account_fund_pgw_id` FOREIGN KEY (`account_fund_pgw_id`) REFERENCES `account_fund_pgw` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history_id` FOREIGN KEY (`id`) REFERENCES `account_fund_trans_history` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history_wire_System_account` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_history_wire`
--

DROP TABLE IF EXISTS `account_fund_trans_history_wire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_history_wire` (
  `ID` int(11) NOT NULL,
  `account_payment_detail_id` int(11) DEFAULT NULL,
  `system_payment_detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `account_payment_trans_history_wire__system_bank_account_id1` (`system_payment_detail_id`),
  KEY `account_payment_trans_history_wire__BankAccount1` (`account_payment_detail_id`),
  CONSTRAINT `account_payment_trans_history_wire__BankAccount` FOREIGN KEY (`account_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_payment_trans_history_wire__system_bank_account_id` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_status`
--

DROP TABLE IF EXISTS `account_fund_trans_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_status` (
  `id` int(11) NOT NULL,
  `name_id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_fund_trans_status_name_id` (`name_id`),
  CONSTRAINT `account_fund_trans_status_name_id` FOREIGN KEY (`name_id`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_trans_type`
--

DROP TABLE IF EXISTS `account_fund_trans_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_trans_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `AllowImpersonate` bit(1) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `FundTypeNameId` (`NameId`) USING BTREE,
  CONSTRAINT `account_fund_trans_type_ibfk_1` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_fund_type`
--

DROP TABLE IF EXISTS `account_fund_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_fund_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Multiplier` tinyint(4) DEFAULT 1 COMMENT '1 for normal fund type, -1 for refund',
  PRIMARY KEY (`Id`),
  KEY `FK_account_fund_type_localizedstringids` (`NameId`) USING BTREE,
  CONSTRAINT `FK_account_fund_type_localizedstringids` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_invitation`
--

DROP TABLE IF EXISTS `account_invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_invitation` (
  `id` int(11) NOT NULL,
  `invitationcode` varchar(600) NOT NULL,
  `EmailAddress` varchar(600) NOT NULL,
  `InvitationDate` datetime NOT NULL,
  `accountid` int(11) NOT NULL,
  `IsAccepted` bit(1) NOT NULL,
  `UserType` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `Accountid_invitation_idx` (`accountid`),
  CONSTRAINT `Accountid_invitation` FOREIGN KEY (`accountid`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_ips`
--

DROP TABLE IF EXISTS `account_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_ips` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `IPRangeStart` varbinary(16) NOT NULL,
  `IPRangeEnd` varbinary(16) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Accounts` (`AccountId`),
  CONSTRAINT `FK_Accounts` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_keyword_mapping`
--

DROP TABLE IF EXISTS `account_keyword_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_keyword_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `KeywordId` int(11) NOT NULL,
  `Code` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4178 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_kpis`
--

DROP TABLE IF EXISTS `account_kpis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_kpis` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeFormatId` tinyint(4) NOT NULL COMMENT '1 - Display\n2 - Video\n3 - Native\n4 - Interstitial',
  `AccountId` int(11) DEFAULT NULL,
  `DisplayRate` decimal(21,12) NOT NULL,
  `CTR` decimal(21,12) NOT NULL,
  `ConversionRate` decimal(21,12) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_kpis_back`
--

DROP TABLE IF EXISTS `account_kpis_back`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_kpis_back` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeFormatId` tinyint(4) NOT NULL COMMENT '1 - Display\n2 - Video\n3 - Native\n4 - Interstitial',
  `AccountId` int(11) DEFAULT NULL,
  `DisplayRate` decimal(21,12) NOT NULL,
  `CTR` decimal(21,12) NOT NULL,
  `ConversionRate` decimal(21,12) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_details`
--

DROP TABLE IF EXISTS `account_payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_details` (
  `Id` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `IsDefault` bit(1) DEFAULT b'1',
  `IsSystem` bit(1) DEFAULT b'0',
  `IsActive` bit(1) DEFAULT b'1',
  `ActiveFrom` datetime DEFAULT NULL,
  `ActiveTo` datetime DEFAULT NULL,
  `typeId` tinyint(4) DEFAULT NULL COMMENT '1 ===>bank  , 2 ===>paypal',
  `subtypeId` tinyint(4) DEFAULT 1 COMMENT '1 ===>both  , 2 ===>payment , 3===>fund',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_trans_history`
--

DROP TABLE IF EXISTS `account_payment_trans_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_trans_history` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Amount` decimal(19,4) NOT NULL,
  `VATAmount` decimal(19,4) NOT NULL DEFAULT 0.0000,
  `UserId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `TransactionDate` datetime NOT NULL,
  `account_trans_type_Id` int(11) NOT NULL,
  `AttachmentId` int(11) DEFAULT NULL,
  `Comment` varchar(512) DEFAULT NULL,
  `TransactionId` varchar(32) DEFAULT NULL,
  `AdFalconReceiptNo` varchar(32) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `CurrencyId` int(11) DEFAULT NULL,
  `OriginalAmount` decimal(19,4) DEFAULT NULL,
  `ForMonth` datetime DEFAULT NULL,
  `BankAccountId` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `exchangeRate` decimal(19,4) DEFAULT 0.0000,
  PRIMARY KEY (`Id`),
  KEY `AccountIdForeignKey` (`AccountId`),
  KEY `UserIdForeign` (`UserId`),
  KEY `account_payment_trans_history__Currencies` (`CurrencyId`),
  CONSTRAINT `AccountIdForeignKey` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserIdForeign` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_payment_trans_history__Currencies` FOREIGN KEY (`CurrencyId`) REFERENCES `currencies` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31717 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_trans_history_bchecks`
--

DROP TABLE IF EXISTS `account_payment_trans_history_bchecks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_trans_history_bchecks` (
  `ID` int(11) NOT NULL,
  `system_payment_detail_id` int(11) DEFAULT NULL,
  `Check_no` varchar(45) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `Collected` int(1) DEFAULT 0,
  `BeneficiaryName` varchar(255) DEFAULT NULL,
  `issuer_name` varchar(45) DEFAULT NULL,
  `issuer_bank_name` varchar(45) DEFAULT NULL,
  `issuer_bank_Branch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `account_payment_trans_history_bchecks__account_payment_details` (`system_payment_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_trans_history_paypal`
--

DROP TABLE IF EXISTS `account_payment_trans_history_paypal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_trans_history_paypal` (
  `Id` int(11) NOT NULL,
  `system_payment_detail_id` int(11) NOT NULL,
  `account_payment_detail_id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `account_payment_trans_history_paypal__system_paypal_account_id` (`system_payment_detail_id`),
  KEY `account_payment_trans_history_wire__account_payment_details` (`account_payment_detail_id`),
  KEY `system_payment_trans_history_wire__account_payment_details` (`system_payment_detail_id`),
  CONSTRAINT `account_fund_trans_history_paypal_copy_ibfk_1` FOREIGN KEY (`account_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_fund_trans_history_paypal_copy_ibfk_2` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_trans_history_wire`
--

DROP TABLE IF EXISTS `account_payment_trans_history_wire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_trans_history_wire` (
  `ID` int(11) NOT NULL,
  `account_payment_detail_id` int(11) DEFAULT NULL,
  `system_payment_detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `account_payment_trans_history_wire__BankAccount1` (`account_payment_detail_id`),
  KEY `account_payment_trans_history_wire__system_bank_account_id1` (`system_payment_detail_id`),
  CONSTRAINT `account_payment_trans_history_wire__BankAccount1` FOREIGN KEY (`account_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_payment_trans_history_wire__system_bank_account_id1` FOREIGN KEY (`system_payment_detail_id`) REFERENCES `account_payment_details` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_payment_trans_type`
--

DROP TABLE IF EXISTS `account_payment_trans_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_payment_trans_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `PaymentTypeNameIdForeignKey` (`NameId`),
  CONSTRAINT `PaymentTypeNameIdForeignKey` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_permissions`
--

DROP TABLE IF EXISTS `account_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_permissions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `PermissionId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `lookup_permission_fk_idx` (`PermissionId`),
  KEY `ad_permission_fk_idx` (`AccountId`),
  CONSTRAINT `ad_permission_fk` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_permission_fk` FOREIGN KEY (`PermissionId`) REFERENCES `permissions` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=655 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accountsperformance`
--

DROP TABLE IF EXISTS `accountsperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountsperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Spend` decimal(21,12) DEFAULT 0.000000000000,
  `Earning` decimal(21,12) DEFAULT 0.000000000000,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AccountId`,`Day`),
  KEY `Account_FK` (`AccountId`),
  KEY `FK_Account` (`AccountId`)
) ENGINE=InnoDB AUTO_INCREMENT=4953496 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accountsummary`
--

DROP TABLE IF EXISTS `accountsummary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountsummary` (
  `AccountId` int(11) NOT NULL,
  `Earning` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `Funds` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `Credit` decimal(21,12) DEFAULT 0.000000000000,
  `TotalPayments` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `ModifiedOn` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`AccountId`),
  KEY `AccountIdIndex` (`AccountId`),
  KEY `Account_FK` (`AccountId`),
  KEY `AccountId` (`AccountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accountsummary_`
--

DROP TABLE IF EXISTS `accountsummary_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountsummary_` (
  `AccountId` int(11) NOT NULL,
  `Earning` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `Funds` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `Credit` decimal(21,12) DEFAULT 0.000000000000,
  `TotalPayments` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  PRIMARY KEY (`AccountId`),
  KEY `AccountIdIndex` (`AccountId`),
  KEY `Account_FK` (`AccountId`),
  KEY `AccountId` (`AccountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_type_filters`
--

DROP TABLE IF EXISTS `action_type_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_type_filters` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ActionTypeId` int(11) NOT NULL,
  `AppSiteId` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `FK_ActionTypes` (`ActionTypeId`),
  CONSTRAINT `FK_ActionTypes` FOREIGN KEY (`ActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=28923 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actiontypeconstraints`
--

DROP TABLE IF EXISTS `actiontypeconstraints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actiontypeconstraints` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameID` int(11) DEFAULT NULL,
  `AdActionTypeId` int(11) DEFAULT NULL,
  `PlatformID` int(11) DEFAULT NULL,
  `SubType` int(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `AdActionType_AdActionTypeId` (`AdActionTypeId`),
  KEY `LocalizedStringIds_NameId` (`NameID`),
  KEY `Platforms_PlatformID` (`PlatformID`),
  CONSTRAINT `AdActionType_AdActionTypeId` FOREIGN KEY (`AdActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `LocalizedStringIds_NameId` FOREIGN KEY (`NameID`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Platforms_PlatformID` FOREIGN KEY (`PlatformID`) REFERENCES `platforms` (`PlatformId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_action_value_trackers`
--

DROP TABLE IF EXISTS `ad_action_value_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_action_value_trackers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdActionValueId` int(11) NOT NULL,
  `Url` varchar(5000) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `ad_action_value_trackers_adactionvalues_fk_idx` (`AdActionValueId`),
  CONSTRAINT `ad_action_value_trackers_adactionvalues_fk` FOREIGN KEY (`AdActionValueId`) REFERENCES `adactionvalues` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9295 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_attributes`
--

DROP TABLE IF EXISTS `ad_creative_unit_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_attributes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitId` int(11) NOT NULL,
  `CreativeAttributeId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdCreativeUnitId_idx` (`AdCreativeUnitId`),
  KEY `CreativeAttribute_idx` (`CreativeAttributeId`),
  CONSTRAINT `adcreativeunitattributes_adcreativeunits` FOREIGN KEY (`AdCreativeUnitId`) REFERENCES `adcreativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adcreativeunitattributes_creativeattributes` FOREIGN KEY (`CreativeAttributeId`) REFERENCES `creative_attributes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2339752 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_ssp_partner_approval`
--

DROP TABLE IF EXISTS `ad_creative_unit_ssp_partner_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_ssp_partner_approval` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitId` int(11) NOT NULL,
  `PartnerCreativeId` varchar(200) DEFAULT NULL,
  `AdCreativeUnitVersion` int(11) NOT NULL,
  `SSPPartnerId` int(11) NOT NULL,
  `OpenAndPrivateAuctionStatus` tinyint(4) DEFAULT 0 COMMENT '0 - Pending, 1 - Approved, 2 - Rejected',
  `PGAndPreferredDealsStatus` tinyint(4) DEFAULT 0 COMMENT '0 - Pending, 1 - Approved, 2 - Rejected',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `adcreativeunitsssppartnerapproval_adcreativeunits_fk` (`AdCreativeUnitId`),
  KEY `adcreativeunitsssppartnerapproval_ssp_partners_fk` (`SSPPartnerId`),
  CONSTRAINT `adcreativeunitsssppartnerapproval_adcreativeunits_fk` FOREIGN KEY (`AdCreativeUnitId`) REFERENCES `adcreativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adcreativeunitsssppartnerapproval_ssp_partners_fk` FOREIGN KEY (`SSPPartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7867 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_ssp_partner_approval_combination_reject_reasons`
--

DROP TABLE IF EXISTS `ad_creative_unit_ssp_partner_approval_combination_reject_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_ssp_partner_approval_combination_reject_reasons` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitSSPPartnerApprovalCombinationId` int(11) NOT NULL,
  `OpenAndPrivateAuctionReason` varchar(500) DEFAULT NULL,
  `PGAndPreferredDealsReason` varchar(500) DEFAULT NULL,
  `OpenAndPrivateAuctionDetails` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PGAndPreferredDealsDetails` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Unique1` (`AdCreativeUnitSSPPartnerApprovalCombinationId`,`OpenAndPrivateAuctionReason`),
  UNIQUE KEY `IX_Unique2` (`AdCreativeUnitSSPPartnerApprovalCombinationId`,`PGAndPreferredDealsReason`),
  KEY `adcreativeunitsssppartnerapprovalcombinationreject_parent_fk` (`AdCreativeUnitSSPPartnerApprovalCombinationId`),
  CONSTRAINT `adcreativeunitsssppartnerapprovalcombinationreject_parent_fk` FOREIGN KEY (`AdCreativeUnitSSPPartnerApprovalCombinationId`) REFERENCES `ad_creative_unit_ssp_partner_approval_combinations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=652006 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_ssp_partner_approval_combinations`
--

DROP TABLE IF EXISTS `ad_creative_unit_ssp_partner_approval_combinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_ssp_partner_approval_combinations` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitSSPPartnerApprovalId` int(11) NOT NULL,
  `CreativeFormatId` int(11) NOT NULL,
  `OpenAndPrivateAuctionStatus` tinyint(4) DEFAULT 0 COMMENT '0 - Pending, 1 - Approved, 2 - Rejected',
  `PGAndPreferredDealsStatus` tinyint(4) DEFAULT 0 COMMENT '0 - Pending, 1 - Approved, 2 - Rejected',
  `LastStatusUpdate` datetime DEFAULT NULL,
  `Adm` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `adcreativeunitsssppartnerapprovalcombinations_parent_fk` (`AdCreativeUnitSSPPartnerApprovalId`),
  KEY `adcreativeunitsssppartnerapprovalcombinations_creativeformats_fk` (`CreativeFormatId`),
  CONSTRAINT `adcreativeunitsssppartnerapprovalcombinations_creativeformats_fk` FOREIGN KEY (`CreativeFormatId`) REFERENCES `creative_formats` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adcreativeunitsssppartnerapprovalcombinations_parent_fk` FOREIGN KEY (`AdCreativeUnitSSPPartnerApprovalId`) REFERENCES `ad_creative_unit_ssp_partner_approval` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15247 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_trackers`
--

DROP TABLE IF EXISTS `ad_creative_unit_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_trackers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitId` int(11) NOT NULL,
  `AdGroupEventId` int(11) NOT NULL,
  `Type` tinyint(4) NOT NULL COMMENT '1 - URL\n2 - JS',
  `Url` varchar(5000) DEFAULT NULL,
  `TrackingJS` varchar(5000) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `ad_creative_unit_trackers_adcreativeunits_fk_idx` (`AdCreativeUnitId`),
  KEY `ad_creative_unit_trackers_ad_group_events_fk_idx` (`AdGroupEventId`),
  CONSTRAINT `ad_creative_unit_trackers_ad_group_events_fk` FOREIGN KEY (`AdGroupEventId`) REFERENCES `adgroup_events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=333883 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_creative_unit_vendors`
--

DROP TABLE IF EXISTS `ad_creative_unit_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_creative_unit_vendors` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdCreativeUnitId` int(11) NOT NULL,
  `CreativeVendorId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdCreativeUnitId_idx` (`AdCreativeUnitId`),
  KEY `CreativeVendorId_idx` (`CreativeVendorId`),
  CONSTRAINT `adcreativeunitvendors_adcreativeunits` FOREIGN KEY (`AdCreativeUnitId`) REFERENCES `adcreativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adcreativeunitvendors_creativevendors` FOREIGN KEY (`CreativeVendorId`) REFERENCES `creative_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3544 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_custom_parameters`
--

DROP TABLE IF EXISTS `ad_custom_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_custom_parameters` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdId` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Value` varchar(200) NOT NULL,
  `IsMandatory` bit(1) NOT NULL DEFAULT b'1',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `adcustomparameters_ads_fk_idx` (`AdId`),
  CONSTRAINT `adcustomparameters_ads_fk` FOREIGN KEY (`AdId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25612 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_events_definition`
--

DROP TABLE IF EXISTS `ad_events_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_events_definition` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(6) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `DefaultFrequencyCapping` int(11) DEFAULT NULL,
  `CapIfBillableOnly` bit(1) NOT NULL DEFAULT b'0',
  `SupportFrequencyCapping` bit(1) DEFAULT b'0',
  `IsConversion` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_extension`
--

DROP TABLE IF EXISTS `ad_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_extension` (
  `Id` int(11) NOT NULL,
  `wrappercontent` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `ad_extension_ads_FK` FOREIGN KEY (`Id`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_supported_creativeunits`
--

DROP TABLE IF EXISTS `ad_supported_creativeunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_supported_creativeunits` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeId` int(11) NOT NULL,
  `AdSubTypeId` int(11) DEFAULT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `EnvironmentTypeId` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 - All, 1 - Web, 2 - App',
  `RequiredType` tinyint(4) NOT NULL DEFAULT 1,
  `OrientationReplacementId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Ad_Supported_Creativeunits_AdTypes_FK` (`AdTypeId`),
  KEY `Ad_Supported_Creativeunits_CreativeUnits_FK` (`CreativeUnitId`),
  CONSTRAINT `Ad_Supported_Creativeunits_AdTypes_FK` FOREIGN KEY (`AdTypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Ad_Supported_Creativeunits_CreativeUnits_FK` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ad_thirdparty_trackers`
--

DROP TABLE IF EXISTS `ad_thirdparty_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_thirdparty_trackers` (
  `Id` int(11) NOT NULL,
  `AdId` int(11) DEFAULT NULL,
  `VendorID` varchar(5000) DEFAULT NULL,
  `ScriptURL` varchar(5000) DEFAULT NULL,
  `ExecutionErrorTrackerURL` varchar(5000) DEFAULT NULL,
  `ParametersURL` varchar(5000) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `ad_thirdparty_trackers_ads` (`AdId`),
  CONSTRAINT `ad_thirdparty_trackers_ads` FOREIGN KEY (`AdId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adactioncostmodelwrappers`
--

DROP TABLE IF EXISTS `adactioncostmodelwrappers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adactioncostmodelwrappers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdActionTypeId` int(11) NOT NULL,
  `CostModelWrapperId` int(11) NOT NULL,
  `Scope` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `adactioncostmodel_costmodelwrapper_idx` (`CostModelWrapperId`),
  CONSTRAINT `adactioncostmodel_costmodelwrapper` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adactions`
--

DROP TABLE IF EXISTS `adactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adactions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `IsDeleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adactiontype_tracking_events`
--

DROP TABLE IF EXISTS `adactiontype_tracking_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adactiontype_tracking_events` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdActionTypeId` int(11) NOT NULL,
  `CostModelWrapperId` int(11) DEFAULT NULL,
  `TrackingEventId` int(11) NOT NULL,
  `MappedStatColumnName` varchar(20) NOT NULL,
  `IsBillable` bit(1) NOT NULL DEFAULT b'0',
  `ParentId` int(11) DEFAULT NULL,
  `AllowDuplicate` bit(1) NOT NULL DEFAULT b'1',
  `Prerequisites` varchar(50) DEFAULT NULL,
  `AllPrerequisitesRequired` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`Id`),
  KEY `adactiontypeId_idx` (`AdActionTypeId`),
  KEY `costmodelwrapperid_idx` (`CostModelWrapperId`),
  KEY `trackingeventid_idx` (`TrackingEventId`),
  KEY `ParentId_idx` (`ParentId`),
  CONSTRAINT `ParentId` FOREIGN KEY (`ParentId`) REFERENCES `adactiontype_tracking_events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adactiontypeId` FOREIGN KEY (`AdActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `costmodelwrapperid` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `trackingeventid` FOREIGN KEY (`TrackingEventId`) REFERENCES `ad_events_definition` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=640 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adactiontypes`
--

DROP TABLE IF EXISTS `adactiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adactiontypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` tinyint(4) DEFAULT NULL,
  `ViewName` varchar(45) DEFAULT NULL,
  `ClickActionImageId` int(11) DEFAULT NULL,
  `ShowInAppId` tinyint(4) DEFAULT NULL,
  `ShowInHouseAd` bit(1) DEFAULT b'1',
  `ShowForObjective` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `AdActionTypes_LocalizedStringId` (`NameId`),
  KEY `ClickActionImageId_TileImages` (`ClickActionImageId`),
  CONSTRAINT `AdActionTypes_LocalizedStringId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ClickActionImageId_TileImages` FOREIGN KEY (`ClickActionImageId`) REFERENCES `tileimages` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adactionvalues`
--

DROP TABLE IF EXISTS `adactionvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adactionvalues` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdId` int(11) DEFAULT NULL,
  `TypeId` int(11) DEFAULT NULL,
  `Value` varchar(5000) DEFAULT NULL,
  `Value2` varchar(5000) DEFAULT NULL,
  `AppLink` varchar(5000) DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `AdId_UNIQUE` (`AdId`),
  KEY `AdId_Ads` (`AdId`),
  CONSTRAINT `AdId_Ads` FOREIGN KEY (`AdId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=260890 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adclicktagtrackers`
--

DROP TABLE IF EXISTS `adclicktagtrackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adclicktagtrackers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdId` int(11) DEFAULT NULL,
  `Url` varchar(5000) NOT NULL,
  `VariableName` varchar(5000) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `adclicktagtrackers_adcreativeunits_fk_idx` (`AdId`),
  CONSTRAINT `adclicktagtrackers_adcreativeunits_fk` FOREIGN KEY (`AdId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=330676 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adcreativeunits`
--

DROP TABLE IF EXISTS `adcreativeunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adcreativeunits` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UniqueId` varchar(36) DEFAULT NULL,
  `Version` int(11) DEFAULT 1,
  `AdId` int(11) DEFAULT NULL,
  `CreativeUnitId` int(11) DEFAULT NULL,
  `Content` mediumtext DEFAULT NULL,
  `DocumentId` int(11) DEFAULT NULL,
  `ImageType` varchar(10) DEFAULT NULL,
  `SnapshotDocumentId` int(11) DEFAULT NULL,
  `SnapshotUrl` varchar(5000) DEFAULT NULL,
  `KeepShapshot` tinyint(1) NOT NULL DEFAULT 0,
  `CreativeProtocolId` int(11) DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `CreativeUnits_FK` (`CreativeUnitId`),
  KEY `Ads_FK` (`AdId`) USING BTREE,
  KEY `adcreativeunits_creativeprotocols_FK_idx` (`CreativeProtocolId`),
  CONSTRAINT `Ads_FK` FOREIGN KEY (`AdId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CreativeUnits_FK` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adcreativeunits_creativeprotocols_FK` FOREIGN KEY (`CreativeProtocolId`) REFERENCES `creative_protocols` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=392941 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adfalconrevenue`
--

DROP TABLE IF EXISTS `adfalconrevenue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adfalconrevenue` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Revenue` decimal(21,12) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AppSiteId`,`Day`),
  KEY `Appsite_FK` (`AppSiteId`)
) ENGINE=InnoDB AUTO_INCREMENT=21547669 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adfalconrevenue_`
--

DROP TABLE IF EXISTS `adfalconrevenue_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adfalconrevenue_` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Revenue` decimal(21,12) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AppSiteId`,`Day`),
  KEY `Appsite_FK` (`AppSiteId`)
) ENGINE=InnoDB AUTO_INCREMENT=21254216 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adformats`
--

DROP TABLE IF EXISTS `adformats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adformats` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(10) NOT NULL,
  `Id_Hex` varchar(7) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_IdHex` (`Id_Hex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_assigned_appsites`
--

DROP TABLE IF EXISTS `adgroup_assigned_appsites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_assigned_appsites` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CampaignId` int(11) NOT NULL,
  `AdGroupId` int(11) DEFAULT NULL,
  `AppSiteAccountId` int(11) DEFAULT NULL,
  `AppSiteId` int(11) NOT NULL,
  `SubAppSiteId` int(11) DEFAULT NULL,
  `SSPId` int(11) DEFAULT NULL,
  `Include` bit(1) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `campaign_assinged_appsited_account_FK_idx` (`AppSiteAccountId`),
  KEY `campaign_assinged_appsited_account_FK_idx1` (`SSPId`),
  KEY `campaign_assinged_appsited_sub_appsites_FK_idx` (`SubAppSiteId`),
  KEY `campaign_assinged_appsited_campaigns_FK_idx` (`CampaignId`),
  KEY `campaign_assinged_appsited_adgroups_FK_idx` (`AdGroupId`),
  CONSTRAINT `campaign_assinged_appsited_account_FK` FOREIGN KEY (`AppSiteAccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaign_assinged_appsited_adgroups_FK` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaign_assinged_appsited_campaigns_FK` FOREIGN KEY (`CampaignId`) REFERENCES `campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaign_assinged_appsited_ssp_partners_FK` FOREIGN KEY (`SSPId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaign_assinged_appsited_sub_appsites_FK` FOREIGN KEY (`SubAppSiteId`) REFERENCES `sub_appsites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=396274 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_bid_config`
--

DROP TABLE IF EXISTS `adgroup_bid_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_bid_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `AppSiteId` int(11) DEFAULT NULL,
  `SubAppSiteId` int(11) DEFAULT NULL,
  `Bid` decimal(21,12) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `adgroup_bid_config_account` (`AccountId`),
  KEY `adgroup_bid_config_appsite` (`AppSiteId`),
  KEY `adgroup_bid_config_sub_appsites_idx` (`SubAppSiteId`),
  KEY `IX_UNIQUE` (`AdGroupId`,`AccountId`,`AppSiteId`,`SubAppSiteId`),
  CONSTRAINT `adgroup_bid_config_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroup_bid_config_adgroup` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroup_bid_config_appsite` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroup_bid_config_sub_appsites` FOREIGN KEY (`SubAppSiteId`) REFERENCES `sub_appsites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5053 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_bid_modifiers`
--

DROP TABLE IF EXISTS `adgroup_bid_modifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_bid_modifiers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CampaignId` int(11) NOT NULL,
  `AdGroupId` int(11) DEFAULT NULL,
  `DimensionType` int(11) NOT NULL COMMENT 'Time = 1 \\n Country = 2 \\n Region = 3 \\n Operator = 4 \\n Geofence = 5 \\n DeviceManufacturer = 6 \\n DeviceModel = 7 \\n DevicePlatform = 8 \\n DeviceType = 9 \\n CreativeUnit = 10 \\n Keyword = 11 \\n EnvironmentType = 12 \\n ContentList = 13 \\n City = 14',
  `DimensionValue` varchar(5000) COLLATE utf8_bin NOT NULL COMMENT '- When DimentionType is "Geofence", then value must be in this format: "{Latitude},{Longitude},{Radius}"\n- When DimentionType is "EnvironmentType", then value must be either "1" for Web or "2" for App',
  `Multiplier` decimal(21,12) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `adgroup_bid_modifiers_campaigns_FK_idx` (`CampaignId`),
  KEY `adgroup_bid_modifiers_adgroups_FK_idx` (`AdGroupId`),
  CONSTRAINT `adgroup_bid_modifiers_adgroups_FK` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroup_bid_modifiers_campaigns_FK` FOREIGN KEY (`CampaignId`) REFERENCES `campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1213 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_cost_elements`
--

DROP TABLE IF EXISTS `adgroup_cost_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_cost_elements` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `CostElementId` int(11) NOT NULL,
  `BeneficiaryPartyId` int(11) DEFAULT NULL,
  `CostValue` decimal(21,12) NOT NULL,
  `FromDate` datetime NOT NULL,
  `ToDate` datetime DEFAULT NULL,
  `CostModelWrapperId` int(11) DEFAULT NULL,
  `Scope` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - Inventory, 2 - Data Provider',
  `DataProviderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CostElement_FK` (`CostElementId`),
  KEY `Party_FK` (`BeneficiaryPartyId`),
  KEY `CostModelWrapper_ForeignKey` (`CostModelWrapperId`),
  KEY `AdGroupCostElements_DataProviders_FK_idx` (`DataProviderId`),
  CONSTRAINT `AdGroupCostElements_DataProviders_FK` FOREIGN KEY (`DataProviderId`) REFERENCES `dp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CostElement_FK` FOREIGN KEY (`CostElementId`) REFERENCES `cost_elements` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CostModelWrapper_ForeignKey` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Party_FK` FOREIGN KEY (`BeneficiaryPartyId`) REFERENCES `party` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9196766 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_cost_items`
--

DROP TABLE IF EXISTS `adgroup_cost_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_cost_items` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `CostItemId` int(11) NOT NULL,
  `BeneficiaryPartyId` int(11) DEFAULT NULL,
  `Value` decimal(21,12) NOT NULL,
  `FromDate` datetime NOT NULL,
  `ToDate` datetime DEFAULT NULL,
  `Scope` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - Inventory\n2 - Data Provider',
  `DataProviderId` int(11) DEFAULT NULL,
  `CostModelWrapperId` int(11) DEFAULT NULL,
  `Type` tinyint(4) DEFAULT 1 COMMENT '1 - Cost Element\n2 - Fee',
  `IsRemoved` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `AdGroupCostItems_CostItem_FK_idx` (`CostItemId`),
  KEY `AdGroupCostItems_Party_FK_idx` (`BeneficiaryPartyId`),
  KEY `AdGroupCostItems_CostModelWrapper_FK_idx` (`CostModelWrapperId`),
  KEY `AdGroupCostItems_DataProviders_FK_idx` (`DataProviderId`),
  CONSTRAINT `AdGroupCostItems_CostItem_FK` FOREIGN KEY (`CostItemId`) REFERENCES `cost_items` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdGroupCostItems_CostModelWrapper_FK` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdGroupCostItems_DataProviders_FK` FOREIGN KEY (`DataProviderId`) REFERENCES `dp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdGroupCostItems_Party_FK` FOREIGN KEY (`BeneficiaryPartyId`) REFERENCES `party` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9232117 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_dynamic_bidding_config`
--

DROP TABLE IF EXISTS `adgroup_dynamic_bidding_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_dynamic_bidding_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `BidOptimizationType` tinyint(4) NOT NULL COMMENT '1 - Maximize CTR\n2 - Minimize eCPC\n3 - Minimize eCPA\n4 - MinimizeeCPVCV\n5 - MaximizeVCVR',
  `BidOptimizationValue` decimal(21,12) NOT NULL,
  `DefaultBidPrice` decimal(21,12) NOT NULL,
  `MaxBidPrice` decimal(21,12) NOT NULL,
  `MinBidPrice` decimal(21,12) NOT NULL,
  `BidStep` decimal(21,12) NOT NULL,
  `KeepBiddingAtMinimum` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `adgroupdynamicbiddingconfig_adgroups_fk_idx` (`AdGroupId`),
  CONSTRAINT `adgroupdynamicbiddingconfig_adgroups_fk` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3637 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_event_audience_segments`
--

DROP TABLE IF EXISTS `adgroup_event_audience_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_event_audience_segments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupEventId` int(11) NOT NULL,
  `AudienceSegmentId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `adgroupeventaudiencesegments_adgroupevents_fk_idx` (`AdGroupEventId`),
  KEY `adgroupeventaudiencesegments_audiencesegments_fk_idx` (`AudienceSegmentId`),
  CONSTRAINT `adgroupeventaudiencesegments_adgroupevents_fk` FOREIGN KEY (`AdGroupEventId`) REFERENCES `adgroup_events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroupeventaudiencesegments_audiencesegments_fk` FOREIGN KEY (`AudienceSegmentId`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12226 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroup_events`
--

DROP TABLE IF EXISTS `adgroup_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroup_events` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `Code` varchar(6) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `PrerequisiteIds` varchar(200) DEFAULT NULL,
  `AllPrerequisitesRequired` bit(1) DEFAULT b'1',
  `AllowDuplicate` bit(1) NOT NULL DEFAULT b'0',
  `StatColumnName` varchar(50) DEFAULT NULL,
  `Revenue` decimal(21,12) DEFAULT NULL,
  `IsBillable` bit(1) NOT NULL DEFAULT b'0',
  `IsCustom` bit(1) NOT NULL DEFAULT b'0',
  `IsPrimary` bit(1) NOT NULL DEFAULT b'0',
  `IsConversion` bit(1) NOT NULL DEFAULT b'0',
  `IsTracking` bit(1) NOT NULL DEFAULT b'1',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `ad_group_events_adgroups_fk_idx` (`AdGroupId`),
  CONSTRAINT `adgroup_events_fix_groups_fk` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=194155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupobjectives`
--

DROP TABLE IF EXISTS `adgroupobjectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupobjectives` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) DEFAULT NULL,
  `ActionTypeId` int(11) DEFAULT NULL,
  `ObjectiveTypeId` int(11) DEFAULT NULL,
  `AdTypeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ActionTypes_AdGroupObjectives` (`ActionTypeId`),
  KEY `ObjectiveTypeId_AdGroupObjectives` (`ObjectiveTypeId`),
  KEY `AdGroup_AdGroupObjectives` (`AdGroupId`),
  KEY `AdTypeId_AdGroupObjectives_idx` (`AdTypeId`),
  CONSTRAINT `ActionTypes_AdGroupObjectives` FOREIGN KEY (`ActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdGroup_AdGroupObjectives` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdTypeId_AdGroupObjectives` FOREIGN KEY (`AdTypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ObjectiveTypeId_AdGroupObjectives` FOREIGN KEY (`ObjectiveTypeId`) REFERENCES `adgroupobjectivetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=240601 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupobjectivetypeactions`
--

DROP TABLE IF EXISTS `adgroupobjectivetypeactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupobjectivetypeactions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupObjectiveTypeId` int(11) DEFAULT NULL,
  `AdActionTypeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `AdGroupActionId_AdGroupObjectiveTypeActions` (`AdActionTypeId`),
  KEY `AdGroupObjectiveTypes_AdGroupObjectiveTypeActions` (`AdGroupObjectiveTypeId`),
  CONSTRAINT `AdGroupActionId_AdGroupObjectiveTypeActions` FOREIGN KEY (`AdActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdGroupObjectiveTypes_AdGroupObjectiveTypeActions` FOREIGN KEY (`AdGroupObjectiveTypeId`) REFERENCES `adgroupobjectivetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupobjectivetypes`
--

DROP TABLE IF EXISTS `adgroupobjectivetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupobjectivetypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` tinyint(4) NOT NULL,
  `DescrptionId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `LocalixedString_AdGroupObjectiveType` (`NameId`),
  KEY `LocalixedString_DescrptionId` (`DescrptionId`),
  CONSTRAINT `LocalixedString_AdGroupObjectiveType` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `LocalixedString_DescrptionId` FOREIGN KEY (`DescrptionId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroups`
--

DROP TABLE IF EXISTS `adgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroups` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UniqueId` varchar(36) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `CampaignId` int(11) NOT NULL,
  `Bid` decimal(21,12) DEFAULT NULL,
  `AudianceDiscountPrice` decimal(21,12) DEFAULT NULL,
  `DataPrice` decimal(21,12) DEFAULT NULL,
  `MaxDataPrice` decimal(21,12) DEFAULT NULL,
  `Budget` decimal(21,12) DEFAULT NULL,
  `DailyBudget` decimal(21,12) DEFAULT NULL,
  `MinimumUnitPrice` decimal(21,12) NOT NULL,
  `Pacing` tinyint(4) DEFAULT 0,
  `StatusId` int(11) DEFAULT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `CostModelWrapperId` int(11) DEFAULT NULL,
  `DisableProxyTraffic` bit(1) DEFAULT b'0',
  `CPMValue` decimal(21,12) DEFAULT NULL,
  `TrackInstalls` bit(1) DEFAULT b'0',
  `IsDefaultPrerequisitesSaved` bit(1) DEFAULT b'0',
  `IsCostModelChanged` bit(1) NOT NULL DEFAULT b'0',
  `OpenInExternalBrowser` bit(1) DEFAULT b'0',
  `AllowOpenAuction` bit(1) DEFAULT b'1',
  `StickToDealBidFloor` bit(1) DEFAULT b'1',
  `MinViewability` float DEFAULT NULL,
  `ViewabilityVendorId` int(11) DEFAULT NULL,
  `DisableViewabilityVendors` bit(1) DEFAULT b'0',
  `IgnoreDailyBudget` bit(1) DEFAULT b'0',
  `ConnectionType` tinyint(4) DEFAULT NULL COMMENT '1 - WiFi\n2 - Cellular',
  `LogAdMarkup` bit(1) NOT NULL DEFAULT b'0',
  `RunAllExchanges` bit(1) DEFAULT b'0',
  `BiddingStrategy` tinyint(4) DEFAULT 1 COMMENT '1 - Fixed\n2 - Dynamic',
  `AdPosition` tinyint(4) DEFAULT NULL,
  `AttributionType` tinyint(4) DEFAULT NULL COMMENT '1 - AttributeToClick\n2 - AttributeToClickOrImpression',
  `ImpressionAttributionWindow` int(11) DEFAULT NULL,
  `ClickAttributionWindow` int(11) DEFAULT NULL,
  `ConversionSetting` tinyint(4) DEFAULT NULL,
  `CountingTypeAttribuation` tinyint(4) DEFAULT 1,
  `CountingAttribuation` int(11) DEFAULT NULL,
  `AllowAllGeoTypeSources` bit(1) DEFAULT b'0',
  `IsDeleted` tinyint(1) DEFAULT 0,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UniqueId_UNIQUE` (`UniqueId`),
  KEY `Campaign_AdGroup` (`CampaignId`),
  KEY `AdGroup_CostModelWrapper_idx` (`CostModelWrapperId`),
  KEY `adgroups_viewabilityvendors_fk_idx` (`ViewabilityVendorId`),
  CONSTRAINT `AdGroup_CostModelWrapper` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Campaign_AdGroup` FOREIGN KEY (`CampaignId`) REFERENCES `campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `adgroups_viewabilityvendors_fk` FOREIGN KEY (`ViewabilityVendorId`) REFERENCES `viewability_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=240601 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupshourlyspend`
--

DROP TABLE IF EXISTS `adgroupshourlyspend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupshourlyspend` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `DateId` int(11) NOT NULL,
  `HourId` int(11) NOT NULL,
  `TotalSpend` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `NeedSync` tinyint(1) NOT NULL DEFAULT 0,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AdGroupId`,`DateId`,`HourId`),
  KEY `AdGroups_Key` (`AdGroupId`),
  CONSTRAINT `AdGroups_FK` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=466775 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupsperformance`
--

DROP TABLE IF EXISTS `adgroupsperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupsperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Spend` decimal(21,12) DEFAULT 0.000000000000,
  `DataSpend` decimal(21,12) DEFAULT 0.000000000000,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `TotalSpend` decimal(21,12) GENERATED ALWAYS AS (`Spend` + `DataSpend`) VIRTUAL,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  `Metrics` blob DEFAULT NULL,
  `Conversions` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AdGroupId`,`Day`),
  KEY `AdGroups_FK` (`AdGroupId`)
) ENGINE=InnoDB AUTO_INCREMENT=6293734 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupstatus`
--

DROP TABLE IF EXISTS `adgroupstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupstatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `LocalizedStringIDs_AdGroupStatus` (`NameId`),
  CONSTRAINT `LocalizedStringIDs_AdGroupStatus` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adgroupstotalspend`
--

DROP TABLE IF EXISTS `adgroupstotalspend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adgroupstotalspend` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) NOT NULL,
  `TotalSpend` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `NeedSync` tinyint(1) NOT NULL DEFAULT 1,
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AdGroupId`)
) ENGINE=InnoDB AUTO_INCREMENT=89578 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adrequest_types_platforms_mapping`
--

DROP TABLE IF EXISTS `adrequest_types_platforms_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adrequest_types_platforms_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Version` varchar(255) NOT NULL,
  `AdRequestPlatformId` int(11) NOT NULL,
  `AdRequestTypeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `adrequest_types_platforms_mapping` (`Id`),
  KEY `AdRequestPlatform_FK` (`AdRequestPlatformId`),
  KEY `AdRequestType_FK` (`AdRequestTypeId`),
  CONSTRAINT `AdRequestPlatform_FK` FOREIGN KEY (`AdRequestPlatformId`) REFERENCES `adrequest_version_platforms` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdRequestType_FK` FOREIGN KEY (`AdRequestTypeId`) REFERENCES `adrequest_version_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=79929 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adrequest_version_platforms`
--

DROP TABLE IF EXISTS `adrequest_version_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adrequest_version_platforms` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(5) NOT NULL,
  `Description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `lookup_fkPlatformVersion` (`NameId`),
  CONSTRAINT `lookup_fkPlatformVersion` FOREIGN KEY (`NameId`) REFERENCES `localizedstrings` (`LocalizedStringID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adrequest_version_targetings`
--

DROP TABLE IF EXISTS `adrequest_version_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adrequest_version_targetings` (
  `Id` int(11) NOT NULL,
  `RequestVersionTypeId` int(11) NOT NULL,
  `RequestVersionPlatformId` int(11) NOT NULL,
  `MinimumVersion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `requestversiontargetings_requestversiontypes_fk_idx` (`RequestVersionTypeId`),
  KEY `requestversiontargetings_requestversionplatforms_fk_idx` (`RequestVersionPlatformId`),
  CONSTRAINT `requestversiontargetings_requestversionplatforms_fk` FOREIGN KEY (`RequestVersionPlatformId`) REFERENCES `adrequest_version_platforms` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `requestversiontargetings_requestversiontypes_fk` FOREIGN KEY (`RequestVersionTypeId`) REFERENCES `adrequest_version_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adrequest_version_types`
--

DROP TABLE IF EXISTS `adrequest_version_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adrequest_version_types` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(5) NOT NULL,
  `Description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `lookup_fkVersionType` (`NameId`),
  CONSTRAINT `lookup_fkVersionType` FOREIGN KEY (`NameId`) REFERENCES `localizedstrings` (`LocalizedStringID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `uId` varchar(36) NOT NULL,
  `AdGroupId` int(11) NOT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `Name` varchar(255) NOT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `StatusId` int(11) NOT NULL,
  `PausedStatusId` int(11) DEFAULT NULL,
  `Bid` decimal(21,12) DEFAULT 0.000000000000,
  `TypeId` int(11) NOT NULL,
  `SubTypeId` tinyint(4) DEFAULT NULL COMMENT '1 - Expandable Rich Media\n2 - JavaScript Rich Media\n3 - JavaScript Interstitial\n4 - External Url Interstitial',
  `TypeIdForPortal` int(11) DEFAULT NULL,
  `SubTypeIdForPortal` tinyint(4) DEFAULT NULL,
  `EnvironmentTypeId` tinyint(4) DEFAULT NULL COMMENT '1 - Web, 2 - App',
  `OrientationTypeId` int(11) DEFAULT NULL,
  `LanguageId` int(11) DEFAULT 1,
  `bannerType` tinyint(4) DEFAULT 1,
  `TileImageId` int(11) DEFAULT NULL,
  `AdText` varchar(40) DEFAULT NULL,
  `KeywordId` int(11) DEFAULT NULL,
  `DomainURL` varchar(1024) DEFAULT NULL,
  `IsSecureCompliant` bit(1) DEFAULT b'0',
  `AppStoreId` varchar(100) DEFAULT NULL,
  `ValidateRequestDeviceAndLocationData` bit(1) DEFAULT b'0',
  `VerifyTargetingCriteria` bit(1) DEFAULT b'1',
  `VerifyStartAndEndDate` bit(1) DEFAULT b'1',
  `VerifyDailyBudget` bit(1) DEFAULT b'1',
  `VerifyPrerequisiteEvents` bit(1) DEFAULT b'1',
  `VerifyEventsFrequency` bit(1) DEFAULT b'1',
  `UpdateEventsFrequency` bit(1) DEFAULT b'1',
  `UpdateAudienceList` bit(1) DEFAULT b'1',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdGroup` (`AdGroupId`),
  KEY `AdStatus` (`StatusId`),
  KEY `AdType` (`TypeId`),
  KEY `Bid` (`Bid`),
  KEY `TileImageId_TileImages` (`TileImageId`),
  KEY `PausedStatusId_FK` (`PausedStatusId`),
  KEY `Kewords_FK` (`KeywordId`),
  KEY `OrientationType_FK` (`OrientationTypeId`),
  KEY `ads_ads_fk_idx` (`ParentId`),
  CONSTRAINT `AdGroup_FK` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdType_FK` FOREIGN KEY (`TypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Adstatus_FK` FOREIGN KEY (`StatusId`) REFERENCES `adstatus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Kewords_FK` FOREIGN KEY (`KeywordId`) REFERENCES `keywords` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `OrientationType_FK` FOREIGN KEY (`OrientationTypeId`) REFERENCES `device_orientations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `PausedStatusId_FK` FOREIGN KEY (`PausedStatusId`) REFERENCES `adstatus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `TileImageId_TileImages` FOREIGN KEY (`TileImageId`) REFERENCES `tileimages` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ads_ads_fk` FOREIGN KEY (`ParentId`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=270283 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adserver_broadcast_receivers`
--

DROP TABLE IF EXISTS `adserver_broadcast_receivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adserver_broadcast_receivers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BroadcastReceiverServiceUrl` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adserver_failed_broadcast_entity_updates`
--

DROP TABLE IF EXISTS `adserver_failed_broadcast_entity_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adserver_failed_broadcast_entity_updates` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EntityType` smallint(6) NOT NULL,
  `EntityIdentifier` varchar(5000) DEFAULT NULL,
  `BroadcastReceiverId` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `failed_broadcast_entity_updates_broadcast_receivers_FK` (`BroadcastReceiverId`),
  CONSTRAINT `failed_broadcast_entity_updates_broadcast_receivers_FK` FOREIGN KEY (`BroadcastReceiverId`) REFERENCES `adserver_broadcast_receivers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adserver_maintenance_job_closed_dates`
--

DROP TABLE IF EXISTS `adserver_maintenance_job_closed_dates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adserver_maintenance_job_closed_dates` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Type` int(11) NOT NULL,
  `LastClosedDate` datetime NOT NULL,
  `Description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adsperformance`
--

DROP TABLE IF EXISTS `adsperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adsperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Spend` decimal(21,12) DEFAULT 0.000000000000,
  `DataSpend` decimal(21,12) DEFAULT 0.000000000000,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `TotalSpend` decimal(21,12) GENERATED ALWAYS AS (`Spend` + `DataSpend`) VIRTUAL,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  `Metrics` blob DEFAULT NULL,
  `Conversions` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Uniquekey` (`AdId`,`Day`)
) ENGINE=InnoDB AUTO_INCREMENT=30445756 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adstatus`
--

DROP TABLE IF EXISTS `adstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adstatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `NameId` (`NameId`),
  CONSTRAINT `NameId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adsubtypes`
--

DROP TABLE IF EXISTS `adsubtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adsubtypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` int(11) NOT NULL,
  `AdTypeId` int(11) NOT NULL,
  `PermissionId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`),
  KEY `adtype_subtype_fk_idx` (`AdTypeId`),
  KEY `lookup_subtype_fk_idx` (`NameId`),
  CONSTRAINT `adtype_subtype_fk` FOREIGN KEY (`AdTypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_subtype_fk` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adtypeactions`
--

DROP TABLE IF EXISTS `adtypeactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adtypeactions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeId` int(11) NOT NULL,
  `AdActionTypeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `AdTypeIds_idx` (`AdTypeId`),
  KEY `AdActionTypes_idx` (`AdActionTypeId`),
  CONSTRAINT `AdActionTypes` FOREIGN KEY (`AdActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdTypeIds` FOREIGN KEY (`AdTypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adtypeperformance`
--

DROP TABLE IF EXISTS `adtypeperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adtypeperformance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dayid` int(11) NOT NULL,
  `pubaccountid` int(11) NOT NULL,
  `appsiteid` int(11) NOT NULL,
  `adtypegroupid` int(11) NOT NULL,
  `requests` bigint(20) DEFAULT NULL,
  `filledrequests` bigint(20) DEFAULT NULL,
  `wins` bigint(20) DEFAULT NULL,
  `impressions` bigint(20) DEFAULT NULL,
  `clicks` bigint(20) DEFAULT NULL,
  `conversions` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_UniqueKey` (`dayid`,`pubaccountid`,`appsiteid`,`adtypegroupid`)
) ENGINE=InnoDB AUTO_INCREMENT=1003465 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adtypes`
--

DROP TABLE IF EXISTS `adtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adtypes` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` char(3) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `PermissionId` int(11) DEFAULT NULL,
  `AdTypeGroup` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Banner=1,\nNative=2,\nInstream=3',
  PRIMARY KEY (`Id`),
  KEY `AdType_LocalizedStringId` (`NameId`),
  KEY `AdType_Permission_fk_idx` (`PermissionId`),
  CONSTRAINT `AdType_LocalizedStringId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AdType_Permission_fk` FOREIGN KEY (`PermissionId`) REFERENCES `permissions` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advertiser_account`
--

DROP TABLE IF EXISTS `advertiser_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertiser_account` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `UserId` int(11) DEFAULT NULL,
  `AdvertiserId` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `IsRestricted` bit(1) DEFAULT b'0',
  `AgencyCommissionModel` tinyint(4) DEFAULT NULL,
  `AgencyCommissionModelValue` decimal(21,12) DEFAULT NULL,
  `ODCZoneName` varchar(200) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `advertiser_account_user_idx` (`UserId`),
  KEY `advertiser_account_idx` (`AccountId`),
  KEY `advertiser_account_advertiser_idx` (`AdvertiserId`),
  CONSTRAINT `advertiser_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `advertiser_account_advertiser` FOREIGN KEY (`AdvertiserId`) REFERENCES `advertisers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `advertiser_account_user` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=160900 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advertiser_account_assignment`
--

DROP TABLE IF EXISTS `advertiser_account_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertiser_account_assignment` (
  `Id` int(11) NOT NULL,
  `InvitationId` int(11) DEFAULT NULL,
  `AssociationId` int(11) NOT NULL,
  `IsRead` bit(1) DEFAULT NULL,
  `IsWrite` bit(1) DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `advertiser_account_assignment_User_idx` (`UserId`),
  KEY `advertiser_account_assignment_adver_idx` (`AssociationId`),
  KEY `advertiser_account_ass_adv_inv` (`InvitationId`),
  CONSTRAINT `advertiser_account_ass_adv_inv` FOREIGN KEY (`InvitationId`) REFERENCES `account_invitation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `advertiser_account_assignment_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `advertiser_account_assignment_adver` FOREIGN KEY (`AssociationId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advertisers`
--

DROP TABLE IF EXISTS `advertisers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisers` (
  `Id` int(11) NOT NULL,
  `UniqueId` varchar(36) DEFAULT NULL,
  `NameId` int(11) NOT NULL,
  `DomainURL` varchar(1024) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UniqueId_UNIQUE` (`UniqueId`),
  KEY `lookup_advertiser_FK` (`NameId`),
  CONSTRAINT `lookup_advertiser_FK` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advertisersperformance`
--

DROP TABLE IF EXISTS `advertisersperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisersperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdvertiserAssociationId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Spend` decimal(21,12) DEFAULT 0.000000000000,
  `DataSpend` decimal(21,12) DEFAULT 0.000000000000,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  `Metrics` blob DEFAULT NULL,
  `Conversions` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AdvertiserAssociationId`,`Day`)
) ENGINE=InnoDB AUTO_INCREMENT=158650 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agegroup`
--

DROP TABLE IF EXISTS `agegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agegroup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NameID` int(11) NOT NULL,
  `MinValue` tinyint(4) NOT NULL,
  `MaxValue` tinyint(4) NOT NULL,
  `Id_Hex` varchar(7) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Id_Hex_UNIQUE` (`Id_Hex`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_marketing_partner_trackers`
--

DROP TABLE IF EXISTS `app_marketing_partner_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_marketing_partner_trackers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppMarketingPartnerId` int(11) NOT NULL,
  `AdGroupId` int(11) DEFAULT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `Type` tinyint(4) NOT NULL COMMENT '1 - ClickTracker\n2 - BillableEvent\n3 - Event\n4 - Other',
  `EventCode` varchar(6) DEFAULT NULL,
  `TrackerUrlTemplate` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `appmarketingpartnertrackers_appmarketingpartners_fk_idx` (`AppMarketingPartnerId`),
  KEY `appmarketingpartnertrackers_platforms_fk_idx` (`PlatformId`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_marketing_partners`
--

DROP TABLE IF EXISTS `app_marketing_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_marketing_partners` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) DEFAULT NULL,
  `Code` varchar(10) DEFAULT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `appmarketingpartners_appsites_fk_idx` (`AppSiteId`),
  KEY `lookup_fk_idx` (`NameId`),
  CONSTRAINT `appmarketingpartners_appsites_fk` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_fk` FOREIGN KEY (`NameId`) REFERENCES `localizedstrings` (`LocalizedStringID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite`
--

DROP TABLE IF EXISTS `appsite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite` (
  `Id` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `PublisherId` varchar(64) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `RegistrationDate` datetime DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `TypeId` int(11) DEFAULT NULL,
  `ThemeId` int(11) DEFAULT NULL,
  `IsUseLocation` bit(1) DEFAULT b'0',
  `URL` varchar(1024) DEFAULT NULL,
  `DomainURL` varchar(1024) DEFAULT NULL,
  `SubType` tinyint(4) DEFAULT NULL,
  `IsContainer` bit(1) NOT NULL DEFAULT b'0',
  `IsApp` bit(1) DEFAULT b'0',
  `IsPublished` bit(1) DEFAULT b'0',
  `BundleId` varchar(100) DEFAULT NULL,
  `StoreId` varchar(100) DEFAULT NULL,
  `AdminComments` varchar(5000) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `UserId` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Publisher` (`PublisherId`),
  KEY `Status` (`StatusId`),
  KEY `Type` (`TypeId`),
  KEY `Theme` (`ThemeId`),
  CONSTRAINT `Status` FOREIGN KEY (`StatusId`) REFERENCES `appsitestatus` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Theme` FOREIGN KEY (`ThemeId`) REFERENCES `textadthemes` (`TextAdThemeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Type` FOREIGN KEY (`TypeId`) REFERENCES `appsitetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite_ad_queue`
--

DROP TABLE IF EXISTS `appsite_ad_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite_ad_queue` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AppsiteId` int(11) NOT NULL,
  `AdId` int(11) NOT NULL,
  `bid` decimal(21,12) NOT NULL,
  `Include` bit(1) DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `IX_BID_APP` (`bid`,`AppsiteId`) USING BTREE,
  KEY `IX_ADID` (`AdId`,`AppsiteId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1838101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite_adserver_settings`
--

DROP TABLE IF EXISTS `appsite_adserver_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite_adserver_settings` (
  `AppsiteId` int(11) NOT NULL,
  `AllowBlindAds` bit(1) DEFAULT b'1',
  `GenerateSystemUniqueId` bit(1) DEFAULT b'1',
  `ImpressionCountMode` tinyint(4) DEFAULT 0,
  `SupportedAdTypes` varchar(20) DEFAULT NULL,
  `SupportedBannerImageTypes` varchar(30) DEFAULT NULL,
  `WatchTraffic` bit(1) DEFAULT b'0',
  `DontStoreUserData` bit(1) DEFAULT b'0',
  `AdRequestCachedDataLifeTime` int(11) DEFAULT NULL,
  `NativeAdLayoutId` int(11) DEFAULT NULL,
  `RewardedVideoItemName` varchar(50) DEFAULT NULL,
  `RewardedVideoItemValue` int(11) DEFAULT NULL,
  `VastExcludedExtensions` varchar(20) DEFAULT NULL COMMENT '1 - AdFalcon extension\n2 - Custom tracking extension\n3 - Moat viewability extension (MVE)',
  `PlacementType` int(11) DEFAULT NULL,
  PRIMARY KEY (`AppsiteId`),
  KEY `appsite_adserver_settings_native_ad_layouts_fk_idx` (`NativeAdLayoutId`),
  CONSTRAINT `appsite_adserver_settings_native_ad_layouts_fk` FOREIGN KEY (`NativeAdLayoutId`) REFERENCES `native_ad_layouts` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite_events`
--

DROP TABLE IF EXISTS `appsite_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite_events` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `AdEventDefinitionId` int(11) NOT NULL,
  `IsBillable` bit(1) DEFAULT NULL,
  `MinBid` decimal(21,12) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`AppSiteId`,`AdEventDefinitionId`),
  KEY `appsiteevents_appsite_idx` (`AppSiteId`),
  KEY `appsiteevents_adeventsdefinition_idx` (`AdEventDefinitionId`),
  CONSTRAINT `appsiteevents_adeventsdefinition` FOREIGN KEY (`AdEventDefinitionId`) REFERENCES `ad_events_definition` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `appsiteevents_appsite` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5863 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite_revenue_calculation_modes`
--

DROP TABLE IF EXISTS `appsite_revenue_calculation_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite_revenue_calculation_modes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `CalculationModeType` tinyint(4) DEFAULT NULL COMMENT '1 - Percentage, 2- Fixed value',
  `Value` decimal(21,12) NOT NULL,
  `FromDate` datetime NOT NULL,
  `ToDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Appsite_FK` (`AppSiteId`)
) ENGINE=InnoDB AUTO_INCREMENT=22642 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsite_thirdparty_info`
--

DROP TABLE IF EXISTS `appsite_thirdparty_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsite_thirdparty_info` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppsiteId` int(11) NOT NULL,
  `ThirdPartyId` int(11) NOT NULL,
  `TrackingId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AppsiteId`,`ThirdPartyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitekeywords`
--

DROP TABLE IF EXISTS `appsitekeywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitekeywords` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `KeywordId` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `unique_key` (`AppSiteId`,`KeywordId`),
  KEY `appSite` (`AppSiteId`),
  KEY `Keyword` (`KeywordId`),
  CONSTRAINT `appSite` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=66262 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsiterefreshmodes`
--

DROP TABLE IF EXISTS `appsiterefreshmodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsiterefreshmodes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `NameId` (`NameId`),
  CONSTRAINT `appsiterefreshmodes_ibfk_1` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitesettings`
--

DROP TABLE IF EXISTS `appsitesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitesettings` (
  `AppSiteId` int(11) NOT NULL,
  `TestingModeId` int(11) DEFAULT NULL,
  `RefreshInterval` int(11) DEFAULT NULL,
  `RefreshModeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`AppSiteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitesperformance`
--

DROP TABLE IF EXISTS `appsitesperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitesperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `CampaignType` tinyint(4) DEFAULT NULL,
  `Revenue` decimal(21,12) DEFAULT 0.000000000000,
  `Requests` int(11) DEFAULT 0,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AppSiteId`,`Day`,`CampaignType`),
  KEY `Appsite_FK` (`AppSiteId`)
) ENGINE=InnoDB AUTO_INCREMENT=19444885 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitestatus`
--

DROP TABLE IF EXISTS `appsitestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitestatus` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NameID` int(11) DEFAULT NULL,
  `Code` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `f` (`NameID`),
  CONSTRAINT `f` FOREIGN KEY (`NameID`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitetextadthemes`
--

DROP TABLE IF EXISTS `appsitetextadthemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitetextadthemes` (
  `idAppSiteTextAdThemes` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) DEFAULT NULL,
  `TextAdThemeID` int(11) DEFAULT NULL,
  PRIMARY KEY (`idAppSiteTextAdThemes`),
  KEY `TextAdThemeAppSite_AppSite` (`AppSiteId`),
  KEY `TextAdThemeAppSite_TextAdTheme` (`TextAdThemeID`),
  CONSTRAINT `TextAdThemeAppSite_AppSite` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `TextAdThemeAppSite_TextAdTheme` FOREIGN KEY (`TextAdThemeID`) REFERENCES `textadthemes` (`TextAdThemeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appsitetypes`
--

DROP TABLE IF EXISTS `appsitetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appsitetypes` (
  `Id` int(11) NOT NULL,
  `NameID` int(11) NOT NULL,
  `IconURL` varchar(255) DEFAULT NULL,
  `IsThemeable` tinyint(1) DEFAULT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `ViewName` varchar(45) DEFAULT NULL,
  `IsApp` tinyint(1) DEFAULT 0,
  `Code` tinyint(4) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audience_list_bins_occupation`
--

DROP TABLE IF EXISTS `audience_list_bins_occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audience_list_bins_occupation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BinIndex` tinyint(4) NOT NULL,
  `NumberOfSegments` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audience_segment_targetings`
--

DROP TABLE IF EXISTS `audience_segment_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audience_segment_targetings` (
  `Id` int(11) NOT NULL,
  `RulesJson` mediumtext NOT NULL,
  `DataPrice` decimal(21,12) DEFAULT NULL,
  `MaxDataPrice` decimal(21,12) DEFAULT NULL,
  `IsExternal` bit(1) DEFAULT b'0',
  `DataProviderId` int(11) DEFAULT NULL,
  `LogAdMarkup` bit(1) DEFAULT b'0',
  `Category` int(11) NOT NULL DEFAULT 0,
  `Options` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `audiencesegmenttargeting_DProvider_FK` (`DataProviderId`),
  CONSTRAINT `audiancesegmenttargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `audiencesegmenttargeting_DProvider_FK` FOREIGN KEY (`DataProviderId`) REFERENCES `dp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audience_segments`
--

DROP TABLE IF EXISTS `audience_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audience_segments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Type` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - Audience\n2- Contextual',
  `ProviderId` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `AdvertiserAccId` int(11) DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `SegmentCode` int(11) NOT NULL,
  `OperatorSegmentCode` varchar(200) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `Price` decimal(21,12) DEFAULT NULL,
  `Selectable` bit(1) NOT NULL DEFAULT b'1',
  `Activated` bit(1) NOT NULL DEFAULT b'0',
  `IsPermissionNeed` bit(1) DEFAULT b'0',
  `CostModelId` int(11) DEFAULT NULL,
  `BillCat` tinyint(4) DEFAULT NULL,
  `BinIndex` tinyint(4) DEFAULT NULL COMMENT 'From 1 to 100',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `SegmentCode_UNIQUE` (`SegmentCode`),
  UNIQUE KEY `ProviderId_OperatorSegmentCode_UNIQUE` (`ProviderId`,`OperatorSegmentCode`),
  KEY `AudienceSegment_Child` (`ParentId`),
  KEY `AudienceSegment_AdvertisrAcc_FK` (`AdvertiserAccId`),
  KEY `AudienceSegment_Account` (`AccountId`),
  KEY `AudienceSegment_CostMode` (`CostModelId`),
  KEY `AudienceSegment_User` (`UserId`),
  KEY `AudienceSegment_BusinessPartner_idx` (`ProviderId`),
  CONSTRAINT `AudienceSegment_Account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AudienceSegment_AdvertisrAcc_FK` FOREIGN KEY (`AdvertiserAccId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AudienceSegment_BusinessPartner` FOREIGN KEY (`ProviderId`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AudienceSegment_CostMode` FOREIGN KEY (`CostModelId`) REFERENCES `costmodels` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `AudienceSegment_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `audienceSeg_ParentChild` FOREIGN KEY (`ParentId`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=57472 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audience_segments_performance`
--

DROP TABLE IF EXISTS `audience_segments_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audience_segments_performance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AudienceSegmentId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Hits` int(11) DEFAULT 0,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`AudienceSegmentId`,`Day`)
) ENGINE=InnoDB AUTO_INCREMENT=22735 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audience_segments_unique_users`
--

DROP TABLE IF EXISTS `audience_segments_unique_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audience_segments_unique_users` (
  `audiencesegmentid` int(11) NOT NULL,
  `unique_users` bigint(8) NOT NULL DEFAULT 0,
  PRIMARY KEY (`audiencesegmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audittrials`
--

DROP TABLE IF EXISTS `audittrials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audittrials` (
  `AuditTrialId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ObjectTypeID` int(11) NOT NULL,
  `ObjectActionId` int(11) NOT NULL,
  `ObjectId` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `ActionTime` datetime NOT NULL,
  `Details` longtext NOT NULL,
  `SessionId` varbinary(16) DEFAULT NULL,
  `RootObjectId` int(11) DEFAULT NULL,
  PRIMARY KEY (`AuditTrialId`),
  UNIQUE KEY `AuditTrialId_UNIQUE` (`AuditTrialId`)
) ENGINE=InnoDB AUTO_INCREMENT=8166976 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audittrialsessionstat`
--

DROP TABLE IF EXISTS `audittrialsessionstat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audittrialsessionstat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varbinary(16) NOT NULL,
  `ids` varchar(500) NOT NULL,
  `actiontime` datetime NOT NULL,
  `user` int(11) NOT NULL,
  `RootObjectId` int(11) DEFAULT NULL,
  `RootObjectTypeId` int(11) DEFAULT NULL,
  `AccountId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1693651 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audittrialstat`
--

DROP TABLE IF EXISTS `audittrialstat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audittrialstat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LastActionTime` datetime NOT NULL,
  `RootObjectId` int(11) NOT NULL,
  `RootObjectTypeId` int(11) NOT NULL,
  `LastUser` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=43792 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account_payment_details`
--

DROP TABLE IF EXISTS `bank_account_payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account_payment_details` (
  `Id` int(11) NOT NULL,
  `BankAddress` varchar(255) DEFAULT NULL,
  `BankName` varchar(64) DEFAULT NULL,
  `BeneficiaryName` varchar(128) NOT NULL,
  `RecipientAccountNumber` varchar(128) DEFAULT NULL,
  `SWIFT` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bankaccount`
--

DROP TABLE IF EXISTS `bankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankaccount` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `BankAddress` varchar(255) NOT NULL,
  `BankName` varchar(64) NOT NULL,
  `BeneficiaryName` varchar(128) NOT NULL,
  `RecipientAccountNumber` varchar(128) DEFAULT NULL,
  `SWIFT` varchar(128) NOT NULL,
  `IsActive` bit(1) DEFAULT b'1',
  `ActiveFrom` datetime DEFAULT NULL,
  `ActiveTo` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=34241 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bannersizes`
--

DROP TABLE IF EXISTS `bannersizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bannersizes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Description` varchar(512) DEFAULT NULL,
  `Width` tinyint(4) NOT NULL,
  `Height` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bc_billing_entity_spend_details`
--

DROP TABLE IF EXISTS `bc_billing_entity_spend_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_billing_entity_spend_details` (
  `AccountKey` varchar(40) NOT NULL,
  `BillingEntityID` int(11) NOT NULL,
  `BillingEntityType` int(11) NOT NULL,
  `ClosedDate` datetime DEFAULT NULL,
  `ActivationDate` datetime NOT NULL,
  `Spend` decimal(21,12) NOT NULL,
  `TodaySpend` decimal(21,12) NOT NULL,
  `SpendAdjustment` bigint(20) NOT NULL,
  `TodaySpendAdjustment` bigint(20) NOT NULL,
  `MostRecentEpoch` bigint(20) NOT NULL,
  `SpendEntries` varchar(2000) DEFAULT NULL,
  `BillingEntityStatus` int(11) NOT NULL,
  `CloseReason` int(11) DEFAULT NULL,
  `OverSpend` decimal(21,12) DEFAULT NULL,
  PRIMARY KEY (`BillingEntityID`,`BillingEntityType`),
  UNIQUE KEY `UNIQUE_IX` (`BillingEntityID`,`BillingEntityType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bid_authorize_timeouts`
--

DROP TABLE IF EXISTS `bid_authorize_timeouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bid_authorize_timeouts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeFormatId` tinyint(4) NOT NULL COMMENT '1 - Display\n2 - Video\n3 - Native\n4 - Interstitial',
  `IsRTB` bit(1) NOT NULL,
  `BillableEventCode` varchar(6) NOT NULL,
  `Timeout` varchar(12) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`AdTypeFormatId`,`IsRTB`,`BillableEventCode`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bid_extend_timeouts`
--

DROP TABLE IF EXISTS `bid_extend_timeouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bid_extend_timeouts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EventCode` varchar(6) NOT NULL,
  `BillableEventCode` varchar(6) NOT NULL,
  `Timeout` varchar(12) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`EventCode`,`BillableEventCode`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bidconfig`
--

DROP TABLE IF EXISTS `bidconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bidconfig` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TypeId` tinyint(4) NOT NULL,
  `TargetingId` int(11) NOT NULL DEFAULT -1,
  `Value` tinyint(4) NOT NULL DEFAULT 0,
  `CostModelWrapperId` int(11) NOT NULL,
  `AppScope` int(11) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `BidConfig_CostModelWrappers_idx` (`CostModelWrapperId`),
  CONSTRAINT `BidConfig_CostModelWrappers` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blackberryvendors`
--

DROP TABLE IF EXISTS `blackberryvendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blackberryvendors` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VendorId` varchar(100) NOT NULL,
  `OperatorId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `VendorId_UNIQUE` (`VendorId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_urls`
--

DROP TABLE IF EXISTS `blocked_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_urls` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Url` varchar(500) CHARACTER SET ascii NOT NULL,
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Url_UNIQUE` (`Url`)
) ENGINE=InnoDB AUTO_INCREMENT=39572 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bridge_impression_vendors`
--

DROP TABLE IF EXISTS `bridge_impression_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bridge_impression_vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ImpressionMetricId` int(11) NOT NULL,
  `MetricVendorId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `impressionmetrictargetings_impressionmetrics_fk_idx` (`ImpressionMetricId`),
  KEY `impressionmetrictargetings_metricvendors_fk_idx` (`MetricVendorId`),
  KEY `bridge_impressionmetrics_vendors_fk_idx` (`ImpressionMetricId`),
  KEY `bridge_vendors_impressionmetrics_fk_idx` (`MetricVendorId`),
  CONSTRAINT `bridge_impressionmetrics_vendors_fk` FOREIGN KEY (`ImpressionMetricId`) REFERENCES `impression_metrics` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_vendors_impressionmetrics_fk` FOREIGN KEY (`MetricVendorId`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_partner_account_white`
--

DROP TABLE IF EXISTS `business_partner_account_white`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_partner_account_white` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `BusinessPartnerAccountWhite_BusinessPartners_FK_idx` (`PartnerId`),
  KEY `BusinessPartnerAccountWhite_Account_FK_idx` (`AccountId`),
  CONSTRAINT `BusinessPartnerAccountWhite_Account_FK` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `BusinessPartnerAccountWhite_BusinessPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_partner_advertiser_block`
--

DROP TABLE IF EXISTS `business_partner_advertiser_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_partner_advertiser_block` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `AdvertiserId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `BusinessPartnerAdvertiserBlock_BusinessPartners_FK_idx` (`PartnerId`),
  KEY `BusinessPartnerAdvertiserBlock_Advertiser_FK_idx` (`AdvertiserId`),
  CONSTRAINT `BusinessPartnerAdvertiserBlock_Advertiser_FK` FOREIGN KEY (`AdvertiserId`) REFERENCES `advertisers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `BusinessPartnerAdvertiserBlock_BusinessPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_partner_domain_block`
--

DROP TABLE IF EXISTS `business_partner_domain_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_partner_domain_block` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Domain` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `BusinessPartnerDomainBlock_BusinessPartners_FK_idx` (`PartnerId`),
  CONSTRAINT `BusinessPartnerDomainBlock_BusinessPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_partner_type`
--

DROP TABLE IF EXISTS `business_partner_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_partner_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `lookup_businesspartnertype_FK` (`NameId`),
  CONSTRAINT `lookup_businesspartnertype_FK` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_partners`
--

DROP TABLE IF EXISTS `business_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_partners` (
  `Id` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `TypeId` int(11) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `ICONID` int(11) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `ContactPerson` varchar(255) DEFAULT NULL,
  `CertPass` varchar(255) DEFAULT NULL,
  `CertPath` varchar(255) DEFAULT NULL,
  `APISiteProviderURL` varchar(255) DEFAULT NULL,
  `APISecret` varchar(255) DEFAULT NULL,
  `APIKey` varchar(255) DEFAULT NULL,
  `AllowImpressionTrackers` bit(1) DEFAULT b'0',
  `AdMarkupLogRequired` bit(1) DEFAULT b'0',
  `IsExternalProvider` bit(1) DEFAULT b'0',
  `HasAdvertiserBlock` bit(1) DEFAULT b'0',
  `HasAccountWhite` bit(1) DEFAULT b'0',
  `BlockedDomains` varchar(10000) DEFAULT NULL,
  `Order` int(11) DEFAULT 1,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `document_Business_ICON_idx` (`ICONID`),
  CONSTRAINT `businesspartners_party_fk` FOREIGN KEY (`Id`) REFERENCES `party` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `document_Business_ICON` FOREIGN KEY (`ICONID`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `buyer_deal_targetings`
--

DROP TABLE IF EXISTS `buyer_deal_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer_deal_targetings` (
  `Id` int(11) NOT NULL,
  `DealId` mediumint(4) unsigned NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `buyerdealtargetings_buyerdeals_fk` (`DealId`),
  CONSTRAINT `buyerdealtargetings_buyerdeals_fk` FOREIGN KEY (`DealId`) REFERENCES `buyer_deals` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `buyerdealtargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `buyer_deals`
--

DROP TABLE IF EXISTS `buyer_deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer_deals` (
  `Id` mediumint(4) unsigned NOT NULL,
  `UniqueId` bigint(20) NOT NULL,
  `Code` varchar(36) NOT NULL,
  `Name` varchar(128) NOT NULL,
  `ExchangeId` int(11) DEFAULT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `PublisherId` int(11) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `StartDate` datetime DEFAULT NULL,
  `EndDate` datetime DEFAULT NULL,
  `Price` decimal(21,12) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `TypeId` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Private Acuction=1,\nFixed=2',
  `Note` varchar(1024) DEFAULT NULL,
  `AssociationAdvId` int(11) DEFAULT NULL,
  `AdvertiserId` int(11) DEFAULT NULL,
  `IsGlobal` bit(1) DEFAULT b'0',
  `PublisherName` varchar(128) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE2` (`UniqueId`),
  UNIQUE KEY `IX_UNIQUE` (`Code`,`ExchangeId`),
  KEY `buyerdeals_publisher_FK` (`PublisherId`),
  KEY `buyerdeals_exchange_ssp_FK` (`ExchangeId`),
  KEY `buyerdeals_primary` (`Id`),
  KEY `buyerdeals_account_FK` (`AccountId`),
  KEY `buyerdeals_Advertiser_FK_idx` (`AdvertiserId`),
  KEY `lookup_buyerDeal_advertiserassco_fk_idx` (`AssociationAdvId`),
  CONSTRAINT `buyerdeals_Advertiser_FK` FOREIGN KEY (`AdvertiserId`) REFERENCES `advertisers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `buyerdeals_account_FK` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `buyerdeals_exchange_ssp_FK` FOREIGN KEY (`ExchangeId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `buyerdeals_publisher_FK` FOREIGN KEY (`PublisherId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_buyerDeal_advertiserassco_fk` FOREIGN KEY (`AssociationAdvId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `buyers`
--

DROP TABLE IF EXISTS `buyers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(6) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB AUTO_INCREMENT=1112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaign_adserver_settings`
--

DROP TABLE IF EXISTS `campaign_adserver_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_adserver_settings` (
  `CampaignId` int(11) NOT NULL,
  `AdRequestCachedDataLifeTime` int(11) DEFAULT NULL,
  `AgencyCommissionModel` tinyint(4) DEFAULT NULL,
  `AgencyCommissionModelValue` decimal(21,12) DEFAULT NULL,
  `CountImpressionFrequencyCappingOnRequest` bit(1) NOT NULL DEFAULT b'0',
  `UserLifetimeInDays` int(11) DEFAULT NULL,
  `TrackUnfilled` bit(1) DEFAULT b'0',
  PRIMARY KEY (`CampaignId`),
  CONSTRAINT `campaign_adserver_settings_campaigns_FK` FOREIGN KEY (`CampaignId`) REFERENCES `campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaign_bid_config`
--

DROP TABLE IF EXISTS `campaign_bid_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_bid_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CampaignId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `AppsiteId` int(11) DEFAULT NULL,
  `SubPublisherId` varchar(100) DEFAULT NULL,
  `Bid` decimal(21,12) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UNIQUE_KEY` (`CampaignId`,`AccountId`,`AppsiteId`,`SubPublisherId`),
  KEY `campaign_bid_config_account` (`AccountId`),
  KEY `campaign_bid_config_appsite` (`AppsiteId`),
  CONSTRAINT `campaign_bid_config_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaign_bid_config_appsite` FOREIGN KEY (`AppsiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaign_frequency_capping_settings`
--

DROP TABLE IF EXISTS `campaign_frequency_capping_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_frequency_capping_settings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CampaignId` int(11) NOT NULL,
  `AdGroupId` int(11) DEFAULT NULL,
  `AdEventDefinitionId` int(11) NOT NULL,
  `FrequencyCappingType` tinyint(4) NOT NULL,
  `FrequencyCappingNumber` int(11) NOT NULL,
  `FrequencyCappingInterval` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`CampaignId`,`AdEventDefinitionId`),
  KEY `campaignfrequencycappingsettings_campaigns_idx` (`CampaignId`),
  KEY `campaignfrequencycappingsettings_adeventsdefinition_idx` (`AdEventDefinitionId`),
  KEY `campaignfrequencycappingsettings_adgroups_idx` (`AdGroupId`),
  CONSTRAINT `campaignfrequencycappingsettings_adeventsdefinition` FOREIGN KEY (`AdEventDefinitionId`) REFERENCES `ad_events_definition` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaignfrequencycappingsettings_adgroups` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `campaignfrequencycappingsettings_campaigns` FOREIGN KEY (`CampaignId`) REFERENCES `campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=80302 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UniqueId` varchar(36) DEFAULT NULL,
  `Name` varchar(128) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `StartDate` datetime DEFAULT NULL,
  `EndDate` datetime DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Budget` decimal(21,12) DEFAULT NULL,
  `DailyBudget` decimal(21,12) DEFAULT NULL,
  `Discount` decimal(21,12) DEFAULT NULL,
  `DiscountType` tinyint(4) DEFAULT NULL,
  `DiscountFromDate` datetime DEFAULT NULL,
  `DiscountToDate` datetime DEFAULT NULL,
  `CPMValue` decimal(21,12) DEFAULT NULL,
  `isRuntime` bit(1) DEFAULT NULL,
  `CostModelWrapperId` tinyint(4) DEFAULT NULL,
  `IsClientLocked` bit(1) DEFAULT NULL,
  `KeywordId` int(11) DEFAULT NULL,
  `DomainURL` varchar(5000) DEFAULT NULL,
  `FolderURL` varchar(1024) DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `Note` varchar(1024) DEFAULT NULL,
  `TypeId` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Normal=1,\nHouse=2,\nProgrammatic Guaranteed = 3',
  `TrackConversions` bit(1) DEFAULT b'0',
  `AssociationAdvId` int(11) DEFAULT NULL,
  `AdvertiserId` int(11) DEFAULT NULL,
  `Pacing` tinyint(4) DEFAULT 0,
  `UserId` int(11) DEFAULT NULL,
  `PriceMode` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - Fixed\n2 - Dynamic',
  `LifeTime` tinyint(4) DEFAULT 1,
  `LogAdMarkup` bit(1) NOT NULL DEFAULT b'0',
  `IsDeleted` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Account_campaigns` (`AccountId`),
  KEY `Account_Campaingn` (`Id`),
  KEY `campaignstatus_campaigns` (`StatusId`),
  KEY `campaigns_Kewords_FK` (`KeywordId`),
  KEY `lookup_campaign_advertiser_fk` (`AdvertiserId`),
  KEY `lookup_campaign_advertiserassco_fk_idx` (`AssociationAdvId`),
  CONSTRAINT `campaigns_Kewords_FK` FOREIGN KEY (`KeywordId`) REFERENCES `keywords` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_campaign_advertiser_fk` FOREIGN KEY (`AdvertiserId`) REFERENCES `advertisers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lookup_campaign_advertiserassco_fk` FOREIGN KEY (`AssociationAdvId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=220999 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaignsperformance`
--

DROP TABLE IF EXISTS `campaignsperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaignsperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CampaignId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Spend` decimal(21,12) DEFAULT 0.000000000000,
  `DataSpend` decimal(21,12) DEFAULT 0.000000000000,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `TotalSpend` decimal(21,12) GENERATED ALWAYS AS (`Spend` + `DataSpend`) VIRTUAL,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  `Metrics` blob DEFAULT NULL,
  `Conversions` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`CampaignId`,`Day`),
  KEY `Campaigns_FK` (`CampaignId`)
) ENGINE=InnoDB AUTO_INCREMENT=3134251 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaignstatus`
--

DROP TABLE IF EXISTS `campaignstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaignstatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameID` int(11) DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `LoclizationId_CampaignStatus` (`NameID`),
  CONSTRAINT `LoclizationId_CampaignStatus` FOREIGN KEY (`NameID`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checked_urls`
--

DROP TABLE IF EXISTS `checked_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checked_urls` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Url` varchar(500) CHARACTER SET ascii NOT NULL,
  `AppsiteId` int(11) DEFAULT NULL,
  `StatusId` tinyint(4) NOT NULL COMMENT '0 - Clean\n1 - Blocked\n2 - Has Blocked Links',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Url_UNIQUE` (`Url`),
  KEY `IX` (`Url`)
) ENGINE=InnoDB AUTO_INCREMENT=107316 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city_name_to_code_mapping`
--

DROP TABLE IF EXISTS `city_name_to_code_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_name_to_code_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CountryCode` varchar(20) NOT NULL,
  `RegionCode_ISO` varchar(20) NOT NULL,
  `RegionCode_FIPS` varchar(20) NOT NULL,
  `CityName` varchar(200) NOT NULL,
  `CityCode` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`CountryCode`,`RegionCode_ISO`,`RegionCode_FIPS`,`CityName`)
) ENGINE=InnoDB AUTO_INCREMENT=4177 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `companion_ads`
--

DROP TABLE IF EXISTS `companion_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companion_ads` (
  `Id` int(11) NOT NULL,
  `TypeId` tinyint(4) NOT NULL COMMENT '1 - Static  \n2 - Dynamic',
  `EnableAutoClose` bit(1) NOT NULL DEFAULT b'1',
  `AutoCloseWaitInSeconds` double DEFAULT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `VideoCompanionAds_Ads` FOREIGN KEY (`Id`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `companytypes`
--

DROP TABLE IF EXISTS `companytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companytypes` (
  `id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `companytypes_localizedstringIds` (`NameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `configurationsettings`
--

DROP TABLE IF EXISTS `configurationsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configurationsettings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ApplicationId` int(11) DEFAULT NULL,
  `HostId` int(11) DEFAULT NULL,
  `Key` varchar(100) DEFAULT NULL,
  `Value` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ConfigurationSettings_Applications_FK` (`ApplicationId`),
  KEY `ConfigurationSettings_Hosts_FK` (`HostId`),
  CONSTRAINT `ConfigurationSettings_Applications_FK` FOREIGN KEY (`ApplicationId`) REFERENCES `applications` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ConfigurationSettings_Hosts_FK` FOREIGN KEY (`HostId`) REFERENCES `hosts` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content_list`
--

DROP TABLE IF EXISTS `content_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_list` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `GlobalScope` bit(1) DEFAULT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `AccountAdvAssId` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `Type` int(11) DEFAULT 1,
  `IsDeleted` bit(1) DEFAULT NULL,
  `LastModifiedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `masterappsite_account_idx` (`AccountId`),
  KEY `masterappsite_user_idx` (`UserId`),
  KEY `masterappsite_adv_idx` (`AccountAdvAssId`),
  CONSTRAINT `masterappsite_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `masterappsite_adv` FOREIGN KEY (`AccountAdvAssId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `masterappsite_user` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content_list_appsites`
--

DROP TABLE IF EXISTS `content_list_appsites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_list_appsites` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(300) NOT NULL,
  `AppID` varchar(300) DEFAULT NULL,
  `Domain` varchar(300) DEFAULT NULL,
  `Type` int(11) DEFAULT NULL,
  `AppSiteName` varchar(300) DEFAULT NULL,
  `LinkId` int(11) DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `masterappsiteitem_account_idx` (`AccountId`),
  KEY `masterappsiteitem_users_idx` (`UserId`),
  KEY `masterappsiteitem_link_idx` (`LinkId`),
  CONSTRAINT `masterappsiteitem_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `masterappsiteitem_link` FOREIGN KEY (`LinkId`) REFERENCES `content_list` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `masterappsiteitem_users` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1592347 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content_list_targeting`
--

DROP TABLE IF EXISTS `content_list_targeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_list_targeting` (
  `Id` int(11) NOT NULL,
  `ListId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `masterappsitetarg_masterappsite_idx` (`ListId`),
  CONSTRAINT `masterappsitetarg_masterappsite` FOREIGN KEY (`ListId`) REFERENCES `content_list` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `masterappsitetarg_targeting` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contextual_partners`
--

DROP TABLE IF EXISTS `contextual_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contextual_partners` (
  `Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `contextualpartners_businesspartners_fk` FOREIGN KEY (`Id`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contextual_segment_targetings`
--

DROP TABLE IF EXISTS `contextual_segment_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contextual_segment_targetings` (
  `Id` int(11) NOT NULL,
  `ContextualSegmentId` int(11) NOT NULL,
  `Include` bit(1) NOT NULL DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `IsBrandSafty` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `contextualsegmenttargetings_audiencesegments_fk_idx` (`ContextualSegmentId`),
  CONSTRAINT `contextualsegmenttargetings_audiencesegments_fk` FOREIGN KEY (`ContextualSegmentId`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `contextualsegmenttargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contextual_segments`
--

DROP TABLE IF EXISTS `contextual_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contextual_segments` (
  `Id` int(11) NOT NULL,
  `Type` varchar(200) DEFAULT NULL,
  `SubType` varchar(200) DEFAULT NULL,
  `TargetingIntent` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `contextualsegments_audiencesegments_fk` FOREIGN KEY (`Id`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contextual_segments_old`
--

DROP TABLE IF EXISTS `contextual_segments_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contextual_segments_old` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) DEFAULT NULL,
  `AdvertiserAccId` int(11) DEFAULT NULL,
  `Code` varchar(200) NOT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Type` varchar(200) DEFAULT NULL,
  `SubType` varchar(200) DEFAULT NULL,
  `TargetingIntent` varchar(200) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`),
  KEY `contextualsegmentsold_account_fk_idx` (`AccountId`),
  KEY `contextualsegmentsold_advertiseraccount_fk_idx` (`AdvertiserAccId`),
  CONSTRAINT `contextualsegmentsold_account_fk` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `contextualsegmentsold_advertiseraccount_fk` FOREIGN KEY (`AdvertiserAccId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1255 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_elements`
--

DROP TABLE IF EXISTS `cost_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_elements` (
  `Id` int(11) NOT NULL,
  `CalculatedFrom` tinyint(4) NOT NULL COMMENT '1 - Fee\n2 - Net Cost\n3 - Billable Cost',
  `CalculatedFromFeeCategory` bigint(20) DEFAULT NULL,
  `IsOneTime` bit(1) DEFAULT NULL,
  `Scope` int(11) DEFAULT 1,
  KEY `cost_elements_cost_items_fk_idx` (`Id`),
  CONSTRAINT `cost_elements_cost_items_fk` FOREIGN KEY (`Id`) REFERENCES `cost_items` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_elements_performance`
--

DROP TABLE IF EXISTS `cost_elements_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_elements_performance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CostElementId` int(11) NOT NULL,
  `BeneficiaryPartyId` int(11) NOT NULL DEFAULT 0,
  `DataProviderId` int(11) NOT NULL DEFAULT 0,
  `AdGroupId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Revenue` decimal(21,12) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UNIQ_IDX` (`Day`,`CostElementId`,`AdGroupId`,`BeneficiaryPartyId`,`DataProviderId`),
  KEY `CostElements_FK` (`CostElementId`)
) ENGINE=InnoDB AUTO_INCREMENT=13472435 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_elements_values`
--

DROP TABLE IF EXISTS `cost_elements_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_elements_values` (
  `Id` int(1) NOT NULL AUTO_INCREMENT,
  `Value` decimal(21,12) NOT NULL,
  `CostModelWrapperId` int(11) NOT NULL,
  `CostElementId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CostModelWrapperId_idx` (`CostModelWrapperId`),
  KEY `CostElement_idx` (`CostElementId`),
  CONSTRAINT `CostElement` FOREIGN KEY (`CostElementId`) REFERENCES `cost_elements` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CostModelWrapper` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=755 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_item_beneficiary_party_map`
--

DROP TABLE IF EXISTS `cost_item_beneficiary_party_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_item_beneficiary_party_map` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CostItemId` int(11) NOT NULL,
  `BeneficiaryPartyId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`CostItemId`,`BeneficiaryPartyId`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_items`
--

DROP TABLE IF EXISTS `cost_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_items` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Type` tinyint(4) NOT NULL COMMENT '1 - Cost Element\n2 - Fee',
  `CalculationType` tinyint(4) NOT NULL COMMENT '1 - Percentage\n2 - Fixed',
  `Category` bigint(20) DEFAULT NULL,
  `ModifiedOn` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=58279 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_items_performance`
--

DROP TABLE IF EXISTS `cost_items_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_items_performance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CostItemId` int(11) NOT NULL,
  `BeneficiaryPartyId` int(11) NOT NULL DEFAULT 0,
  `DataProviderId` int(11) NOT NULL DEFAULT 0,
  `AdGroupId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Amount` decimal(21,12) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UNIQ_IDX` (`Day`,`CostItemId`,`AdGroupId`,`BeneficiaryPartyId`,`DataProviderId`),
  KEY `CostElements_FK` (`CostItemId`)
) ENGINE=InnoDB AUTO_INCREMENT=13843042 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_items_values_`
--

DROP TABLE IF EXISTS `cost_items_values_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_items_values_` (
  `Id` int(1) NOT NULL AUTO_INCREMENT,
  `Value` decimal(21,12) NOT NULL,
  `CostModelWrapperId` int(11) NOT NULL,
  `CostItemId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `CostModelWrapperId2_idx` (`CostModelWrapperId`),
  KEY `CostItem2_idx` (`CostItemId`),
  CONSTRAINT `CostItem2` FOREIGN KEY (`CostItemId`) REFERENCES `cost_items` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CostModelWrapper2` FOREIGN KEY (`CostModelWrapperId`) REFERENCES `cost_model_wrappers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1468 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cost_model_wrappers`
--

DROP TABLE IF EXISTS `cost_model_wrappers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cost_model_wrappers` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `CostModelId` int(11) NOT NULL,
  `DefaultBidValue` int(11) NOT NULL DEFAULT 0,
  `DefaultDSPBidValue` int(11) NOT NULL DEFAULT 0,
  `ad_event_definition_id` int(11) DEFAULT NULL,
  `factor` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`Id`),
  KEY `costmodel` (`CostModelId`),
  KEY `ad_event_definition_id_idx` (`ad_event_definition_id`),
  CONSTRAINT `ad_event_definition_id` FOREIGN KEY (`ad_event_definition_id`) REFERENCES `ad_events_definition` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `costmodel` FOREIGN KEY (`CostModelId`) REFERENCES `costmodels` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `costmodels`
--

DROP TABLE IF EXISTS `costmodels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `costmodels` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counters`
--

DROP TABLE IF EXISTS `counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counters` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) DEFAULT NULL,
  `Year` smallint(6) DEFAULT NULL,
  `Counter` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_ip_mapping`
--

DROP TABLE IF EXISTS `country_ip_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country_ip_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) NOT NULL,
  `CountryId` int(11) NOT NULL,
  `OperatorId` int(11) DEFAULT NULL,
  `IPRangeStart` varchar(20) DEFAULT NULL,
  `IPRangeEnd` varchar(20) DEFAULT NULL,
  `IPRangeStart_Number` int(15) unsigned DEFAULT NULL,
  `IPRangeEnd_Number` int(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_vat`
--

DROP TABLE IF EXISTS `country_vat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country_vat` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaxNoRegistrationExpression` varchar(200) DEFAULT NULL,
  `CountryId` int(11) NOT NULL,
  `VATValue` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  PRIMARY KEY (`Id`),
  KEY `Country_VAT_idx` (`CountryId`),
  CONSTRAINT `Country_VAT` FOREIGN KEY (`CountryId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creative_attributes`
--

DROP TABLE IF EXISTS `creative_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creative_attributes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `IsSupported` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creative_formats`
--

DROP TABLE IF EXISTS `creative_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creative_formats` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creative_protocols`
--

DROP TABLE IF EXISTS `creative_protocols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creative_protocols` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creative_vendor_keywords`
--

DROP TABLE IF EXISTS `creative_vendor_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creative_vendor_keywords` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CreativeVendorId` int(11) NOT NULL,
  `Keyword` varchar(255) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Keyword_CreativeVendorId_idx` (`CreativeVendorId`),
  CONSTRAINT `Keyword_CreativeVendorId_idx` FOREIGN KEY (`CreativeVendorId`) REFERENCES `creative_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creative_vendors`
--

DROP TABLE IF EXISTS `creative_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creative_vendors` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Code` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creativeunit_groups`
--

DROP TABLE IF EXISTS `creativeunit_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creativeunit_groups` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` tinyint(4) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creativeunit_groups_mapping`
--

DROP TABLE IF EXISTS `creativeunit_groups_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creativeunit_groups_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `GroupId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `Priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `GROUPS_FK` (`GroupId`),
  KEY `GROUP_CREATIVES_FK` (`CreativeUnitId`),
  CONSTRAINT `GROUPS_FK` FOREIGN KEY (`GroupId`) REFERENCES `creativeunit_groups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `GROUP_CREATIVES_FK` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creativeunitformats`
--

DROP TABLE IF EXISTS `creativeunitformats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creativeunitformats` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Format` varchar(10) DEFAULT NULL,
  `CreativeUnitId` int(11) DEFAULT NULL,
  `MaxSize` int(11) DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `CreativeUnits_CreativeUnitId` (`CreativeUnitId`),
  CONSTRAINT `CreativeUnits_CreativeUnitId` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creativeunits`
--

DROP TABLE IF EXISTS `creativeunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creativeunits` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `HD_Width` smallint(6) DEFAULT NULL,
  `HD_Height` smallint(6) DEFAULT NULL,
  `OrientationTypeId` int(11) NOT NULL DEFAULT 0,
  `NameId` int(11) DEFAULT NULL,
  `Description` varchar(512) DEFAULT NULL,
  `Width` smallint(6) NOT NULL,
  `Height` smallint(6) NOT NULL,
  `DeviceTypeId` int(11) DEFAULT NULL,
  `Code` tinyint(4) DEFAULT NULL,
  `Priority` tinyint(4) DEFAULT NULL,
  `PreviewWidth` smallint(6) DEFAULT NULL,
  `PreviewHeight` smallint(6) DEFAULT NULL,
  `RequiredType` tinyint(4) DEFAULT 1,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `creativeunits_DeviceType` (`DeviceTypeId`),
  CONSTRAINT `creativeunits_DeviceType` FOREIGN KEY (`DeviceTypeId`) REFERENCES `devicetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `csvdata`
--

DROP TABLE IF EXISTS `csvdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvdata` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `appsiteid` int(11) DEFAULT NULL,
  `sdkversion` varchar(100) DEFAULT NULL,
  `counter` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `currencies_localizedstringIds` (`NameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_provider_logs`
--

DROP TABLE IF EXISTS `data_provider_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_provider_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` int(11) NOT NULL,
  `logtype` int(11) NOT NULL,
  `path` varchar(2000) DEFAULT NULL,
  `creationdate` datetime NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dataproviderid` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `Written` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_idx` (`day`,`dataproviderid`,`logtype`),
  KEY `implog_dataprovider_idx` (`dataproviderid`)
) ENGINE=InnoDB AUTO_INCREMENT=15246 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dataprotectionkeys`
--

DROP TABLE IF EXISTS `dataprotectionkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataprotectionkeys` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FriendlyName` text DEFAULT NULL,
  `Xml` text DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dealsperformance`
--

DROP TABLE IF EXISTS `dealsperformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealsperformance` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DealId` int(11) NOT NULL,
  `AdvertiserAssociationId` int(11) NOT NULL,
  `CampaignId` int(11) NOT NULL,
  `AdGroupId` int(11) NOT NULL,
  `Day` int(11) NOT NULL,
  `Impressions` int(11) DEFAULT 0,
  `Clicks` int(11) DEFAULT 0,
  `NetCost` decimal(21,12) DEFAULT NULL,
  `AdjustedNetCost` decimal(21,12) DEFAULT NULL,
  `AdFalconRevenue` decimal(21,12) DEFAULT NULL,
  `BillableCost` decimal(21,12) DEFAULT NULL,
  `GrossCost` decimal(21,12) DEFAULT NULL,
  `DataFee` decimal(21,12) DEFAULT NULL,
  `ThirdPartyFee` decimal(21,12) DEFAULT NULL,
  `PlatformFee` decimal(21,12) DEFAULT NULL,
  `Metrics` blob DEFAULT NULL,
  `Conversions` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UniqueKey` (`DealId`,`AdGroupId`,`Day`)
) ENGINE=InnoDB AUTO_INCREMENT=58921 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `demo_fix_metrics`
--

DROP TABLE IF EXISTS `demo_fix_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demo_fix_metrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateid` int(11) NOT NULL,
  `campaignid` int(11) NOT NULL,
  `adgroupid` int(11) NOT NULL,
  `adid` int(11) NOT NULL,
  `advassociationid` int(11) NOT NULL,
  `pageviews` int(11) DEFAULT 0,
  `vcreativeviews` int(11) DEFAULT 0,
  `vstart` int(11) DEFAULT 0,
  `vfirstquartile` int(11) DEFAULT 0,
  `vmidpoint` int(11) DEFAULT 0,
  `vthirdquartile` int(11) DEFAULT 0,
  `vcomplete` int(11) DEFAULT 0,
  `metric` blob DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `demographictargeting`
--

DROP TABLE IF EXISTS `demographictargeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographictargeting` (
  `Id` int(11) NOT NULL,
  `GenderId` int(11) DEFAULT NULL,
  `AgeGroupId` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AgeGroup_DemographicTrageting` (`AgeGroupId`),
  KEY `Gender_DemographicTrageting` (`GenderId`),
  KEY `Id` (`Id`),
  KEY `IX_GROUPID` (`GenderId`,`AgeGroupId`),
  CONSTRAINT `AgeGroup_DemographicTrageting` FOREIGN KEY (`AgeGroupId`) REFERENCES `agegroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Gender_DemographicTrageting` FOREIGN KEY (`GenderId`) REFERENCES `genders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_atlas_devices`
--

DROP TABLE IF EXISTS `device_atlas_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_atlas_devices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Device` varchar(150) DEFAULT NULL,
  `MatchWurflValue` varchar(150) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Device_UNIQUE` (`Device`)
) ENGINE=InnoDB AUTO_INCREMENT=1030 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_atlas_manufacturers`
--

DROP TABLE IF EXISTS `device_atlas_manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_atlas_manufacturers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Manufacturer` varchar(75) DEFAULT NULL,
  `MatchWurflValue` varchar(75) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Manufacturer_UNIQUE` (`Manufacturer`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_atlas_platforms`
--

DROP TABLE IF EXISTS `device_atlas_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_atlas_platforms` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Platform` varchar(25) DEFAULT NULL,
  `MatchWurflValue` varchar(25) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Platform_UNIQUE` (`Platform`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_capabilities`
--

DROP TABLE IF EXISTS `device_capabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_capabilities` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `WurflCapabilities` varchar(100) NOT NULL,
  `WurflValue` varchar(100) NOT NULL,
  `Type` tinyint(4) DEFAULT 1 COMMENT '1 all ,2 Include,3 Exclude',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=507 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_codes`
--

DROP TABLE IF EXISTS `device_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_codes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceId` int(11) DEFAULT NULL,
  `Code` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `devicecodes_devices_fk_idx` (`DeviceId`),
  CONSTRAINT `devicecodes_devices_fk` FOREIGN KEY (`DeviceId`) REFERENCES `devices` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6400 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_extension`
--

DROP TABLE IF EXISTS `device_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_extension` (
  `id` int(11) NOT NULL,
  `summarize` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_orientations`
--

DROP TABLE IF EXISTS `device_orientations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_orientations` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` char(1) DEFAULT NULL,
  `Description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_targeting_device_capabilities`
--

DROP TABLE IF EXISTS `device_targeting_device_capabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_targeting_device_capabilities` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceTargetingId` int(11) NOT NULL,
  `CapabilityId` int(11) NOT NULL,
  `Include` bit(1) NOT NULL DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `FK_DeviceTargeting` (`DeviceTargetingId`),
  KEY `FK_DeviceCapabilities` (`CapabilityId`),
  KEY `IX_Index` (`Include`,`CapabilityId`),
  CONSTRAINT `FK_DeviceCapabilities` FOREIGN KEY (`CapabilityId`) REFERENCES `device_capabilities` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DeviceTargeting` FOREIGN KEY (`DeviceTargetingId`) REFERENCES `devicetargetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25557 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_targeting_type`
--

DROP TABLE IF EXISTS `device_targeting_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_targeting_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceTargetingId` int(11) NOT NULL,
  `DeviceTypeId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `FK_DeviceTypeTargeting` (`DeviceTargetingId`),
  KEY `FK_DeviceTypes` (`DeviceTypeId`),
  KEY `IX_Index` (`DeviceTypeId`),
  CONSTRAINT `FK_DeviceTypeTargeting` FOREIGN KEY (`DeviceTargetingId`) REFERENCES `devicetargetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DeviceTypes` FOREIGN KEY (`DeviceTypeId`) REFERENCES `devicetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=163330 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicebannersizes`
--

DROP TABLE IF EXISTS `devicebannersizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicebannersizes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceId` int(11) NOT NULL,
  `BannerSizeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Device` (`DeviceId`),
  KEY `BannerSize` (`BannerSizeId`),
  CONSTRAINT `BannerSize` FOREIGN KEY (`BannerSizeId`) REFERENCES `bannersizes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Device` FOREIGN KEY (`DeviceId`) REFERENCES `devices` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `ManufacturerId` int(11) NOT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `BannerSizeId` int(11) DEFAULT NULL,
  `DeviceTypeId` int(11) DEFAULT 1,
  `Summarize` int(1) NOT NULL DEFAULT 3 COMMENT '1 --> always summrize\n2 --> always don''t summrize\n3 --> calcuated ',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `b` (`BannerSizeId`),
  KEY `m` (`ManufacturerId`),
  KEY `p` (`PlatformId`),
  KEY `devices_DeviceTypeId` (`DeviceTypeId`),
  CONSTRAINT `b` FOREIGN KEY (`BannerSizeId`) REFERENCES `bannersizes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_DeviceTypeId` FOREIGN KEY (`DeviceTypeId`) REFERENCES `devicetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `m` FOREIGN KEY (`ManufacturerId`) REFERENCES `manufacturers` (`ManufacturerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `p` FOREIGN KEY (`PlatformId`) REFERENCES `platforms` (`PlatformId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24058 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetargetingdevices`
--

DROP TABLE IF EXISTS `devicetargetingdevices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetargetingdevices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceTargetingId` int(11) NOT NULL,
  `DeviceId` int(11) NOT NULL,
  `ManufacturerId` int(11) DEFAULT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `Include` bit(1) NOT NULL DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `Devices_DeviceTragetingDevices` (`DeviceId`),
  KEY `DeviceTrageting_DeviceTragetingDevices` (`DeviceTargetingId`),
  KEY `IX_GROUPID` (`Include`,`DeviceId`),
  CONSTRAINT `DeviceTrageting_DeviceTragetingDevices` FOREIGN KEY (`DeviceTargetingId`) REFERENCES `devicetargetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Devices_DeviceTragetingDevices` FOREIGN KEY (`DeviceId`) REFERENCES `devices` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=209419 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetargetingmanufacturers`
--

DROP TABLE IF EXISTS `devicetargetingmanufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetargetingmanufacturers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceTargetingId` int(11) DEFAULT NULL,
  `ManufacturerId` int(11) DEFAULT NULL,
  `IsAll` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `DeviceTrageting_DeviceTragetingManufacturers` (`DeviceTargetingId`),
  KEY `Manufacturers_FK` (`ManufacturerId`),
  KEY `IX_GROUPID` (`ManufacturerId`),
  CONSTRAINT `DeviceTrageting_DeviceTragetingManufacturers` FOREIGN KEY (`DeviceTargetingId`) REFERENCES `devicetargetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Manufacturers_FK` FOREIGN KEY (`ManufacturerId`) REFERENCES `manufacturers` (`ManufacturerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=46078 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetargetingplatforms`
--

DROP TABLE IF EXISTS `devicetargetingplatforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetargetingplatforms` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DeviceTargetingId` int(11) NOT NULL,
  `PlatformId` int(11) NOT NULL,
  `PlatformMinimumVersion` varchar(50) DEFAULT NULL,
  `PlatformMaximumVersion` varchar(50) DEFAULT NULL,
  `isAll` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `DeviceTrageting_DeviceTragetingPlatforms` (`DeviceTargetingId`),
  KEY `IX_GROUPID` (`PlatformId`),
  CONSTRAINT `DeviceTrageting_DeviceTragetingPlatforms` FOREIGN KEY (`DeviceTargetingId`) REFERENCES `devicetargetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=157972 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetargetings`
--

DROP TABLE IF EXISTS `devicetargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetargetings` (
  `Id` int(11) NOT NULL,
  `IsAll` tinyint(1) DEFAULT 1,
  `SubTypeId` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Targetings_FK` (`Id`),
  CONSTRAINT `Targetings_FK` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetargetingtypes`
--

DROP TABLE IF EXISTS `devicetargetingtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetargetingtypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `localizedstringid_devicetragetingtypes` (`NameId`),
  CONSTRAINT `localizedstringid_devicetragetingtypes` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicetypes`
--

DROP TABLE IF EXISTS `devicetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicetypes` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Code` tinyint(4) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `devicetypes_NameId_LocalizedstringId` (`NameId`),
  CONSTRAINT `devicetypes_NameId_LocalizedstringId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dimdate`
--

DROP TABLE IF EXISTS `dimdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dimdate` (
  `date_id` int(11) NOT NULL AUTO_INCREMENT,
  `fulldate` date DEFAULT NULL,
  `dayofmonth` int(11) DEFAULT NULL,
  `dayofyear` int(11) DEFAULT NULL,
  `dayofweek` int(11) DEFAULT NULL,
  `dayname` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `monthnumber` int(11) DEFAULT NULL,
  `monthname` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `quarter` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`date_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20201232 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dimhourstime`
--

DROP TABLE IF EXISTS `dimhourstime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dimhourstime` (
  `DimHoursTimeKey` int(11) NOT NULL,
  `FromHour` tinyint(4) NOT NULL,
  `ToHour` tinyint(4) NOT NULL,
  `FromHour24` tinyint(4) NOT NULL,
  `ToHour24` tinyint(4) NOT NULL,
  `AM` char(2) CHARACTER SET latin1 NOT NULL,
  `HourName` varchar(20) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`DimHoursTimeKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dimtime`
--

DROP TABLE IF EXISTS `dimtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dimtime` (
  `DimTimeKey` int(11) NOT NULL,
  `Hour` tinyint(4) NOT NULL,
  `HourName` varchar(10) CHARACTER SET latin1 NOT NULL,
  `Hour24` tinyint(4) NOT NULL,
  `AM` char(2) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`DimTimeKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `Id` int(11) NOT NULL,
  `DocumentTypeId` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Extension` varchar(16) NOT NULL,
  `Size` int(11) NOT NULL,
  `UploadedDate` datetime NOT NULL,
  `Content` longblob DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `IsUsed` tinyint(1) DEFAULT 0,
  `Usage` int(11) DEFAULT 0,
  `IsWebHDFS` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `DocumentTypes_DocumentTypeId` (`DocumentTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `documenttypes`
--

DROP TABLE IF EXISTS `documenttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documenttypes` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `LocalizedStringIds_NameId` (`NameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dp_partners`
--

DROP TABLE IF EXISTS `dp_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dp_partners` (
  `Id` int(11) NOT NULL,
  `IsExternalProvider` bit(1) DEFAULT b'0',
  `SiteProviderURL` varchar(255) DEFAULT NULL,
  `IsFTPEnabled` bit(1) DEFAULT b'0',
  `FTPURL` varchar(255) DEFAULT NULL,
  `AdMarkupLogRequired` bit(1) NOT NULL DEFAULT b'0',
  `APIKey` varchar(255) DEFAULT NULL,
  `APISecret` varchar(255) DEFAULT NULL,
  `APISiteProviderURL` varchar(255) DEFAULT NULL,
  `CertPath` varchar(255) DEFAULT NULL,
  `CertPass` varchar(255) DEFAULT NULL,
  `AllowImpressionTrackers` bit(1) DEFAULT b'1',
  `Order` int(11) DEFAULT 1,
  PRIMARY KEY (`Id`),
  CONSTRAINT `DPPartners_BusinessPartners_FK` FOREIGN KEY (`Id`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dp_revenue_calculation_modes`
--

DROP TABLE IF EXISTS `dp_revenue_calculation_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dp_revenue_calculation_modes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DataProviderId` int(11) NOT NULL,
  `CalculationModeType` tinyint(4) DEFAULT NULL COMMENT '1 - Percentage, 2- Fixed value',
  `Value` decimal(21,12) NOT NULL,
  `FromDate` datetime NOT NULL,
  `ToDate` datetime DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `DataProvider_FK` (`DataProviderId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_account_setting`
--

DROP TABLE IF EXISTS `dsp_account_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_account_setting` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BillToAddress2` varchar(300) DEFAULT NULL,
  `BusinessName` varchar(300) NOT NULL,
  `BillingContactName` varchar(300) NOT NULL,
  `BillToAddressPersonName` varchar(300) DEFAULT NULL,
  `BillToAddress1` varchar(300) DEFAULT NULL,
  `AccountId` int(11) NOT NULL,
  `CountryId` int(11) DEFAULT NULL,
  `StateId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `dsp_account_setting_account_idx` (`AccountId`),
  KEY `dsp_account_setting_account_country_idx` (`CountryId`),
  KEY `dsp_account_setting_account_city_idx` (`StateId`),
  CONSTRAINT `dsp_account_setting_account` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_account_setting_account_city` FOREIGN KEY (`StateId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_account_setting_account_country` FOREIGN KEY (`CountryId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_account_setting_contact`
--

DROP TABLE IF EXISTS `dsp_account_setting_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_account_setting_contact` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(300) NOT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `AccountSettingId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `dsp_account_setting_contact_idx` (`AccountSettingId`),
  CONSTRAINT `dsp_account_setting_contact` FOREIGN KEY (`AccountSettingId`) REFERENCES `dsp_account_setting` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_partners`
--

DROP TABLE IF EXISTS `dsp_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_partners` (
  `Id` int(11) NOT NULL,
  `AppSiteId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `DSPPartners_AppSite_FK_idx` (`AppSiteId`),
  CONSTRAINT `DSPPartners_AppSite_FK` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DSPPartners_BusinessPartners_FK` FOREIGN KEY (`Id`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emailsender_events_emails`
--

DROP TABLE IF EXISTS `emailsender_events_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailsender_events_emails` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `eventname` varchar(45) NOT NULL,
  `emails` varchar(1000) NOT NULL,
  `sendtodefault` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `Id` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `job_position_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `employee_jobPositions` (`job_position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `eventbroker_event_state`
--

DROP TABLE IF EXISTS `eventbroker_event_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventbroker_event_state` (
  `ProxyId` varchar(50) NOT NULL,
  `SubscriberId` varchar(50) NOT NULL,
  `State` tinyblob DEFAULT NULL,
  PRIMARY KEY (`ProxyId`,`SubscriberId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `eventbroker_offset_track`
--

DROP TABLE IF EXISTS `eventbroker_offset_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventbroker_offset_track` (
  `ProxyId` varchar(50) NOT NULL,
  `LatestOffset` bigint(15) NOT NULL,
  PRIMARY KEY (`ProxyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EventName` varchar(512) DEFAULT NULL,
  `Desc` varchar(512) DEFAULT NULL,
  `isActive` bit(1) DEFAULT NULL,
  `UpdateStats` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `events_stat`
--

DROP TABLE IF EXISTS `events_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events_stat` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EventId` int(11) NOT NULL,
  `InstanceId` varchar(50) DEFAULT NULL,
  `NumberOfRaises` int(11) DEFAULT NULL,
  `LastRaiseDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Unique` (`EventId`,`InstanceId`),
  KEY `FK_Events` (`EventId`),
  CONSTRAINT `FK_Events` FOREIGN KEY (`EventId`) REFERENCES `events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=351826 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `eventsubscription`
--

DROP TABLE IF EXISTS `eventsubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventsubscription` (
  `EventID` varchar(255) NOT NULL,
  `SubscriberID` varchar(255) NOT NULL,
  PRIMARY KEY (`EventID`,`SubscriberID`),
  UNIQUE KEY `SubscriberID` (`SubscriberID`,`EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fact_stat_delta_transaction_affected_days`
--

DROP TABLE IF EXISTS `fact_stat_delta_transaction_affected_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fact_stat_delta_transaction_affected_days` (
  `Id` int(11) NOT NULL,
  `FactStatDeltaTransactionId` int(11) NOT NULL,
  `Day` datetime NOT NULL,
  `IsClosed` bit(1) NOT NULL DEFAULT b'0',
  `LastPageIndex` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`FactStatDeltaTransactionId`,`Day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `features_localizedstringid_idx` (`NameId`),
  CONSTRAINT `features_localizedstringid` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees` (
  `Id` int(11) NOT NULL,
  `CalculatedFrom` tinyint(4) NOT NULL COMMENT '1 - ANC\n2 - System',
  `IsBillable` bit(1) NOT NULL,
  `IsAutoAdded` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `fees_cost_items_fk` FOREIGN KEY (`Id`) REFERENCES `cost_items` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filters` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AppSiteId` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `AppSiteId` (`AppSiteId`,`IsDeleted`),
  CONSTRAINT `AppSiteId` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=75046 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fraud_detection_vendors`
--

DROP TABLE IF EXISTS `fraud_detection_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fraud_detection_vendors` (
  `Id` int(11) NOT NULL,
  KEY `frauddetectionvendors_metricvendors_fk_idx` (`Id`),
  CONSTRAINT `frauddetectionvendors_metricvendors_fk` FOREIGN KEY (`Id`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fund_about_to_be_consumed_event_stat`
--

DROP TABLE IF EXISTS `fund_about_to_be_consumed_event_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_about_to_be_consumed_event_stat` (
  `CampaignId` int(11) NOT NULL,
  `NumberOfRaises` int(11) NOT NULL DEFAULT 0,
  `LastRaiseDate` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`CampaignId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `genders`
--

DROP TABLE IF EXISTS `genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` char(1) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geofencing_targetings`
--

DROP TABLE IF EXISTS `geofencing_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geofencing_targetings` (
  `Id` int(11) NOT NULL,
  `Latitude` decimal(20,18) NOT NULL,
  `Longitude` decimal(20,18) NOT NULL,
  `Radius` decimal(14,7) NOT NULL,
  `ModifiedOn` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geographictargetings`
--

DROP TABLE IF EXISTS `geographictargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geographictargetings` (
  `Id` int(11) NOT NULL,
  `LocationId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Locations_GeographicTragetings` (`LocationId`),
  KEY `Id` (`Id`),
  KEY `IX_GROUPID` (`LocationId`),
  CONSTRAINT `Locations_GeographicTragetings` FOREIGN KEY (`LocationId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_unique_key`
--

DROP TABLE IF EXISTS `hibernate_unique_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_unique_key` (
  `next_hi` mediumtext DEFAULT NULL,
  `TableKey` varchar(45) NOT NULL,
  `Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hosts`
--

DROP TABLE IF EXISTS `hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hosts` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `house_ad_appsites`
--

DROP TABLE IF EXISTS `house_ad_appsites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_ad_appsites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `house_ad_id` int(11) DEFAULT NULL,
  `appsite_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `house_ad_appsites_house_ad_idx` (`house_ad_id`),
  KEY `house_ad_appsites_appsite_idx` (`appsite_id`),
  CONSTRAINT `house_ad_appsites_appsite` FOREIGN KEY (`appsite_id`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `house_ad_appsites_house_ad` FOREIGN KEY (`house_ad_id`) REFERENCES `house_ads` (`AdGroupId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=487 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `house_ads`
--

DROP TABLE IF EXISTS `house_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_ads` (
  `Id` int(11) NOT NULL,
  `AdGroupId` int(11) NOT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `ForAppsiteId` int(11) DEFAULT NULL,
  `DeliveryMode` tinyint(4) DEFAULT 1 COMMENT 'WhenNoAds = 1,\nFullyAllocate = 2',
  `IsDeleted` bit(1) DEFAULT b'0',
  `UserId` int(11) DEFAULT NULL,
  PRIMARY KEY (`AdGroupId`),
  KEY `house_ads_appsite_idx` (`ForAppsiteId`),
  KEY `house_ads_account_idx` (`AccountId`),
  KEY `house_ads_adgroups_idx` (`AdGroupId`),
  CONSTRAINT `house_ads_adgroups` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `house_ads_appsite` FOREIGN KEY (`ForAppsiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `http_referers`
--

DROP TABLE IF EXISTS `http_referers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_referers` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Domain` varchar(250) NOT NULL,
  `SampleUrl` varchar(5000) DEFAULT NULL,
  `SampleAppsiteId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Domain_UNIQUE` (`Domain`)
) ENGINE=InnoDB AUTO_INCREMENT=27516751 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iab_content_categories`
--

DROP TABLE IF EXISTS `iab_content_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iab_content_categories` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `IABCategory` varchar(100) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `IsBlocked` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iab_content_categories_to_keywords_mapping`
--

DROP TABLE IF EXISTS `iab_content_categories_to_keywords_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iab_content_categories_to_keywords_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `IABContentCategoryId` int(11) NOT NULL,
  `KeywordId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `mapping_iab_content_categories_fk` (`IABContentCategoryId`),
  KEY `mapping_keywords_fkk` (`KeywordId`)
) ENGINE=InnoDB AUTO_INCREMENT=464 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `impression_logs`
--

DROP TABLE IF EXISTS `impression_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impression_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` int(11) NOT NULL,
  `path` varchar(2000) DEFAULT NULL,
  `creationdate` datetime NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dataproviderid` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_idx` (`day`,`dataproviderid`),
  KEY `implog_dataprovider_idx` (`dataproviderid`),
  CONSTRAINT `implog_dataprovider` FOREIGN KEY (`dataproviderid`) REFERENCES `dp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5152 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `impression_metric_targetings`
--

DROP TABLE IF EXISTS `impression_metric_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impression_metric_targetings` (
  `Id` int(11) NOT NULL,
  `MetricVendorId` int(11) DEFAULT NULL,
  `ImpressionMetricId` int(11) NOT NULL,
  `MinValue` float NOT NULL,
  `IgnoreIfNotAvailable` bit(1) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `impressionmetrictargetings_impressionmetrics_fk` (`ImpressionMetricId`),
  KEY `impressionmetrictargetings_metricvendors_fk_idx` (`MetricVendorId`),
  CONSTRAINT `impressionmetrictargetings_impressionmetrics_fk` FOREIGN KEY (`ImpressionMetricId`) REFERENCES `impression_metrics` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `impressionmetrictargetings_metricvendors_fk` FOREIGN KEY (`MetricVendorId`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `impressionmetrictargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `impression_metrics`
--

DROP TABLE IF EXISTS `impression_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impression_metrics` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(100) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ip_targetings`
--

DROP TABLE IF EXISTS `ip_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_targetings` (
  `Id` int(11) NOT NULL,
  `IPRangeStart` varbinary(16) NOT NULL,
  `IPRangeEnd` varbinary(16) NOT NULL,
  `Description` varchar(512) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `IX_GroupId` (`IPRangeStart`,`IPRangeEnd`),
  CONSTRAINT `FK_Targetings` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_positions`
--

DROP TABLE IF EXISTS `job_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_positions` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `job_positions_NameId__localizedstringId` (`NameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywords` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(6) NOT NULL,
  `Usage` int(11) DEFAULT NULL,
  `isCustom` tinyint(1) DEFAULT 1,
  `IsDeleted` bit(1) DEFAULT b'0',
  `IsHidden` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB AUTO_INCREMENT=40604 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `keywords_to_iab_content_categories_mapping`
--

DROP TABLE IF EXISTS `keywords_to_iab_content_categories_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywords_to_iab_content_categories_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `KeywordId` int(11) NOT NULL,
  `IABContentCategoryId` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `keywordsfilters`
--

DROP TABLE IF EXISTS `keywordsfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywordsfilters` (
  `Id` int(11) NOT NULL,
  `KeywordId` int(11) NOT NULL,
  `AppSiteId` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `FK_KeywordId` (`KeywordId`),
  KEY `IX_APPSITE_ID` (`AppSiteId`,`KeywordId`,`IsDeleted`) USING BTREE,
  CONSTRAINT `FK_KeywordId` FOREIGN KEY (`KeywordId`) REFERENCES `keywords` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `keywordtargetings`
--

DROP TABLE IF EXISTS `keywordtargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywordtargetings` (
  `Id` int(11) NOT NULL,
  `keywordId` int(11) NOT NULL,
  `Include` bit(1) NOT NULL DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `KeywordId` (`keywordId`),
  KEY `IX_GROUPID` (`keywordId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_config`
--

DROP TABLE IF EXISTS `kpi_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_config` (
  `Id` int(11) NOT NULL,
  `GroupKey` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DataBaseField` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IsDefault` bit(1) DEFAULT b'0',
  `Icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GrowIcon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NameId` int(11) DEFAULT NULL,
  `ForAdvertiser` bit(1) DEFAULT b'0',
  `ForDeals` bit(1) DEFAULT NULL,
  `ForCampaign` bit(1) DEFAULT b'0',
  `ForPublisher` bit(1) DEFAULT b'0',
  `ForDataProvider` bit(1) DEFAULT b'0',
  `DisplayFormat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `kpi_config_localized_idx` (`NameId`),
  CONSTRAINT `kpi_config_localized` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `language_targetings`
--

DROP TABLE IF EXISTS `language_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_targetings` (
  `Id` int(11) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `languagetargetings_languages_fk_idx` (`LanguageId`),
  CONSTRAINT `languagetargetings_languages_fk` FOREIGN KEY (`LanguageId`) REFERENCES `languages` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `languagetargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `languagefilters`
--

DROP TABLE IF EXISTS `languagefilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languagefilters` (
  `Id` int(11) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  `AppSiteId` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `l` (`LanguageId`),
  KEY `IX_APPSITEID` (`AppSiteId`,`LanguageId`,`IsDeleted`) USING BTREE,
  CONSTRAINT `i` FOREIGN KEY (`LanguageId`) REFERENCES `languages` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` char(5) DEFAULT NULL,
  `Id_Hex` varchar(7) DEFAULT NULL,
  `ForPortal` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `localizedstringids`
--

DROP TABLE IF EXISTS `localizedstringids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localizedstringids` (
  `LocalizedStringId` int(11) NOT NULL AUTO_INCREMENT,
  `GroupKey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`LocalizedStringId`)
) ENGINE=InnoDB AUTO_INCREMENT=30904 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `localizedstrings`
--

DROP TABLE IF EXISTS `localizedstrings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localizedstrings` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LocalizedStringID` int(11) NOT NULL DEFAULT 0,
  `Culture` char(5) NOT NULL DEFAULT '',
  `Value` varchar(255) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `lid` (`LocalizedStringID`)
) ENGINE=InnoDB AUTO_INCREMENT=58159 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `location_extension`
--

DROP TABLE IF EXISTS `location_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_extension` (
  `id` int(11) NOT NULL,
  `summarize` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `LocationType` tinyint(4) NOT NULL,
  `Code1` varchar(200) DEFAULT NULL,
  `Code2` varchar(200) DEFAULT NULL,
  `Code3` varchar(200) DEFAULT NULL,
  `Code_Alpha2` varchar(10) DEFAULT NULL,
  `Summarize` int(1) NOT NULL DEFAULT 3 COMMENT '1 --> always summrize\\n2 --> always don''t summrize\\n3 --> calcuated ',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `CODE1_UNIQUE` (`LocationType`,`ParentId`,`Code1`),
  UNIQUE KEY `CODE2_UNIQUE` (`LocationType`,`ParentId`,`Code2`),
  UNIQUE KEY `CODE3_UNIQUE` (`LocationType`,`ParentId`,`Code3`)
) ENGINE=InnoDB AUTO_INCREMENT=24454 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_filters`
--

DROP TABLE IF EXISTS `log_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_filters` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FilterTypeId` int(11) NOT NULL,
  `FilterValues` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookalike_jobs`
--

DROP TABLE IF EXISTS `lookalike_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookalike_jobs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SeedAudienceListCode` int(11) NOT NULL,
  `LookalikeAudienceListCode` int(11) NOT NULL,
  `PopulationCountryFilter` varchar(45) NOT NULL,
  `LookalikePercentage` float NOT NULL,
  `SeedCount` int(11) DEFAULT NULL,
  `LookalikeCount` int(11) DEFAULT NULL,
  `IsCompleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manufacturercodes`
--

DROP TABLE IF EXISTS `manufacturercodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturercodes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ManufacturerId` int(11) DEFAULT NULL,
  `Code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`),
  KEY `ManufacturerId_Manufacturers` (`ManufacturerId`),
  CONSTRAINT `ManufacturerId_Manufacturers` FOREIGN KEY (`ManufacturerId`) REFERENCES `manufacturers` (`ManufacturerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturers` (
  `ManufacturerId` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1000,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ManufacturerId`)
) ENGINE=InnoDB AUTO_INCREMENT=20506 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `masteraccounts`
--

DROP TABLE IF EXISTS `masteraccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `masteraccounts` (
  `AccountKey` varchar(40) NOT NULL,
  `AccountType` int(11) NOT NULL,
  `AccountStatus` int(11) NOT NULL,
  `TotalBudget` decimal(21,12) DEFAULT NULL,
  `BudgetExpiry` datetime NOT NULL,
  `Allocated` decimal(21,12) NOT NULL,
  `CommitmentsMade` decimal(21,12) NOT NULL,
  `CommitmentsRetired` decimal(21,12) NOT NULL,
  `Spend` decimal(21,12) NOT NULL,
  `TodaySpend` decimal(21,12) NOT NULL,
  `SpendAdjustment` decimal(21,12) NOT NULL,
  `TodaySpendAdjustment` decimal(21,12) NOT NULL,
  `UnitPrice` decimal(21,12) NOT NULL,
  `AccumulatedHourlySpend` varchar(255) DEFAULT NULL,
  `EndOfTodayEpoch` bigint(20) NOT NULL,
  `PacingPolicy` int(11) NOT NULL,
  `IsOnline` tinyint(1) NOT NULL,
  `CloseReason` int(11) NOT NULL,
  `CloseDate` datetime DEFAULT NULL,
  `LastPersisted` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `LastUpdated` bigint(20) NOT NULL,
  PRIMARY KEY (`AccountKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matchtypes`
--

DROP TABLE IF EXISTS `matchtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matchtypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metric_vendor_creative_plugins`
--

DROP TABLE IF EXISTS `metric_vendor_creative_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metric_vendor_creative_plugins` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VendorId` int(11) NOT NULL,
  `CreativeFormatId` int(11) NOT NULL,
  `ApiFramework` varchar(50) DEFAULT NULL,
  `SdkPlugin` varchar(5000) DEFAULT NULL,
  `NonSdkPlugin` varchar(5000) DEFAULT NULL,
  `Priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `metricvendorcreativeplugins_metricvendors_fk_idx` (`VendorId`),
  KEY `metricvendorcreativeplugins_creativeformats_fk_idx` (`CreativeFormatId`),
  CONSTRAINT `metricvendorcreativeplugins_creativeformats_fk` FOREIGN KEY (`CreativeFormatId`) REFERENCES `creative_formats` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `metricvendorcreativeplugins_metricvendors_fk` FOREIGN KEY (`VendorId`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metric_vendor_whitelist_accounts`
--

DROP TABLE IF EXISTS `metric_vendor_whitelist_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metric_vendor_whitelist_accounts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VendorId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `metricvendorwhitelistaccounts_metricvendors_fk_idx` (`VendorId`),
  KEY `metricvendorwhitelistaccounts_account_fk_idx` (`AccountId`),
  CONSTRAINT `metricvendorwhitelistaccounts_account_fk` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `metricvendorwhitelistaccounts_metricvendors_fk` FOREIGN KEY (`VendorId`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metric_vendors`
--

DROP TABLE IF EXISTS `metric_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metric_vendors` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Type` tinyint(4) NOT NULL COMMENT '1 - Viewability\n2 - Fraud\n',
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metrices_columns`
--

DROP TABLE IF EXISTS `metrices_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrices_columns` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Order` varchar(45) DEFAULT NULL,
  `Advertiser` bit(1) DEFAULT NULL,
  `Publisher` bit(1) DEFAULT NULL,
  `DSP` bit(1) DEFAULT NULL,
  `IsSelected` bit(1) DEFAULT NULL,
  `HeaderResourceKey` varchar(100) DEFAULT NULL,
  `HeaderResourceSet` varchar(100) DEFAULT NULL,
  `GroupKey` varchar(100) DEFAULT NULL,
  `DataBaseFieldName` varchar(100) DEFAULT NULL,
  `AppFieldName` varchar(100) DEFAULT NULL,
  `Hide` bit(1) DEFAULT NULL,
  `Format` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metrices_columns_reportcriteria`
--

DROP TABLE IF EXISTS `metrices_columns_reportcriteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrices_columns_reportcriteria` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `metriceColumnId` int(11) NOT NULL,
  `ReportCriteriaId` int(11) NOT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `metrice_column_report_idx` (`metriceColumnId`),
  KEY `metrice_column_reportCriteria_idx` (`ReportCriteriaId`),
  CONSTRAINT `metrice_column_report` FOREIGN KEY (`metriceColumnId`) REFERENCES `metrices_columns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `metrice_column_reportCriteria` FOREIGN KEY (`ReportCriteriaId`) REFERENCES `report_criteria` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26872 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `metrics`
--

DROP TABLE IF EXISTS `metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrics` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` varchar(10) NOT NULL,
  `MetricTarget` varchar(10) NOT NULL,
  `Color` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migationcampaignadvertiser`
--

DROP TABLE IF EXISTS `migationcampaignadvertiser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migationcampaignadvertiser` (
  `CampaignID` int(11) NOT NULL,
  `DomainURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migationdomainurladvertiser`
--

DROP TABLE IF EXISTS `migationdomainurladvertiser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migationdomainurladvertiser` (
  `URL` varchar(255) DEFAULT NULL,
  `NewURL` varchar(255) DEFAULT NULL,
  `ArabicDescription` varchar(300) DEFAULT NULL,
  `EnglishDescription` varchar(300) DEFAULT NULL,
  `AdvertiserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migationdomainurladvertiserclean`
--

DROP TABLE IF EXISTS `migationdomainurladvertiserclean`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migationdomainurladvertiserclean` (
  `NewURL` varchar(255) DEFAULT NULL,
  `AdvertiserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mime_types`
--

DROP TABLE IF EXISTS `mime_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mime_types` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MIME` varchar(100) NOT NULL,
  `AdTypeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `mime_types_adtypes_fk` (`AdTypeId`),
  CONSTRAINT `mime_types_adtypes_fk` FOREIGN KEY (`AdTypeId`) REFERENCES `adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mimetypes_documentypes`
--

DROP TABLE IF EXISTS `mimetypes_documentypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mimetypes_documentypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DocumentTypeId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `mimetype_documenttype_mimetypid_idx` (`MIMETypeId`),
  KEY `mimetype_documenttype_documenttypeid_idx` (`DocumentTypeId`),
  CONSTRAINT `mimetype_documenttype_documenttypeid` FOREIGN KEY (`DocumentTypeId`) REFERENCES `documenttypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `mimetype_documenttype_mimetypid` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `native_ad_icons`
--

DROP TABLE IF EXISTS `native_ad_icons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `native_ad_icons` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NativeAdId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  `Url` varchar(5000) DEFAULT NULL,
  `DocumentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `nativeadicons_nativeads_fk_idx` (`NativeAdId`),
  KEY `nativeadicons_mimtypes_fk_idx` (`MIMETypeId`),
  KEY `nativeadicons_documents_fk_idx` (`DocumentId`),
  KEY `nativeadicons_creativeunits_fk_idx` (`CreativeUnitId`),
  CONSTRAINT `nativeadicons_creativeunits_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadicons_documents_fk` FOREIGN KEY (`DocumentId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadicons_mimetypes_fk` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadicons_nativeads_fk` FOREIGN KEY (`NativeAdId`) REFERENCES `native_ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=70603 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `native_ad_images`
--

DROP TABLE IF EXISTS `native_ad_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `native_ad_images` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NativeAdId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  `Url` varchar(5000) DEFAULT NULL,
  `DocumentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `nativeadimages_nativeads_fk_idx` (`NativeAdId`),
  KEY `nativeadimages_mimtypes_fk_idx` (`MIMETypeId`),
  KEY `nativeadimages_documents_fk_idx` (`DocumentId`),
  KEY `nativeadimages_creativeunits_fk_idx` (`CreativeUnitId`),
  CONSTRAINT `nativeadimages_creativeunits_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadimages_documents_fk` FOREIGN KEY (`DocumentId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadimages_mimetypes_fk` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `nativeadimages_nativeads_fk` FOREIGN KEY (`NativeAdId`) REFERENCES `native_ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=85048 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `native_ad_layouts`
--

DROP TABLE IF EXISTS `native_ad_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `native_ad_layouts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `native_ad_layouts_localizedstringids_idx` (`NameId`),
  CONSTRAINT `native_ad_layouts_localizedstringids` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `native_ads`
--

DROP TABLE IF EXISTS `native_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `native_ads` (
  `Id` int(11) NOT NULL,
  `DESCRIPTION` varchar(400) DEFAULT NULL,
  `AppOpenUrl` varchar(500) DEFAULT NULL,
  `StarRating` float DEFAULT NULL,
  `ActionText` varchar(50) DEFAULT NULL,
  `ShowIfInstalled` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  CONSTRAINT `Ads_NativeAds` FOREIGN KEY (`Id`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `objectactions`
--

DROP TABLE IF EXISTS `objectactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objectactions` (
  `ObjectActionId` int(11) NOT NULL AUTO_INCREMENT,
  `ObjectActionName` varchar(20) DEFAULT NULL,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`ObjectActionId`),
  KEY `lookup_name_objectactions_idx` (`NameId`),
  CONSTRAINT `lookup_name_objectactions` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `objectmetadata`
--

DROP TABLE IF EXISTS `objectmetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objectmetadata` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PropertyName` varchar(300) NOT NULL,
  `IsDeleted` tinyint(4) DEFAULT NULL,
  `Format` int(11) NOT NULL,
  `Visibility` int(11) NOT NULL,
  `ResourceSet` varchar(300) DEFAULT NULL,
  `ResourceKey` varchar(300) DEFAULT NULL,
  `objecttypeid` int(11) DEFAULT NULL,
  `subobjecttypeid` int(11) DEFAULT NULL,
  `objecttypestring` varchar(300) DEFAULT NULL,
  `objectsubtypestring` varchar(300) DEFAULT NULL,
  `MethodDescriper` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `objectypes_metadata_idx` (`objecttypeid`),
  KEY `sub_objectypes_metadata_idx` (`subobjecttypeid`),
  CONSTRAINT `objectypes_metadata` FOREIGN KEY (`objecttypeid`) REFERENCES `objecttypes` (`ObjectTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `sub_objectypes_metadata` FOREIGN KEY (`subobjecttypeid`) REFERENCES `objecttypes` (`ObjectTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4166 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `objecttypes`
--

DROP TABLE IF EXISTS `objecttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objecttypes` (
  `ObjectTypeId` int(11) NOT NULL,
  `ObjectTypeName` varchar(255) DEFAULT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Visibility` int(11) DEFAULT NULL,
  `RootID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ObjectTypeId`),
  KEY `lookup_name_objecttype_idx` (`NameId`),
  CONSTRAINT `lookup_name_objecttype` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `odc_calls`
--

DROP TABLE IF EXISTS `odc_calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `odc_calls` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Time` datetime NOT NULL,
  `TotalCalls` int(11) DEFAULT NULL,
  `FirstRetries` int(11) DEFAULT NULL,
  `ManyRetries` int(11) DEFAULT NULL,
  `InfiniteRetries` int(11) DEFAULT NULL,
  `NoMatches` int(11) DEFAULT NULL,
  `Errors` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Time_UNIQUE` (`Time`)
) ENGINE=InnoDB AUTO_INCREMENT=4205602 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operator_ips`
--

DROP TABLE IF EXISTS `operator_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operator_ips` (
  `Id` int(11) NOT NULL,
  `OperatorId` int(11) NOT NULL,
  `IPRangeStart` varbinary(16) NOT NULL,
  `IPRangeEnd` varbinary(16) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Operators` (`OperatorId`),
  CONSTRAINT `FK_Operators` FOREIGN KEY (`OperatorId`) REFERENCES `operators` (`OperatorId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operators`
--

DROP TABLE IF EXISTS `operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators` (
  `OperatorId` int(11) NOT NULL AUTO_INCREMENT,
  `OperatorNameId` int(11) DEFAULT NULL,
  `LocationId` int(11) DEFAULT NULL,
  `MobileNetworkCodes` varchar(100) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`OperatorId`),
  UNIQUE KEY `IX_Unique_LocationId_MobileNetworkCode` (`LocationId`,`MobileNetworkCodes`),
  KEY `Location_operators` (`LocationId`),
  CONSTRAINT `Location_operators` FOREIGN KEY (`LocationId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20201 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operatorsmapping`
--

DROP TABLE IF EXISTS `operatorsmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operatorsmapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `OperatorId` int(10) unsigned NOT NULL,
  `ISP` varchar(100) NOT NULL,
  `ORG` varchar(100) NOT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UNIQUE_IX` (`ISP`,`ORG`)
) ENGINE=MyISAM AUTO_INCREMENT=2406 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operatortargetings`
--

DROP TABLE IF EXISTS `operatortargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operatortargetings` (
  `Id` int(11) NOT NULL,
  `OperatorId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Operators_OperatorTragetings` (`OperatorId`),
  KEY `Id` (`Id`),
  KEY `IX_GROUPID` (`OperatorId`),
  CONSTRAINT `Operators_OperatorTragetings` FOREIGN KEY (`OperatorId`) REFERENCES `operators` (`OperatorId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Visible` bit(1) DEFAULT b'1',
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=353836 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paypal_account_payment_details`
--

DROP TABLE IF EXISTS `paypal_account_payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_account_payment_details` (
  `id` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `IsPrimary` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` varchar(45) NOT NULL,
  `CategorieNameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `lookup_adpermission_fk_idx` (`NameId`),
  KEY `CategorieName_Permissions_idx1` (`CategorieNameId`),
  CONSTRAINT `lookup_adpermission_fk` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Department_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pixel_adgroup_events`
--

DROP TABLE IF EXISTS `pixel_adgroup_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pixel_adgroup_events` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PixelId` int(11) NOT NULL,
  `AdGroupEventId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `pixel_adgroup_events__pixels_idx` (`PixelId`),
  KEY `pixel_adgroup_events__adgroup_events_fk_idx` (`AdGroupEventId`),
  CONSTRAINT `pixel_adgroup_events__adgroup_events_fk` FOREIGN KEY (`AdGroupEventId`) REFERENCES `adgroup_events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pixel_adgroup_events__pixels_fk` FOREIGN KEY (`PixelId`) REFERENCES `pixels` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5257 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pixel_audience_segments`
--

DROP TABLE IF EXISTS `pixel_audience_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pixel_audience_segments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PixelId` int(11) NOT NULL,
  `AudienceSegmentId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `pixel_audience_segments__audience_segments_idx` (`AudienceSegmentId`),
  KEY `pixel_audience_segments__pixels_idx` (`PixelId`),
  CONSTRAINT `pixel_audience_segments__audience_segments_fk` FOREIGN KEY (`AudienceSegmentId`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pixel_audience_segments__pixels_fk` FOREIGN KEY (`PixelId`) REFERENCES `pixels` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1417 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pixels`
--

DROP TABLE IF EXISTS `pixels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pixels` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Code` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Status` int(11) NOT NULL,
  `AccountAdvAssId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`),
  KEY `pixels__accounts_fk_idx` (`AccountId`),
  KEY `pixels__users_fk_idx` (`UserId`),
  KEY `pixels__advertiser_account_fk_idx` (`AccountAdvAssId`),
  CONSTRAINT `pixels__accounts_fk` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pixels__advertiser_account_fk` FOREIGN KEY (`AccountAdvAssId`) REFERENCES `advertiser_account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pixels__users_fk` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5455 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_version_mapping`
--

DROP TABLE IF EXISTS `platform_version_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_version_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PlatformId` int(11) NOT NULL,
  `InputValue` varchar(50) NOT NULL,
  `StandardValue` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platformcodes`
--

DROP TABLE IF EXISTS `platformcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platformcodes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PlatformId` int(11) DEFAULT NULL,
  `Code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Code_UNIQUE` (`Code`),
  KEY `platformcodes_PlatformId` (`PlatformId`),
  KEY `Platforms_FK` (`PlatformId`),
  CONSTRAINT `Platforms_FK` FOREIGN KEY (`PlatformId`) REFERENCES `platforms` (`PlatformId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platforms`
--

DROP TABLE IF EXISTS `platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platforms` (
  `PlatformId` int(11) NOT NULL AUTO_INCREMENT,
  `PlatformNameId` int(11) DEFAULT NULL,
  `IsVisible` bit(1) DEFAULT b'1',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`PlatformId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platformversions`
--

DROP TABLE IF EXISTS `platformversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platformversions` (
  `Id` int(11) NOT NULL,
  `PlatformId` int(11) NOT NULL,
  `Version` varchar(25) NOT NULL,
  `code` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`Id`),
  KEY `Platform_idx` (`PlatformId`),
  CONSTRAINT `Platform` FOREIGN KEY (`PlatformId`) REFERENCES `platforms` (`PlatformId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pmp_targetings`
--

DROP TABLE IF EXISTS `pmp_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pmp_targetings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `TypeId` smallint(6) NOT NULL DEFAULT 1,
  `PMPDealId` mediumint(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `PMPDeals_tragetings_idx` (`PMPDealId`),
  CONSTRAINT `PMPDeals_tragetings` FOREIGN KEY (`PMPDealId`) REFERENCES `buyer_deals` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pmpdeal_adsizetargetings`
--

DROP TABLE IF EXISTS `pmpdeal_adsizetargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pmpdeal_adsizetargetings` (
  `Id` int(11) NOT NULL,
  `AdSizeId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdSize_PMPDealAdSizeTragetings` (`AdSizeId`),
  KEY `Id` (`Id`),
  KEY `IPMPX_AdSizeID` (`AdSizeId`),
  CONSTRAINT `AdSize_PMPDealAdSizeTragetings` FOREIGN KEY (`AdSizeId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pmpdeal_adtypegroupetargetings`
--

DROP TABLE IF EXISTS `pmpdeal_adtypegroupetargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pmpdeal_adtypegroupetargetings` (
  `Id` int(11) NOT NULL,
  `AdGroupTypeId` smallint(6) NOT NULL DEFAULT 1,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdFormat_PMPDealAdFormatTragetings` (`AdGroupTypeId`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pmpdeal_geographictargetings`
--

DROP TABLE IF EXISTS `pmpdeal_geographictargetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pmpdeal_geographictargetings` (
  `Id` int(11) NOT NULL,
  `LocationId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Locations_PMPDealGeographicTragetings` (`LocationId`),
  KEY `Id` (`Id`),
  KEY `IPMPX_GROUPID` (`LocationId`),
  CONSTRAINT `Locations_PMPDealGeographicTragetings` FOREIGN KEY (`LocationId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_dimension_column`
--

DROP TABLE IF EXISTS `qb_bridge_dimension_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_dimension_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dimensionId` int(11) NOT NULL,
  `columnId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bridge_dimensions_d_idx` (`dimensionId`),
  KEY `bridge_column_c_idx` (`columnId`),
  CONSTRAINT `bridge_column_c` FOREIGN KEY (`columnId`) REFERENCES `qb_columns` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_dimension_c` FOREIGN KEY (`dimensionId`) REFERENCES `qb_dimensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_column`
--

DROP TABLE IF EXISTS `qb_bridge_fact_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factid` int(11) DEFAULT NULL,
  `colid` int(11) DEFAULT NULL,
  `isdeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_dimension`
--

DROP TABLE IF EXISTS `qb_bridge_fact_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_dimension` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factId` int(11) NOT NULL,
  `dimId` int(11) NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `fact_dim_idx` (`factId`),
  KEY `dim_fact_idx` (`dimId`),
  CONSTRAINT `bridge_dim_d` FOREIGN KEY (`dimId`) REFERENCES `qb_dimensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_fact_d` FOREIGN KEY (`factId`) REFERENCES `qb_facts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_measure`
--

DROP TABLE IF EXISTS `qb_bridge_fact_measure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_measure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factId` int(11) NOT NULL,
  `measurId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bridge_fact_idx` (`factId`),
  KEY `bridge_measure_idx` (`measurId`),
  CONSTRAINT `bridge_fact_m` FOREIGN KEY (`factId`) REFERENCES `qb_facts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_measure_m` FOREIGN KEY (`measurId`) REFERENCES `qb_measures` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_columns`
--

DROP TABLE IF EXISTS `qb_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `attribute` varchar(250) DEFAULT NULL,
  `dataType` int(11) DEFAULT 0,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `tableName` varchar(250) DEFAULT NULL,
  `fkSelector` varchar(250) DEFAULT NULL,
  `isSql` bit(1) NOT NULL DEFAULT b'1',
  `parentId` int(11) DEFAULT NULL,
  `orderNumber` int(11) NOT NULL DEFAULT 0,
  `isHidden` bit(1) DEFAULT b'0',
  `isDuplicated` bit(1) DEFAULT b'0',
  `alias` varchar(45) DEFAULT NULL,
  `homeIdSelector` varchar(45) DEFAULT 'id',
  `displayName` varchar(250) DEFAULT NULL,
  `source` varchar(250) DEFAULT NULL,
  `formatSQL` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29001 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_dimensions`
--

DROP TABLE IF EXISTS `qb_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_dimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `source` varchar(250) NOT NULL,
  `isSql` bit(1) NOT NULL DEFAULT b'1',
  `attributes` varchar(250) DEFAULT NULL,
  `filterCol` varchar(250) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `tableName` varchar(250) DEFAULT NULL,
  `selector` varchar(250) DEFAULT NULL,
  `customget` varchar(250) DEFAULT NULL,
  `isenum` bit(1) DEFAULT b'0',
  `isgrouped` bit(1) DEFAULT b'0',
  `isscoped` bit(1) DEFAULT b'0',
  `scopetablename` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`,`isDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_facts`
--

DROP TABLE IF EXISTS `qb_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_facts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `displayname` varchar(250) NOT NULL,
  `webdisplayname` varchar(250) NOT NULL,
  `isforweb` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_measures`
--

DROP TABLE IF EXISTS `qb_measures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_measures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `attribute` varchar(250) DEFAULT NULL,
  `dataType` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `orderNumber` int(11) NOT NULL DEFAULT 0,
  `isHidden` bit(1) DEFAULT b'1',
  `displayName` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `region_name_to_code_mapping`
--

DROP TABLE IF EXISTS `region_name_to_code_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_name_to_code_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CountryId` int(11) NOT NULL,
  `Name` varchar(500) NOT NULL,
  `FIPS_Code` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `regionnametcodemapping_locations_fk_idx` (`CountryId`),
  KEY `IX` (`CountryId`,`Name`),
  CONSTRAINT `regionnametcodemapping_locations_fk` FOREIGN KEY (`CountryId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11179 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_criteria`
--

DROP TABLE IF EXISTS `report_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_criteria` (
  `Id` int(11) NOT NULL,
  `UserId` int(11) DEFAULT NULL,
  `AccountId` int(11) DEFAULT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `Criteria` varchar(8024) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `SectionType` int(11) DEFAULT NULL,
  `ReportScope` int(11) DEFAULT NULL,
  `ForDashBoard` bit(1) DEFAULT NULL,
  `CriteriaName` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportrecipient`
--

DROP TABLE IF EXISTS `reportrecipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportrecipient` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) NOT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `ReportSchedulerId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ReportRecipient` (`Id`),
  KEY `ReportScheduler_Recipient_FK` (`ReportSchedulerId`),
  CONSTRAINT `ReportScheduler_Recipient_FK` FOREIGN KEY (`ReportSchedulerId`) REFERENCES `reportscheduler` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=51112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reportscheduler`
--

DROP TABLE IF EXISTS `reportscheduler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportscheduler` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(300) NOT NULL,
  `JobName` varchar(300) DEFAULT NULL,
  `PreferedName` varchar(300) DEFAULT NULL,
  `EmailIntroduction` varchar(1000) DEFAULT NULL,
  `TriggerName` varchar(300) DEFAULT NULL,
  `TriggerGroupName` varchar(300) DEFAULT NULL,
  `AccountId` int(11) NOT NULL,
  `ReportId` int(11) NOT NULL,
  `LastDocumnetGeneratedId` int(11) DEFAULT NULL,
  `MonthDay` int(11) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `LastRunningDate` datetime DEFAULT NULL,
  `NextFireTime` datetime DEFAULT NULL,
  `UpdateDate` datetime DEFAULT NULL,
  `UserId` int(11) DEFAULT NULL,
  `ReportCriteriaId` int(11) DEFAULT NULL,
  `TimeSentAt` datetime NOT NULL,
  `ReportJsonCriteria` varchar(8024) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `EmailSubject` varchar(300) DEFAULT NULL,
  `IsActive` bit(1) DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `IsSendNow` tinyint(1) DEFAULT 0,
  `IsFinished` tinyint(1) DEFAULT NULL,
  `DaysOfWeekParams` varchar(300) DEFAULT NULL,
  `IsScheduled` bit(1) DEFAULT NULL,
  `IsForQueryBuilder` bit(1) DEFAULT b'0',
  `RecurrenceType` tinyint(4) NOT NULL DEFAULT 1,
  `WeekDay` tinyint(4) NOT NULL DEFAULT 2,
  `ReportSectionType` tinyint(4) NOT NULL DEFAULT 1,
  `DateRecurrenceType` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `Account_ReportScheduler_FK` (`AccountId`),
  KEY `Document_ReportScheduler_FK` (`LastDocumnetGeneratedId`),
  KEY `reportscheduler` (`Id`),
  KEY `Criteria_ReportScheduler_idx` (`ReportCriteriaId`),
  CONSTRAINT `Account_ReportScheduler_FK` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Criteria_ReportScheduler` FOREIGN KEY (`ReportCriteriaId`) REFERENCES `report_criteria` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Document_ReportScheduler_FK` FOREIGN KEY (`LastDocumnetGeneratedId`) REFERENCES `documents` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47068 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `ResourceID` int(11) NOT NULL AUTO_INCREMENT,
  `ResourceSet` varchar(45) NOT NULL,
  `ResourceKey` varchar(100) NOT NULL,
  `CultureCode` char(5) NOT NULL,
  `ResourceValue` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`ResourceID`)
) ENGINE=InnoDB AUTO_INCREMENT=5323 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `richmedia_protocols`
--

DROP TABLE IF EXISTS `richmedia_protocols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `richmedia_protocols` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) NOT NULL,
  `Code` varchar(2) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rtb_partners`
--

DROP TABLE IF EXISTS `rtb_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rtb_partners` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(32) DEFAULT NULL,
  `AppsiteId` int(11) DEFAULT NULL,
  `DefaultSeatId` varchar(32) DEFAULT NULL,
  `OpenRtbVersion` varchar(10) DEFAULT NULL,
  `Description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `rtb_partners_appsite_fk` (`AppsiteId`),
  CONSTRAINT `rtb_partners_appsite_fk` FOREIGN KEY (`AppsiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_ad`
--

DROP TABLE IF EXISTS `runtime_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_ad` (
  `AdId` int(11) NOT NULL,
  `AdGroupId` int(11) NOT NULL,
  `Text` varchar(64) DEFAULT NULL,
  `LanguageId` int(11) DEFAULT NULL,
  `TypeId` int(11) NOT NULL,
  `SubTypeId` tinyint(4) DEFAULT NULL,
  `DisableProxyTraffic` tinyint(1) DEFAULT 0,
  `KeywordId` int(11) DEFAULT NULL,
  `URL` varchar(1024) DEFAULT NULL,
  `EnvironmentTypeId` tinyint(4) DEFAULT NULL,
  `OrientationTypeId` int(11) DEFAULT NULL,
  `DisplayCount` int(11) DEFAULT 0,
  `IsDeleted` bit(1) DEFAULT b'0',
  `TrackEndDate` datetime DEFAULT NULL,
  PRIMARY KEY (`AdId`),
  KEY `IX_GROUPID` (`AdGroupId`),
  KEY `IX_Id` (`AdId`,`LanguageId`,`URL`(255),`Text`,`DisplayCount`) USING BTREE,
  KEY `IX_MAIN` (`DisplayCount`,`LanguageId`,`TypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_appsite_ad_queue`
--

DROP TABLE IF EXISTS `runtime_appsite_ad_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_appsite_ad_queue` (
  `AppsiteId` int(11) NOT NULL,
  `AdId` int(11) NOT NULL,
  `Include` bit(1) DEFAULT NULL,
  UNIQUE KEY `IX_UNIQUE_KEY` (`AppsiteId`,`AdId`),
  KEY `IX_ADID` (`AdId`,`AppsiteId`) USING BTREE,
  KEY `IX_APP` (`AppsiteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_demographic_targetings`
--

DROP TABLE IF EXISTS `runtime_demographic_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_demographic_targetings` (
  `GroupId` int(11) NOT NULL,
  `GenderId` int(11) DEFAULT NULL,
  `AgeGroupId` int(11) DEFAULT NULL,
  KEY `IX_GROUPID` (`GroupId`,`GenderId`,`AgeGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_device_capability_targetings`
--

DROP TABLE IF EXISTS `runtime_device_capability_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_device_capability_targetings` (
  `GroupId` int(11) NOT NULL,
  `CapabilityId` int(11) NOT NULL,
  `Include` bit(1) NOT NULL,
  KEY `IX_Index` (`GroupId`,`Include`,`CapabilityId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_device_manufacturer_targetings`
--

DROP TABLE IF EXISTS `runtime_device_manufacturer_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_device_manufacturer_targetings` (
  `GroupId` int(11) NOT NULL,
  `ManufacturerId` int(11) NOT NULL,
  UNIQUE KEY `IX_UniqueKey` (`GroupId`,`ManufacturerId`),
  KEY `IX_GROUPID` (`GroupId`,`ManufacturerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_device_model_targetings`
--

DROP TABLE IF EXISTS `runtime_device_model_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_device_model_targetings` (
  `GroupId` int(11) NOT NULL,
  `ModelId` int(11) NOT NULL,
  `ManufacturerId` int(11) DEFAULT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `Include` bit(1) NOT NULL,
  KEY `IX_GROUPID` (`GroupId`,`Include`,`ModelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_device_platform_targetings`
--

DROP TABLE IF EXISTS `runtime_device_platform_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_device_platform_targetings` (
  `GroupId` int(11) NOT NULL,
  `PlatformId` int(11) NOT NULL,
  UNIQUE KEY `IX_UniqueKey` (`GroupId`,`PlatformId`),
  KEY `IX_GROUPID` (`GroupId`,`PlatformId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_device_type_targetings`
--

DROP TABLE IF EXISTS `runtime_device_type_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_device_type_targetings` (
  `GroupId` int(11) NOT NULL,
  `DeviceTypeId` int(11) NOT NULL,
  UNIQUE KEY `IX_UniqueKey` (`GroupId`,`DeviceTypeId`),
  KEY `IX_Index` (`GroupId`,`DeviceTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_geographic_targetings`
--

DROP TABLE IF EXISTS `runtime_geographic_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_geographic_targetings` (
  `GroupId` int(11) NOT NULL,
  `LocationId` int(11) NOT NULL,
  `LocationType` tinyint(4) NOT NULL,
  UNIQUE KEY `IX_UniqueKey` (`GroupId`,`LocationId`),
  KEY `IX_GROUPID` (`GroupId`,`LocationId`,`LocationType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_language_targetings`
--

DROP TABLE IF EXISTS `runtime_language_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_language_targetings` (
  `GroupId` int(11) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  UNIQUE KEY `IX_UniqueKey` (`GroupId`,`LanguageId`),
  KEY `IX_Index` (`GroupId`,`LanguageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runtime_operator_targetings`
--

DROP TABLE IF EXISTS `runtime_operator_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runtime_operator_targetings` (
  `GroupId` int(11) NOT NULL,
  `OperatorId` int(11) NOT NULL,
  UNIQUE KEY `IX_UNIQUEKEY` (`GroupId`,`OperatorId`),
  KEY `IX_GROUPID` (`GroupId`,`OperatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_content_categories`
--

DROP TABLE IF EXISTS `ssp_partner_content_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_content_categories` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `MappedIABContentCategoryId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerContentCategories_SSPPartners_FK_idx` (`PartnerId`),
  KEY `SSPPartnerContentCategories_IABContentCategories_FK_idx` (`MappedIABContentCategoryId`),
  CONSTRAINT `SSPPartnerContentCategories_IABContentCategories_FK` FOREIGN KEY (`MappedIABContentCategoryId`) REFERENCES `iab_content_categories` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartnerContentCategories_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_creative_attributes`
--

DROP TABLE IF EXISTS `ssp_partner_creative_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_creative_attributes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `MappedCreativeAttributeId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerCreativeAttributes_SSPPartners_FK_idx` (`PartnerId`),
  KEY `SSPPartnerCreativeAttributes_CreativeAttribute_FK_idx` (`MappedCreativeAttributeId`),
  CONSTRAINT `SSPPartnerCreativeAttributes_CreativeAttribute_FK` FOREIGN KEY (`MappedCreativeAttributeId`) REFERENCES `creative_attributes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartnerCreativeAttributes_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_creative_vendors`
--

DROP TABLE IF EXISTS `ssp_partner_creative_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_creative_vendors` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Codes` varchar(100) NOT NULL,
  `MappedCreativeVendorId` int(11) NOT NULL,
  `IsCertified` bit(1) NOT NULL,
  `IsDeclarable` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerCreativeVendors_SSPPartners_FK_idx` (`PartnerId`),
  KEY `SSPPartnerCreativeVendors_CreativeVendors_FK_idx` (`MappedCreativeVendorId`),
  CONSTRAINT `SSPPartnerCreativeVendors_CreativeVendors_FK` FOREIGN KEY (`MappedCreativeVendorId`) REFERENCES `creative_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartnerCreativeVendors_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=266 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_creativeunits`
--

DROP TABLE IF EXISTS `ssp_partner_creativeunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_creativeunits` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Width` int(11) NOT NULL,
  `Height` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerCreativeUnits_SSPPartners_FK_idx` (`PartnerId`),
  CONSTRAINT `SSPPartnerCreativeUnits_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_data_segments`
--

DROP TABLE IF EXISTS `ssp_partner_data_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_data_segments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Code` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `MinAcceptableWeight` float DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerDataSegments_SSPPartners_FK_idx` (`PartnerId`),
  CONSTRAINT `SSPPartnerDataSegments_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4597 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_data_segments_mapping`
--

DROP TABLE IF EXISTS `ssp_partner_data_segments_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_data_segments_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SSPPartnerDataSegmentId` int(11) NOT NULL,
  `AudienceSegmentId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerDataSegmentsMapping_AudienceSegments_FK_idx` (`AudienceSegmentId`),
  KEY `SSPPartnerDataSegmentsMapping_SSPPartnerDataSegments_FK_idx` (`SSPPartnerDataSegmentId`),
  CONSTRAINT `SSPPartnerDataSegmentsMapping_AudienceSegments_FK` FOREIGN KEY (`AudienceSegmentId`) REFERENCES `audience_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartnerDataSegmentsMapping_SSPPartnerDataSegments_FK` FOREIGN KEY (`SSPPartnerDataSegmentId`) REFERENCES `ssp_partner_data_segments` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12097 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_mobile_operators`
--

DROP TABLE IF EXISTS `ssp_partner_mobile_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_mobile_operators` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Code` varchar(100) NOT NULL,
  `MappedOperatorId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerMobileOperators_SSPPartners_FK_idx` (`PartnerId`),
  KEY `SSPPartnerMobileOperators_Operators_FK_idx` (`MappedOperatorId`),
  CONSTRAINT `SSPPartnerMobileOperators_Operators_FK` FOREIGN KEY (`MappedOperatorId`) REFERENCES `operators` (`OperatorId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartnerMobileOperators_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_supported_creative_formats`
--

DROP TABLE IF EXISTS `ssp_partner_supported_creative_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_supported_creative_formats` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `EnvironmentType` tinyint(4) NOT NULL COMMENT '1 - Web, 2 - App',
  `CreativeFormatId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ssppartnersupportedcreativeformats_ssppartners_fk_idx` (`PartnerId`),
  KEY `ssppartnersupportedcreativeformats_creativeformats_fk_idx` (`CreativeFormatId`),
  CONSTRAINT `ssppartnersupportedcreativeformats_creativeformats_fk` FOREIGN KEY (`CreativeFormatId`) REFERENCES `creative_formats` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ssppartnersupportedcreativeformats_ssppartners_fk` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5689 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_whitelist_ips`
--

DROP TABLE IF EXISTS `ssp_partner_whitelist_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_whitelist_ips` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `IP` varbinary(16) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerWhitelistIPs_SSPPartners_FK_idx` (`PartnerId`),
  CONSTRAINT `SSPPartnerWhitelistIPs_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partner_whitelist_org_isps`
--

DROP TABLE IF EXISTS `ssp_partner_whitelist_org_isps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partner_whitelist_org_isps` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `Organization` varchar(500) NOT NULL,
  `ISP` varchar(500) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SSPPartnerWhitelistORGISPs_SSPPartners_FK_idx` (`PartnerId`),
  CONSTRAINT `SSPPartnerWhitelistORGISPs_SSPPartners_FK` FOREIGN KEY (`PartnerId`) REFERENCES `ssp_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ssp_partners`
--

DROP TABLE IF EXISTS `ssp_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssp_partners` (
  `Id` int(11) NOT NULL,
  `AppSiteId` int(11) NOT NULL,
  `OpenRtbVersion` varchar(50) NOT NULL,
  `NumberOfSupportedImpressionTrackersInNative` int(11) NOT NULL DEFAULT 100,
  `NumberOfSupportedClickTrackersInNative` int(11) NOT NULL DEFAULT 100,
  `NumberOfSupportedVastWrapperLevels` int(11) DEFAULT 100,
  `NumberOfSupportedImpressionTrackersInPartnerMechanism` int(11) DEFAULT NULL,
  `AuctionPricePricingUnitId` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - CPM, 2 - CPI, 3 - CPI micros',
  `AuctionPriceEncryptionAlgorithmId` tinyint(4) DEFAULT NULL COMMENT '1 - HMAC_SHA1, 2 - Blowfish',
  `AuctionPriceEncryptionKey` varchar(500) DEFAULT NULL,
  `AuctionPriceIntegrityKey` varchar(500) DEFAULT NULL,
  `AuctionPriceMacroName` varchar(50) NOT NULL DEFAULT '${AUCTION_PRICE}',
  `AuctionPriceTestValue` varchar(50) DEFAULT NULL,
  `EncodedClickTrackerMacroName` varchar(50) DEFAULT NULL,
  `DoubleEncodedClickTrackerMacroName` varchar(50) DEFAULT NULL,
  `SupportWinNotice` bit(1) NOT NULL DEFAULT b'1',
  `FingerPrintAllowed` bit(1) DEFAULT b'1',
  `TaggingAllowed` bit(1) DEFAULT b'1',
  `DisallowGeofenceLessThanRadius` bit(1) DEFAULT b'0',
  `GeofenceRadius` int(11) DEFAULT NULL,
  `DeviceOSIdsIncludeValidUserId` varchar(500) DEFAULT NULL,
  `ReportUnfilledRequests` bit(1) DEFAULT NULL,
  `ImpressionSource` tinyint(4) DEFAULT 1 COMMENT '1 - Client\n2 - Server',
  `RequestThirdPartyAdSources` bit(1) DEFAULT b'0',
  `ThirdPartyAdSourcesMaximumResponseTime` int(11) DEFAULT NULL,
  `SupportUserSync` bit(1) NOT NULL DEFAULT b'0',
  `ResyncUserPeriod` int(11) DEFAULT NULL,
  `UserSyncPixel` varchar(2000) DEFAULT NULL,
  `NeedsCreativeApproval` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `AppSiteId_UNIQUE` (`AppSiteId`),
  KEY `SSPPartners_AppSite_FK_idx` (`AppSiteId`),
  CONSTRAINT `SSPPartners_AppSite_FK` FOREIGN KEY (`AppSiteId`) REFERENCES `appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SSPPartners_BusinessPartners_FK` FOREIGN KEY (`Id`) REFERENCES `business_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_appsite_keywords`
--

DROP TABLE IF EXISTS `sub_appsite_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_appsite_keywords` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SubAppSiteId` int(11) NOT NULL,
  `KeywordId` int(11) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UNIQUE_IX` (`SubAppSiteId`,`KeywordId`),
  KEY `subappsitekeywords_subappsits_fk_idx` (`SubAppSiteId`),
  KEY `subappsitekeywords_keywords_fk_idx` (`KeywordId`),
  CONSTRAINT `subappsitekeywords_keywords_fk` FOREIGN KEY (`KeywordId`) REFERENCES `keywords` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `subappsitekeywords_subappsits_fk` FOREIGN KEY (`SubAppSiteId`) REFERENCES `sub_appsites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25169965 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_appsites`
--

DROP TABLE IF EXISTS `sub_appsites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_appsites` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SubPublisherId` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `SubPublisherName` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SubPublisherUrl` varchar(5000) CHARACTER SET utf8 DEFAULT NULL,
  `SubPublisherMarketId` varchar(5000) CHARACTER SET utf8 DEFAULT NULL,
  `SubPublisherPartnerId` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `AppsiteId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CreatedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`SubPublisherId`)
) ENGINE=InnoDB AUTO_INCREMENT=125523943 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(512) DEFAULT NULL,
  `TypeResolver` varchar(512) DEFAULT NULL,
  `isActive` bit(1) DEFAULT NULL,
  `ApplicationId` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `Id` int(11) NOT NULL,
  `EventId` int(11) DEFAULT NULL,
  `SubscriberId` int(11) DEFAULT NULL,
  `MethodName` varchar(512) DEFAULT NULL,
  `isActive` bit(1) DEFAULT NULL,
  `IsAsync` bit(1) DEFAULT NULL,
  `IsTransactional` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Events_Subscription_EventId` (`EventId`),
  KEY `Events_Subscriber_SubscriberId` (`SubscriberId`),
  CONSTRAINT `Events_Subscriber_SubscriberId` FOREIGN KEY (`SubscriberId`) REFERENCES `subscribers` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Events_Subscription_EventId` FOREIGN KEY (`EventId`) REFERENCES `events` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subtypeactiontypes`
--

DROP TABLE IF EXISTS `subtypeactiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subtypeactiontypes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SubTypeId` int(11) NOT NULL,
  `AdTypeActionId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Subtype_idx` (`SubTypeId`),
  KEY `AdActiontype_idx` (`AdTypeActionId`),
  CONSTRAINT `subadtypeto_fk` FOREIGN KEY (`SubTypeId`) REFERENCES `adsubtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `subadtypetoactiontpe_fk` FOREIGN KEY (`AdTypeActionId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `targetings`
--

DROP TABLE IF EXISTS `targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targetings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdGroupId` int(11) DEFAULT NULL,
  `TypeId` smallint(6) NOT NULL DEFAULT 4,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `AdGroups_tragetings` (`AdGroupId`),
  CONSTRAINT `AdGroups_tragetings` FOREIGN KEY (`AdGroupId`) REFERENCES `adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1560679 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `targetingtype`
--

DROP TABLE IF EXISTS `targetingtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targetingtype` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `LocalizedString_TragetingType` (`NameId`),
  CONSTRAINT `LocalizedString_TragetingType` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templookupid`
--

DROP TABLE IF EXISTS `templookupid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templookupid` (
  `idtemplookupId` int(11) NOT NULL,
  `templookupIdcol` varchar(500) DEFAULT NULL,
  `templookupIdcol2` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idtemplookupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_native_ad_icons`
--

DROP TABLE IF EXISTS `test_native_ad_icons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_native_ad_icons` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TestNativeAdId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  `Url` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `testnativeadicons_testnativeads_fk_idx` (`TestNativeAdId`),
  KEY `testnativeadicons_mimetypes_fk_idx` (`MIMETypeId`),
  KEY `testnativeadicons_creativeunits_fk_idx` (`CreativeUnitId`),
  CONSTRAINT `testnativeadicons_creativeunits_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `testnativeadicons_mimetypes_fk` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `testnativeadicons_testnativeads_fk` FOREIGN KEY (`TestNativeAdId`) REFERENCES `test_native_ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_native_ad_images`
--

DROP TABLE IF EXISTS `test_native_ad_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_native_ad_images` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TestNativeAdId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  `Url` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `testnativeadimages_mimetypes_fk_idx` (`MIMETypeId`),
  KEY `testnativeadimages_creativeunits_fk_idx` (`CreativeUnitId`),
  KEY `testnativeadimages_testnativeads_fk1_idx` (`TestNativeAdId`),
  CONSTRAINT `testnativeadimages_creativeunits_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `testnativeadimages_mimetypes_fk` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `testnativeadimages_testnativeads_fk1` FOREIGN KEY (`TestNativeAdId`) REFERENCES `test_native_ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=611 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_native_ads`
--

DROP TABLE IF EXISTS `test_native_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_native_ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ActionTypeId` int(11) NOT NULL,
  `AdTitle` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `AppOpenUrl` varchar(500) DEFAULT NULL,
  `StarRating` int(11) DEFAULT NULL,
  `ActionText` varchar(50) DEFAULT NULL,
  `ShowIfInstalled` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Test_Native_Ads_ActionTypes_idx` (`ActionTypeId`),
  CONSTRAINT `FK_Test_Native_Ads_ActionTypes` FOREIGN KEY (`ActionTypeId`) REFERENCES `adactiontypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_richmedia_ads`
--

DROP TABLE IF EXISTS `test_richmedia_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_richmedia_ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdSubTypeId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `EnvironmentTypeId` int(11) DEFAULT NULL,
  `OrientationTypeId` int(11) DEFAULT NULL,
  `MraidProtocol` varchar(6) DEFAULT NULL,
  `Content` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_text_banner_plainhtml_ads`
--

DROP TABLE IF EXISTS `test_text_banner_plainhtml_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_text_banner_plainhtml_ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTypeId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `Content` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_video_ads`
--

DROP TABLE IF EXISTS `test_video_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_video_ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AdTitle` varchar(200) DEFAULT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `DurationInSeconds` int(11) NOT NULL,
  `VideoTypeId` int(11) NOT NULL,
  `DeliveryMethodId` int(11) NOT NULL,
  `BitRate` int(11) NOT NULL,
  `Width` int(11) NOT NULL,
  `Height` int(11) NOT NULL,
  `Url` varchar(5000) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `TestVideoAds_VideoDeliveryMethods_FK_idx` (`DeliveryMethodId`),
  CONSTRAINT `TestVideoAds_VideoDeliveryMethods_FK` FOREIGN KEY (`DeliveryMethodId`) REFERENCES `video_delivery_methods` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `textadthemes`
--

DROP TABLE IF EXISTS `textadthemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `textadthemes` (
  `TextAdThemeId` int(11) NOT NULL AUTO_INCREMENT,
  `TextColor` varchar(16) DEFAULT NULL,
  `BackgroundColor` varchar(16) DEFAULT NULL,
  `AdFalconTextColor` varchar(16) DEFAULT NULL,
  `IsCustom` tinyint(1) DEFAULT NULL,
  `NameId` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`TextAdThemeId`),
  KEY `Index` (`IsCustom`)
) ENGINE=InnoDB AUTO_INCREMENT=75553 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `textfilters`
--

DROP TABLE IF EXISTS `textfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `textfilters` (
  `Id` int(11) NOT NULL,
  `Text` varchar(512) NOT NULL,
  `MatchTypeId` int(11) NOT NULL,
  `AppSiteID` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `IX_AppSiteId` (`AppSiteID`,`MatchTypeId`,`IsDeleted`,`Text`(255)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tileimageformats`
--

DROP TABLE IF EXISTS `tileimageformats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tileimageformats` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Format` varchar(10) DEFAULT NULL,
  `TileImageSizeId` int(11) DEFAULT NULL,
  `MaxSize` int(10) unsigned DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `TileImageFormat_tileImageSize` (`TileImageSizeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tileimages`
--

DROP TABLE IF EXISTS `tileimages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tileimages` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `IsCustom` tinyint(1) DEFAULT 1,
  `IsClickAction` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `TitleImages_LocalizedStrings` (`NameId`),
  CONSTRAINT `TitleImages_LocalizedStrings` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32927 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tileimagesizedocuments`
--

DROP TABLE IF EXISTS `tileimagesizedocuments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tileimagesizedocuments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TileImageId` int(11) NOT NULL,
  `TileImageSizeId` int(11) NOT NULL,
  `DocumentId` int(11) DEFAULT NULL,
  `URL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `TitleImageId_TitleImages` (`TileImageId`),
  KEY `TitleImageSizeId_TitleImagesSizes` (`TileImageSizeId`),
  KEY `Documents_DocumentId` (`DocumentId`),
  CONSTRAINT `Documents_DocumentId` FOREIGN KEY (`DocumentId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32928 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tileimagesizes`
--

DROP TABLE IF EXISTS `tileimagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tileimagesizes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Width` smallint(6) NOT NULL,
  `Height` smallint(6) NOT NULL,
  `NameId` int(11) NOT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `DeviceTypeId` int(11) DEFAULT NULL,
  `IsActionTile` tinyint(1) DEFAULT 0,
  `TitleSizeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `tileimagesizes_devicetypes` (`DeviceTypeId`),
  KEY `tileimagesizes_tileimagesizes_TitleSizeId` (`TitleSizeId`),
  CONSTRAINT `tileimagesizes_devicetypes` FOREIGN KEY (`DeviceTypeId`) REFERENCES `devicetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tileimagesizes_tileimagesizes_TitleSizeId` FOREIGN KEY (`TitleSizeId`) REFERENCES `tileimagesizes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tracking_ads`
--

DROP TABLE IF EXISTS `tracking_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracking_ads` (
  `Id` int(11) NOT NULL,
  `PlatformId` int(11) DEFAULT NULL,
  `AppMarketingPartnerId` int(11) NOT NULL,
  `ClickTrackerUrl` varchar(5000) NOT NULL,
  `EnableEventsPostback` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `trackingadss_appmarketingpartners_fk_idx_idx` (`AppMarketingPartnerId`),
  KEY `trackingads_platform_fk_idx` (`PlatformId`),
  CONSTRAINT `trackingads_ads_fk` FOREIGN KEY (`Id`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `trackingads_platform_fk` FOREIGN KEY (`PlatformId`) REFERENCES `platforms` (`PlatformId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `trackingadss_appmarketingpartners_fk_idx` FOREIGN KEY (`AppMarketingPartnerId`) REFERENCES `app_marketing_partners` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `url_targetings`
--

DROP TABLE IF EXISTS `url_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_targetings` (
  `Id` int(11) NOT NULL,
  `URL` varchar(5000) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `urlfilters`
--

DROP TABLE IF EXISTS `urlfilters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `urlfilters` (
  `Id` int(11) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `AppSiteID` int(11) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `IX_APPSITEID` (`AppSiteID`,`URL`,`IsDeleted`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_accounts`
--

DROP TABLE IF EXISTS `user_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_accounts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `AccountId` int(11) NOT NULL,
  `IsSecondPrimaryUser` bit(1) NOT NULL DEFAULT b'0',
  `UserType` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`Id`),
  KEY `User_Account_idx` (`UserId`),
  KEY `Account_User_idx` (`AccountId`),
  CONSTRAINT `Account_User` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `User_Account` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=309700 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `useragents`
--

DROP TABLE IF EXISTS `useragents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useragents` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MD5Key` varchar(32) NOT NULL,
  `Name` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `MD5Key_UNIQUE` (`MD5Key`)
) ENGINE=InnoDB AUTO_INCREMENT=239278358 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) DEFAULT NULL,
  `EmailAddress` varchar(255) NOT NULL,
  `FirstName` varchar(32) NOT NULL,
  `LastName` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `ActivationCode` varchar(36) NOT NULL,
  `CountryId` int(11) NOT NULL,
  `State` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Address1` varchar(255) DEFAULT NULL,
  `Address2` varchar(255) DEFAULT '',
  `Company` varchar(255) DEFAULT '',
  `Phone` varchar(32) DEFAULT '',
  `Postal` varchar(16) DEFAULT '',
  `IsAllowNotifications` bit(1) NOT NULL,
  `LanguageId` int(11) NOT NULL,
  `RegistrationDate` datetime NOT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `PendingEmailAddress` varchar(255) DEFAULT '',
  `Block` bit(1) NOT NULL DEFAULT b'0',
  `RegistredIP` varbinary(68) DEFAULT NULL,
  `LastAccountLoginId` int(11) DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `UserResetToken` varchar(255) DEFAULT NULL,
  `TokenCreationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `EmailAddress_UNIQUE` (`EmailAddress`),
  KEY `EmailAddress` (`EmailAddress`),
  KEY `LanguageId` (`LanguageId`),
  KEY `CountryId` (`CountryId`),
  KEY `Status` (`StatusId`),
  KEY `Language` (`LanguageId`),
  KEY `AccountIdRelation` (`AccountId`),
  CONSTRAINT `AccountRelation` FOREIGN KEY (`AccountId`) REFERENCES `account` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CountryId` FOREIGN KEY (`CountryId`) REFERENCES `locations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Language` FOREIGN KEY (`LanguageId`) REFERENCES `languages` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=353230 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userstatus`
--

DROP TABLE IF EXISTS `userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstatus` (
  `Id` int(11) NOT NULL,
  `UserStatusNameId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `UserStatusNameId` (`UserStatusNameId`),
  CONSTRAINT `UserStatusNameId` FOREIGN KEY (`UserStatusNameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_ad_creative_unit_extension`
--

DROP TABLE IF EXISTS `video_ad_creative_unit_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_ad_creative_unit_extension` (
  `Id` int(11) NOT NULL,
  `DeliveryMethodId` int(11) NOT NULL,
  `BitRate` int(11) DEFAULT NULL,
  `Width` int(11) NOT NULL,
  `Height` int(11) NOT NULL,
  `ThumbnailDocId` int(11) DEFAULT NULL,
  `OriginalCreativeUnitId` int(11) DEFAULT NULL,
  `MIMETypeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `VideoAdCreativeUnits_VideoDeliveryMethods_FK` (`DeliveryMethodId`),
  KEY `ThumbnailDocId_Document_idx` (`ThumbnailDocId`),
  KEY `VideoAdCreativeUnits_MIMETypeIds_FK_idx` (`MIMETypeId`),
  CONSTRAINT `ThumbnailDocId_Document` FOREIGN KEY (`ThumbnailDocId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `VideoAdCreativeUnits_AdCreativeunits_FK` FOREIGN KEY (`Id`) REFERENCES `adcreativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `VideoAdCreativeUnits_MIMETypeIds_FK` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `VideoAdCreativeUnits_VideoDeliveryMethods_FK` FOREIGN KEY (`DeliveryMethodId`) REFERENCES `video_delivery_methods` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_ad_media_files`
--

DROP TABLE IF EXISTS `video_ad_media_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_ad_media_files` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoAdCreativeUnitId` int(11) NOT NULL,
  `MIMETypeId` int(11) NOT NULL,
  `DeliveryMethodId` int(11) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `BitRate` int(11) DEFAULT NULL,
  `Url` varchar(5000) DEFAULT NULL,
  `DocumentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `videoadmediafiles_videodeliverymethods_fk_idx` (`DeliveryMethodId`),
  KEY `videoadmediafiles_documents_fk_idx` (`DocumentId`),
  KEY `videoadmediafiles_creativeunits_fk_idx` (`CreativeUnitId`),
  KEY `videoadmediafiles_mimetypes_fk_idx` (`MIMETypeId`),
  KEY `videoadmediafiles_adcreativeunits_fk_idx` (`VideoAdCreativeUnitId`),
  CONSTRAINT `videoadmediafiles_adcreativeunits_fk` FOREIGN KEY (`VideoAdCreativeUnitId`) REFERENCES `adcreativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videoadmediafiles_creativeunits_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videoadmediafiles_documents_fk` FOREIGN KEY (`DocumentId`) REFERENCES `documents` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videoadmediafiles_mimetypes_fk` FOREIGN KEY (`MIMETypeId`) REFERENCES `mime_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videoadmediafiles_videodeliverymethods_fk` FOREIGN KEY (`DeliveryMethodId`) REFERENCES `video_delivery_methods` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=146251 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_ad_third_party_om_verifications`
--

DROP TABLE IF EXISTS `video_ad_third_party_om_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_ad_third_party_om_verifications` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoAdId` int(11) NOT NULL,
  `VendorId` varchar(200) NOT NULL,
  `ScriptUrl` varchar(2000) NOT NULL,
  `UrlParameters` varchar(2000) DEFAULT NULL,
  `ExecutionErrorTracker` varchar(2000) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `videoadomverifications_videoads_fk_idx` (`VideoAdId`),
  CONSTRAINT `videoadomverifications_videoads_fk` FOREIGN KEY (`VideoAdId`) REFERENCES `video_ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_ads`
--

DROP TABLE IF EXISTS `video_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_ads` (
  `Id` int(11) NOT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `DurationInSeconds` double NOT NULL,
  `CreateOptionId` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 - Upload Video File \n2 - Video VAST Tag',
  `IsDraft` bit(1) DEFAULT b'0',
  `VideoEndCardFluid` bit(1) DEFAULT b'0',
  `ThirdPartyTag` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  CONSTRAINT `VideoAds_Ads` FOREIGN KEY (`Id`) REFERENCES `ads` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_conversion_creativeunit`
--

DROP TABLE IF EXISTS `video_conversion_creativeunit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_conversion_creativeunit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(45) NOT NULL,
  `CreativeUnitId` int(11) NOT NULL,
  `BitRate` int(11) DEFAULT NULL,
  `AudioBitRate` int(11) DEFAULT NULL,
  `VideoFrameRate` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `dd_idx` (`CreativeUnitId`),
  CONSTRAINT `creative_video_conversion_unit_fk` FOREIGN KEY (`CreativeUnitId`) REFERENCES `creativeunits` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_delivery_methods`
--

DROP TABLE IF EXISTS `video_delivery_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_delivery_methods` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) NOT NULL,
  `Code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `VideoDeliveryMethod_LocalizedStringId` (`NameId`),
  CONSTRAINT `VideoDeliveryMethod_LocalizedStringId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_instream_positions`
--

DROP TABLE IF EXISTS `video_instream_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_instream_positions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_placement_types`
--

DROP TABLE IF EXISTS `video_placement_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_placement_types` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_playback_methods`
--

DROP TABLE IF EXISTS `video_playback_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_playback_methods` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_skippable_ad_options`
--

DROP TABLE IF EXISTS `video_skippable_ad_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_skippable_ad_options` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_targeting_instream_positions`
--

DROP TABLE IF EXISTS `video_targeting_instream_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_targeting_instream_positions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoTargetingId` int(11) NOT NULL,
  `InstreamPositionId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `videotargetingsinstreampositions_videotargetings_fk` (`VideoTargetingId`),
  KEY `videotargetingsinstreampositions_videoinstreampositions_fk` (`InstreamPositionId`),
  CONSTRAINT `videotargetingsinstreampositions_videoinstreampositions_fk` FOREIGN KEY (`InstreamPositionId`) REFERENCES `video_instream_positions` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videotargetingsinstreampositions_videotargetings_fk` FOREIGN KEY (`VideoTargetingId`) REFERENCES `video_targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3409 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_targeting_placement_types`
--

DROP TABLE IF EXISTS `video_targeting_placement_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_targeting_placement_types` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoTargetingId` int(11) NOT NULL,
  `PlacementTypeId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `videotargetingsplacementtypes_videotargetings_fk` (`VideoTargetingId`),
  KEY `videotargetingsplacementtypes_videoplacementtypes_fk` (`PlacementTypeId`),
  CONSTRAINT `videotargetingsplacementtypes_videoplacementtypes_fk` FOREIGN KEY (`PlacementTypeId`) REFERENCES `video_placement_types` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videotargetingsplacementtypes_videotargetings_fk` FOREIGN KEY (`VideoTargetingId`) REFERENCES `video_targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3418 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_targeting_playback_methods`
--

DROP TABLE IF EXISTS `video_targeting_playback_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_targeting_playback_methods` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoTargetingId` int(11) NOT NULL,
  `PlaybackMethodId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `videotargetingsplaybackmethods_videotargetings_fk` (`VideoTargetingId`),
  KEY `videotargetingsplaybackmethods_videoplaybackmethods_fk` (`PlaybackMethodId`),
  CONSTRAINT `videotargetingsplaybackmethods_videoplaybackmethods_fk` FOREIGN KEY (`PlaybackMethodId`) REFERENCES `video_playback_methods` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videotargetingsplaybackmethods_videotargetings_fk` FOREIGN KEY (`VideoTargetingId`) REFERENCES `video_targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3418 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_targeting_skippable_ad_options`
--

DROP TABLE IF EXISTS `video_targeting_skippable_ad_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_targeting_skippable_ad_options` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoTargetingId` int(11) NOT NULL,
  `SkippableAdOptionId` int(11) NOT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `videotargetingsskippableadoptions_videotargetings_fk` (`VideoTargetingId`),
  KEY `videotargetingsskippableadoptions_videoskippableadoptions_fk` (`SkippableAdOptionId`),
  CONSTRAINT `videotargetingsskippableadoptions_videoskippableadoptions_fk` FOREIGN KEY (`SkippableAdOptionId`) REFERENCES `video_skippable_ad_options` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `videotargetingsskippableadoptions_videotargetings_fk` FOREIGN KEY (`VideoTargetingId`) REFERENCES `video_targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2560 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_targetings`
--

DROP TABLE IF EXISTS `video_targetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_targetings` (
  `Id` int(11) NOT NULL,
  `AllowRewardedAd` bit(1) NOT NULL DEFAULT b'1',
  `RewardedAdOnly` bit(1) DEFAULT b'0',
  `MatchDeviceOrientation` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  CONSTRAINT `videotargetings_targetings_fk` FOREIGN KEY (`Id`) REFERENCES `targetings` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_types`
--

DROP TABLE IF EXISTS `video_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_types` (
  `Id` int(11) NOT NULL,
  `NameId` int(11) DEFAULT NULL,
  `Code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `VideoType_LocalizedStringId` (`NameId`),
  CONSTRAINT `VideoType_LocalizedStringId` FOREIGN KEY (`NameId`) REFERENCES `localizedstringids` (`LocalizedStringId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `viewability_vendor_creative_plugins`
--

DROP TABLE IF EXISTS `viewability_vendor_creative_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `viewability_vendor_creative_plugins` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ViewabilityVendorId` int(11) NOT NULL,
  `CreativeFormatId` int(11) NOT NULL,
  `SdkPlugin` varchar(5000) DEFAULT NULL,
  `NonSdkPlugin` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `viewabilityvendorcreativeplugins_viewabilityvendors_fk_idx` (`ViewabilityVendorId`),
  KEY `viewabilityvendorcreativeplugins_creativeformats_fk_idx` (`CreativeFormatId`),
  CONSTRAINT `viewabilityvendorcreativeplugins_creativeformats_fk` FOREIGN KEY (`CreativeFormatId`) REFERENCES `creative_formats` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `viewabilityvendorcreativeplugins_viewabilityvendors_fk` FOREIGN KEY (`ViewabilityVendorId`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `viewability_vendor_creative_plugins_backup`
--

DROP TABLE IF EXISTS `viewability_vendor_creative_plugins_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `viewability_vendor_creative_plugins_backup` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ViewabilityVendorId` int(11) NOT NULL,
  `CreativeFormatId` int(11) NOT NULL,
  `SdkPlugin` varchar(5000) DEFAULT NULL,
  `NonSdkPlugin` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `viewabilityvendorcreativeplugins_viewabilityvendors_fk_idx` (`ViewabilityVendorId`),
  KEY `viewabilityvendorcreativeplugins_creativeformats_fk_idx` (`CreativeFormatId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `viewability_vendors`
--

DROP TABLE IF EXISTS `viewability_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `viewability_vendors` (
  `Id` int(11) NOT NULL,
  `DefaultApiFramework` varchar(50) DEFAULT NULL,
  KEY `viewabilityvendors_metricvendors_fk_idx` (`Id`),
  CONSTRAINT `viewabilityvendors_metricvendors_fk` FOREIGN KEY (`Id`) REFERENCES `metric_vendors` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `x`
--

DROP TABLE IF EXISTS `x`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `uId` varchar(36) DEFAULT NULL,
  `AdGroupId` int(11) DEFAULT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `Name` varchar(255) NOT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `PausedStatusId` int(11) DEFAULT NULL,
  `Bid` decimal(21,12) DEFAULT 0.000000000000,
  `TypeId` int(11) DEFAULT NULL,
  `SubTypeId` tinyint(4) DEFAULT NULL COMMENT '1 - Expandable Rich Media\n2 - JavaScript Rich Media\n3 - JavaScript Interstitial\n4 - External Url Interstitial',
  `EnvironmentTypeId` tinyint(4) DEFAULT NULL COMMENT '1 - Web, 2 - App',
  `OrientationTypeId` int(11) DEFAULT NULL,
  `LanguageId` int(11) DEFAULT 1,
  `bannerType` tinyint(4) DEFAULT 1,
  `TileImageId` int(11) DEFAULT NULL,
  `AdText` varchar(40) DEFAULT NULL,
  `KeywordId` int(11) DEFAULT NULL,
  `DomainURL` varchar(1024) DEFAULT NULL,
  `IsSecureCompliant` bit(1) DEFAULT b'0',
  `AppStoreId` varchar(100) DEFAULT NULL,
  `ValidateRequestDeviceAndLocationData` bit(1) DEFAULT b'0',
  `VerifyTargetingCriteria` bit(1) DEFAULT b'1',
  `VerifyStartAndEndDate` bit(1) DEFAULT b'1',
  `VerifyDailyBudget` bit(1) DEFAULT b'1',
  `VerifyPrerequisiteEvents` bit(1) DEFAULT b'1',
  `VerifyEventsFrequency` bit(1) DEFAULT b'1',
  `UpdateEventsFrequency` bit(1) DEFAULT b'1',
  `UpdateTags` bit(1) DEFAULT b'1',
  `UpdatedByPortal` bit(1) DEFAULT NULL,
  `DataBid` decimal(21,12) DEFAULT NULL,
  `MaxDataBid` decimal(21,12) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `AdGroup` (`AdGroupId`),
  KEY `AdStatus` (`StatusId`),
  KEY `AdType` (`TypeId`),
  KEY `Bid` (`Bid`),
  KEY `TileImageId_TileImages` (`TileImageId`),
  KEY `PausedStatusId_FK` (`PausedStatusId`),
  KEY `Kewords_FK` (`KeywordId`),
  KEY `OrientationType_FK` (`OrientationTypeId`),
  KEY `ads_ads_fk_idx` (`ParentId`)
) ENGINE=InnoDB AUTO_INCREMENT=214828 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-07  8:25:30
