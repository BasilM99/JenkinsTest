-- MariaDB dump 10.17  Distrib 10.5.5-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: adfalcon
-- ------------------------------------------------------
-- Server version	10.5.5-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'adfalcon'
--
/*!50003 DROP PROCEDURE IF EXISTS `AccountAdvertiserAssociationGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountAdvertiserAssociationGetById`(IN inId int)
BEGIN

SELECT Id, AccountId, AdvertiserId, AgencyCommissionModel, AgencyCommissionModelValue FROM advertiser_account WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountBidConfigGetByAccountIdAndAppSiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountBidConfigGetByAccountIdAndAppSiteId`(in inAccountId int,in inAppsiteId int)
BEGIN

SELECT a.Id, a.TypeId, a.TargetingId, a.Value, b.Code EventCode
FROM account_bid_config a
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id
WHERE a.AccountId = inAccountId AND a.AppsiteId = inAppsiteId

UNION

SELECT a.Id, a.TypeId, a.TargetingId, a.Value, b.Code EventCode
FROM account_bid_config a
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id
WHERE a.AccountId = inAccountId AND a.AppsiteId IS NULL AND NOT EXISTS (SELECT 1 
                                                                        FROM account_bid_config c
                                                                        WHERE c.AccountId = inAccountId AND c.AppsiteId = inAppsiteId
                                                                        AND c.TypeId = a.TypeId AND c.TargetingId = a.TargetingId AND c.AdEventDefinitionId = a.AdEventDefinitionId);
                                                                        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountDiscountGetByAccountId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountDiscountGetByAccountId`(in inAccountId INT)
BEGIN

SELECT Discount, DiscountFromDate, DiscountToDate
FROM account_discount
WHERE AccountId = inAccountId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountGetById`(IN id int)
BEGIN

Select A.Id AccountId, A.DefaultRevenuePercentage, A.BuyerId, A.AgencyCommissionModel, A.AgencyCommissionModelValue,
S.Funds, S.Credit,
IFNULL(U.company, CONCAT(U.FirstName, ' ', U.LastName)) as AccountName
FROM account A 
LEFT JOIN accountsummary S ON A.Id = S.AccountId
LEFT JOIN users U on A.Id = U.AccountId AND A.PrimaryUserId = U.Id
Where A.Id = id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountIdsGetByODCZoneNames` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountIdsGetByODCZoneNames`(in inODCZoneNames varchar(5000))
BEGIN

SET @STMT_TEXT := CONCAT("select Id,ODCZoneName from account where ODCZoneName in (", inODCZoneNames, ");");

PREPARE stmt FROM @STMT_TEXT;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountIPsGetByAccountId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountIPsGetByAccountId`(in inAccountId INT)
BEGIN
SELECT IPRangeStart, IPRangeEnd FROM account_ips
WHERE AccountId = inAccountId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountKeywordMappingGetByAccountId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountKeywordMappingGetByAccountId`(in inAccountId int)
BEGIN

Select KeywordId, Code
FROM account_keyword_mapping 
WHERE AccountId = inAccountId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountKPIGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountKPIGetAll`()
BEGIN

SELECT Id, AdTypeFormatId, AccountId, DisplayRate, CTR, ConversionRate FROM account_kpis;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountMonthlyRevenueGetForAllMonths` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountMonthlyRevenueGetForAllMonths`(in inDateId int)
BEGIN

SET sql_big_selects = 1;

SELECT p.accountid AccountId,
Concat(u.FirstName, ' ', u.LastName) AccountName, 
u.EmailAddress Email,
u.Company Company, 
Concat(substring(p.dateid,5,2), '-', substring(p.dateid,1,4)) Month,
sum(p.revenue) Revenue
FROM adfalcon_stats_summary.fact_stat_app_month p
INNER JOIN users u ON p.accountid = u.accountid
WHERE p.dateid <= inDateId and p.revenue > 0
GROUP BY p.accountid,p.dateid
ORDER BY p.accountid,p.dateid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountMonthlyRevenueGetForLastMonth` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountMonthlyRevenueGetForLastMonth`(in inDateId int)
BEGIN

SET sql_big_selects = 1;

SELECT p.accountid AccountId,
Concat(u.FirstName, ' ', u.LastName) AccountName, 
u.EmailAddress Email,
u.Company Company, 
Concat(substring(p.dateid,5,2), '-', substring(p.dateid,1,4)) Month,
sum(p.revenue) Revenue
FROM adfalcon_stats_summary.fact_stat_app_month p
INNER JOIN users u ON p.accountid = u.accountid
WHERE p.dateid = inDateId and p.revenue > 0
GROUP BY p.accountid
ORDER BY p.accountid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountPaymentsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountPaymentsGet`(in inTillDate DateTime)
BEGIN

SELECT p. accountid AccountId,
Concat(u.FirstName, ' ', u.LastName) AccountName, 
u.EmailAddress Email,
u.Company Company,  
SUM(p.amount) Payments 
FROM account_payment_trans_history p 
INNER JOIN users u ON p.accountid = u.accountid
WHERE p.transactiondate <= inTillDate
GROUP BY p.accountid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AccountPaymentsMethodGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AccountPaymentsMethodGet`()
BEGIN

select account.id 'AccountId',CONCAT(users.FirstName,' ',users.lastname) 'AccountName',users.Company, users.emailaddress 'Email',
IFNUll((select case t.typeid when 2 then 'PayPal' 
	else 'Bank' 
	end PreferedPayment 
		from (
		select typeid, isdefault,accountId
		from account_payment_details account0 
		where
		account0.isactive =1  and 	account0.isdefault =1 
		order by isdefault desc
		) t
		where t.accountid = account.id
		limit 0,1),'') 'PreferedPayment',
(select paypal1.UserName from account_payment_details account1 inner join paypal_account_payment_details paypal1 on account1.id = paypal1.id where account1.AccountId = account.id and isactive =1 order by paypal1.IsPrimary desc,paypal1.id asc limit 0,1) 'PayPalId',
(select bank1.BankName from account_payment_details account2 inner join bank_account_payment_details bank1 on account2.Id = bank1.Id where account2.AccountId = account.id and isactive = 1 limit 0,1) 'BankName',
(select bank1.BankAddress from account_payment_details account2 inner join bank_account_payment_details bank1 on account2.Id = bank1.Id where account2.AccountId = account.id and isactive = 1 limit 0,1) 'BankAddress',
(select bank1.BeneficiaryName from account_payment_details account2 inner join bank_account_payment_details bank1 on account2.Id = bank1.Id where account2.AccountId = account.id and isactive = 1 limit 0,1) 'BeneficiaryName',
(select bank1.RecipientAccountNumber from account_payment_details account2 inner join bank_account_payment_details bank1 on account2.Id = bank1.Id where account2.AccountId = account.id and isactive = 1 limit 0,1) 'IBANNumber',
(select bank1.SWIFT from account_payment_details account2 inner join bank_account_payment_details bank1 on account2.Id = bank1.Id where account2.AccountId = account.id and isactive = 1 limit 0,1) SWIFT
from account
inner join users on users.AccountId = account.id
where account.id in ( select appsiteaccount.accountid from appsite appsiteaccount)
and account.id in (select AccountId from accountsummary where earning > 0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ActionTypeFilterGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ActionTypeFilterGetByAppsiteId`(IN inAppsiteId int)
BEGIN

SELECT ActionTypeId
FROM action_type_filters
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ActionTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ActionTypeGetAll`()
BEGIN

Select AC.Id, AC.Code, AC.ClickActionImageId from adactiontypes AC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ActionValueGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ActionValueGetByAdId`(in adId int)
BEGIN
Select Id, AdId, Value, AppLink 
from adactionvalues V
Where V.AdId = adId AND V.IsDeleted = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdActionValueTrackerGetByAdActionValueId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdActionValueTrackerGetByAdActionValueId`(IN inAdActionValueId INT)
BEGIN

SELECT Url
FROM ad_action_value_trackers 
WHERE AdActionValueId = inAdActionValueId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdAssignedAppsitesGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdAssignedAppsitesGetByAdId`(in inAdId int)
BEGIN

SELECT AppsiteId, Include FROM appsite_ad_queue WHERE AdId = inAdId AND AppsiteId != 74052; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitGetById`(IN id INT)
BEGIN

SELECT ACU.Id, ACU.UniqueId, ACU.AdId, ACU.CreativeUnitId, ACU.Content, ACU.SnapshotUrl, ACU.ImageType, ACU.CreativeProtocolId, ACU.Version
FROM adcreativeunits ACU
WHERE ACU.Id = id; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitGetByUniqueId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitGetByUniqueId`(IN inUniqueId VARCHAR(36))
BEGIN

SELECT ACU.Id, ACU.UniqueId, ACU.AdId, ACU.CreativeUnitId, ACU.Content, ACU.SnapshotUrl, ACU.ImageType, ACU.CreativeProtocolId, ACU.Version
FROM adcreativeunits ACU
WHERE ACU.UniqueId = inUniqueId; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitGetNeedSSPPartnerApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitGetNeedSSPPartnerApproval`(/*IN inSSPPartnerId int*/)
BEGIN

SELECT AC.Id FROM adcreativeunits AC
INNER JOIN ads A ON AC.AdId = A.Id
INNER JOIN adgroups G ON A.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
INNER JOIN account ACC ON C.AccountId = ACC.Id 
LEFT JOIN business_partners BP ON ACC.Id = BP.AccountId 
WHERE A.StatusId IN (4,10)/*Approved,Active*/ AND A.TypeId NOT IN (7,8)  
AND (BP.AccountId IS NULL OR BP.TypeId != 5) AND AC.IsDeleted = 0 AND AC.Id NOT IN (SELECT p.AdCreativeUnitId FROM ad_creative_unit_ssp_partner_approval p WHERE /* p.SSPPartnerId = inSSPPartnerId AND */ p.AdCreativeUnitVersion = AC.Version AND p.IsDeleted = 0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationGet`(IN inAdCreativeUnitSSPPartnerApprovalId int, IN inCreativeFormatId int)
BEGIN

SELECT Id, OpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus FROM ad_creative_unit_ssp_partner_approval_combinations WHERE AdCreativeUnitSSPPartnerApprovalId = inAdCreativeUnitSSPPartnerApprovalId AND CreativeFormatId = inCreativeFormatId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationNew`(IN inAdCreativeUnitSSPPartnerApprovalId int, IN inCreativeFormatId int, IN inAdm mediumtext, OUT outId int)
BEGIN

INSERT INTO ad_creative_unit_ssp_partner_approval_combinations (AdCreativeUnitSSPPartnerApprovalId, CreativeFormatId, Adm) VALUES (inAdCreativeUnitSSPPartnerApprovalId, inCreativeFormatId, inAdm);
Set outId = LAST_INSERT_ID();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationRejectReasonNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationRejectReasonNew`(IN inAdCreativeUnitSSPPartnerApprovalCombinationId int, IN inOpenAndPrivateAuctionReason varchar(500), 
                                                                                 IN inOpenAndPrivateAuctionDetails mediumtext, IN inPGAndPreferredDealsReason varchar(500), IN inPGAndPreferredDealsDetails mediumtext)
BEGIN

INSERT INTO ad_creative_unit_ssp_partner_approval_combination_reject_reasons (AdCreativeUnitSSPPartnerApprovalCombinationId, OpenAndPrivateAuctionReason, OpenAndPrivateAuctionDetails, PGAndPreferredDealsReason, PGAndPreferredDealsDetails) 
VALUES (inAdCreativeUnitSSPPartnerApprovalCombinationId, inOpenAndPrivateAuctionReason, inOpenAndPrivateAuctionDetails, inPGAndPreferredDealsReason, inPGAndPreferredDealsDetails)
On DUPLICATE KEY UPDATE 
AdCreativeUnitSSPPartnerApprovalCombinationId = VALUES(AdCreativeUnitSSPPartnerApprovalCombinationId),
OpenAndPrivateAuctionReason = VALUES(OpenAndPrivateAuctionReason),
OpenAndPrivateAuctionDetails = VALUES(OpenAndPrivateAuctionDetails),
PGAndPreferredDealsReason = VALUES(PGAndPreferredDealsReason),
PGAndPreferredDealsDetails = VALUES(PGAndPreferredDealsDetails);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationsGetAllPending` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationsGetAllPending`()
BEGIN

SELECT B.AdCreativeUnitId, B.AdCreativeUnitVersion, B.PartnerCreativeId, A.CreativeFormatId, B.SSPPartnerId FROM ad_creative_unit_ssp_partner_approval_combinations A 
INNER JOIN ad_creative_unit_ssp_partner_approval B ON A.AdCreativeUnitSSPPartnerApprovalId = B.Id
WHERE A.OpenAndPrivateAuctionStatus = 0 OR A.PGAndPreferredDealsStatus = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationsGetByParentId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationsGetByParentId`(IN inAdCreativeUnitSSPPartnerApprovalId int)
BEGIN

SELECT Id, OpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus FROM ad_creative_unit_ssp_partner_approval_combinations WHERE AdCreativeUnitSSPPartnerApprovalId = inAdCreativeUnitSSPPartnerApprovalId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalCombinationStatusUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalCombinationStatusUpdate`(IN inAdCreativeUnitSSPPartnerApprovalCombinationId int, IN inOpenAndPrivateAuctionStatus tinyint, IN inPGAndPreferredDealsStatus tinyint, IN inLastStatusUpdate datetime)
BEGIN

UPDATE ad_creative_unit_ssp_partner_approval_combinations SET OpenAndPrivateAuctionStatus = inOpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus = inPGAndPreferredDealsStatus, LastStatusUpdate = inLastStatusUpdate 
WHERE Id = inAdCreativeUnitSSPPartnerApprovalCombinationId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalDeactivateOld` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalDeactivateOld`(IN inAdCreativeUnitId int, IN inPartnerCreativeId varchar(200), IN inNewAdCreativeUnitVersion int, IN inSSPPartnerId int)
BEGIN

IF inPartnerCreativeId IS NULL THEN
 UPDATE ad_creative_unit_ssp_partner_approval SET IsDeleted = 1 WHERE AdCreativeUnitId = inAdCreativeUnitId AND AdCreativeUnitVersion < inNewAdCreativeUnitVersion AND SSPPartnerId = inSSPPartnerId;
ELSE 
 UPDATE ad_creative_unit_ssp_partner_approval SET IsDeleted = 1 WHERE AdCreativeUnitId = inAdCreativeUnitId AND PartnerCreativeId = inPartnerCreativeId AND AdCreativeUnitVersion < inNewAdCreativeUnitVersion AND SSPPartnerId = inSSPPartnerId;
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalGet`(IN inAdCreativeUnitId int, IN inPartnerCreativeId varchar(200), IN inAdCreativeUnitVersion int, IN inSSPPartnerId int)
BEGIN

IF inPartnerCreativeId IS NULL THEN
 SELECT Id, OpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus FROM ad_creative_unit_ssp_partner_approval WHERE AdCreativeUnitId = inAdCreativeUnitId AND AdCreativeUnitVersion = inAdCreativeUnitVersion AND SSPPartnerId = inSSPPartnerId AND IsDeleted = 0;
ELSE 
 SELECT Id, OpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus FROM ad_creative_unit_ssp_partner_approval WHERE AdCreativeUnitId = inAdCreativeUnitId AND PartnerCreativeId = inPartnerCreativeId AND AdCreativeUnitVersion = inAdCreativeUnitVersion AND SSPPartnerId = inSSPPartnerId AND IsDeleted = 0;
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalNew`(IN inAdCreativeUnitId int, IN inPartnerCreativeId varchar(200), IN inAdCreativeUnitVersion int, IN inSSPPartnerId int, OUT outId int)
BEGIN

IF inPartnerCreativeId IS NULL THEN
  INSERT INTO ad_creative_unit_ssp_partner_approval (AdCreativeUnitId, AdCreativeUnitVersion, SSPPartnerId) VALUES (inAdCreativeUnitId, inAdCreativeUnitVersion, inSSPPartnerId);
ELSE 
  INSERT INTO ad_creative_unit_ssp_partner_approval (AdCreativeUnitId, PartnerCreativeId, AdCreativeUnitVersion, SSPPartnerId) VALUES (inAdCreativeUnitId, inPartnerCreativeId, inAdCreativeUnitVersion, inSSPPartnerId);
END IF;

Set outId = LAST_INSERT_ID();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitPerSSPPartnerApprovalStatusUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitPerSSPPartnerApprovalStatusUpdate`(IN inAdCreativeUnitSSPPartnerApprovalId int, IN inOpenAndPrivateAuctionStatus tinyint, IN inPGAndPreferredDealsStatus tinyint)
BEGIN

UPDATE ad_creative_unit_ssp_partner_approval SET OpenAndPrivateAuctionStatus = inOpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus = inPGAndPreferredDealsStatus 
WHERE Id = inAdCreativeUnitSSPPartnerApprovalId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitsGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitsGetByAdId`(IN inAdId INT)
BEGIN

Select Id AdCreativeUnitId From adcreativeunits Where AdId = inAdId and IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitSSPPartnerApprovalGetByAdCreativeUnitId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitSSPPartnerApprovalGetByAdCreativeUnitId`(IN inAdCreativeUnitId int)
BEGIN

SELECT SSPPartnerId, PartnerCreativeId, OpenAndPrivateAuctionStatus, PGAndPreferredDealsStatus FROM ad_creative_unit_ssp_partner_approval WHERE AdCreativeUnitId = inAdCreativeUnitId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitTrackerGetByAdCreativeUnitId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitTrackerGetByAdCreativeUnitId`(IN inAdCreativeUnitId INT)
BEGIN

SELECT AGE.Code EventCode, ACUT.Url
FROM ad_creative_unit_trackers ACUT
INNER JOIN adgroup_events AGE ON ACUT.AdGroupEventId = AGE.Id
WHERE ACUT.AdCreativeUnitId = inAdCreativeUnitId AND ACUT.Type = 1  AND ACUT.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCreativeUnitViewGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCreativeUnitViewGetAll`(IN inCheckDate DateTime)
BEGIN

SELECT 
ACU.Id AdCreativeUnitId,
A.Id AdId,
A.StatusId,
G.Id AdGroupId,
C.Id CampaignId,
C.IsRuntime,
C.StartDate,
C.EndDate,
C.AccountId
FROM adcreativeunits ACU
INNER JOIN ads A ON ACU.AdId = A.Id
INNER JOIN adgroups G ON A.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
WHERE 
        (
         A.StatusId IN (4 , 10)
         OR ((C.EndDate IS NULL
         OR DATE_FORMAT(inCheckDate, '%Y%m%d') <= DATE_FORMAT(C.EndDate, '%Y%m%d'))
         AND A.StatusId NOT IN (6 , 1, 2, 3))
        )
        AND ACU.IsDeleted = 0
        AND A.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdCustomParameterGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdCustomParameterGetByAdId`(In inAdId INT)
BEGIN

SELECT Name, Value, IsMandatory FROM ad_custom_parameters WHERE AdId = inAdId and IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdEventDefinitionGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdEventDefinitionGetAll`()
BEGIN

SELECT Id, Code, DefaultFrequencyCapping, CapIfBillableOnly FROM ad_events_definition;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdFormatGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdFormatGetAll`()
BEGIN
Select F.Id, F.Code, F.Id_Hex from adformats F;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGetAllTrackUnfilled` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGetAllTrackUnfilled`()
BEGIN

SELECT A.Id AdId
FROM ads A
INNER JOIN adgroups G ON A.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
INNER JOIN campaign_adserver_settings CS ON C.Id = CS.CampaignId
WHERE CS.TrackUnfilled = 1 AND A.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGetById`(IN id int)
BEGIN

Select A.Id AdId, A.uId UniqueId, A.Name AdName, A.AdText, A.CreationDate, A.StatusId, A.Bid, A.TypeId, A.ParentId, G.DataPrice DataBid, G.MaxDataPrice MaxDataBid,  
A.SubTypeId, A.EnvironmentTypeId, A.OrientationTypeId, A.LanguageId, A.TileImageId, A.AdGroupId, A.IsSecureCompliant, A.AppStoreId, A.ValidateRequestDeviceAndLocationData,
A.VerifyTargetingCriteria, A.VerifyStartAndEndDate, A.VerifyDailyBudget, A.VerifyPrerequisiteEvents, A.VerifyEventsFrequency, A.UpdateEventsFrequency, A.UpdateAudienceList,
N.Description NativeAdDescription, N.AppOpenUrl, N.StarRating, N.ActionText, N.ShowIfInstalled,
V.DurationInSeconds, V.Description VideoAdDescription, V.CreateOptionId, V.ThirdPartyTag,
TRK.AppMarketingPartnerId, TRK.EnableEventsPostback, 
C.TypeId 'CompanionAdTypeId', C.EnableAutoClose, C.AutoCloseWaitInSeconds
FROM ads A
INNER JOIN adgroups G ON A.AdGroupId = G.Id
LEFT JOIN native_ads N ON A.Id = N.Id
LEFT JOIN video_ads V ON A.Id = V.Id
LEFT JOIN tracking_ads TRK ON A.Id = TRK.Id
LEFT JOIN companion_ads C ON A.Id = C.Id
WHERE A.Id = id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGetByUniqueId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGetByUniqueId`(IN inUniqueId VARCHAR(36))
BEGIN

Select A.Id AdId, A.uId UniqueId, A.Name AdName, A.AdText, A.CreationDate, A.StatusId, A.Bid, A.TypeId, A.ParentId, G.DataPrice DataBid, G.MaxDataPrice MaxDataBid, 
A.SubTypeId, A.EnvironmentTypeId, A.OrientationTypeId, A.LanguageId, A.TileImageId, A.AdGroupId, A.IsSecureCompliant, A.AppStoreId, A.ValidateRequestDeviceAndLocationData,
A.VerifyTargetingCriteria, A.VerifyStartAndEndDate, A.VerifyDailyBudget, A.VerifyPrerequisiteEvents, A.VerifyEventsFrequency, A.UpdateEventsFrequency, A.UpdateAudienceList,
N.Description NativeAdDescription, N.AppOpenUrl, N.StarRating, N.ActionText, N.ShowIfInstalled,
V.DurationInSeconds, V.Description VideoAdDescription, V.CreateOptionId, V.ThirdPartyTag,
TRK.AppMarketingPartnerId, TRK.EnableEventsPostback, 
C.TypeId 'CompanionAdTypeId', C.EnableAutoClose, C.AutoCloseWaitInSeconds
FROM ads A
INNER JOIN adgroups G ON A.AdGroupId = G.Id
LEFT JOIN native_ads N ON A.Id = N.Id
LEFT JOIN video_ads V ON A.Id = V.Id
LEFT JOIN tracking_ads TRK ON A.Id = TRK.Id
LEFT JOIN companion_ads C ON A.Id = C.Id
WHERE A.uId = inUniqueId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupAssignedAppSitesGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupAssignedAppSitesGet`(in inAdGroupId int)
BEGIN

IF EXISTS (SELECT 1 FROM adgroup_assigned_appsites WHERE AdGroupId = inAdGroupId AND IsDeleted = 0) THEN

SELECT AppSiteId, SubAppSiteId, Include FROM adgroup_assigned_appsites 
WHERE AdGroupId = inAdGroupId AND IsDeleted = 0;

ELSE

SET @CampaignId = (SELECT CampaignId FROM adgroups WHERE Id = inAdGroupId AND IsDeleted = 0);

SELECT AppSiteId, SubAppSiteId, Include FROM adgroup_assigned_appsites 
WHERE CampaignId = @CampaignId AND AdGroupId IS NULL AND IsDeleted = 0;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupBidConfigGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupBidConfigGet`(in inAdGroupId int)
BEGIN

SELECT AccountId, AppSiteId, SubAppSiteId, Bid 
FROM adgroup_bid_config
WHERE AdGroupId = inAdGroupId and IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupBidModifiersGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupBidModifiersGet`(in inAdGroupId int)
BEGIN

IF EXISTS (SELECT 1 FROM adgroup_bid_modifiers WHERE AdGroupId = inAdGroupId AND IsDeleted = 0) THEN

SELECT DimensionType, DimensionValue, Multiplier FROM adgroup_bid_modifiers 
WHERE AdGroupId = inAdGroupId AND IsDeleted = 0;

ELSE

SET @CampaignId = (SELECT CampaignId FROM adgroups WHERE Id = inAdGroupId AND IsDeleted = 0);

SELECT DimensionType, DimensionValue, Multiplier FROM adgroup_bid_modifiers 
WHERE CampaignId = @CampaignId AND AdGroupId IS NULL AND IsDeleted = 0;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupDynamicBiddingConfigGetByAdGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupDynamicBiddingConfigGetByAdGroupId`(IN inAdGroupId INT)
BEGIN

SELECT AdGroupId, BidOptimizationType, BidOptimizationValue, DefaultBidPrice, MaxBidPrice, MinBidPrice, BidStep, KeepBiddingAtMinimum
FROM adgroup_dynamic_bidding_config
WHERE AdGroupId = inAdGroupId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupEventAudienceSegmentGetByAdGroupEventId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupEventAudienceSegmentGetByAdGroupEventId`(IN inAdGroupEventId INT)
BEGIN

SELECT AudienceSegmentId
FROM adgroup_event_audience_segments 
WHERE AdGroupEventId = inAdGroupEventId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupEventGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupEventGetById`(IN inId INT)
BEGIN

SELECT Id, Code, Name, AdGroupId, PrerequisiteIds, AllPrerequisitesRequired, AllowDuplicate, StatColumnName, IsBillable, IsPrimary, IsConversion, Revenue, IsDeleted
FROM adgroup_events
WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupEventsGetByAdGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupEventsGetByAdGroupId`(IN inAdGroupId INT)
BEGIN

SELECT Id
FROM adgroup_events
WHERE AdGroupId = inAdGroupId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupEventsGetByPixelId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupEventsGetByPixelId`(IN inPixelId INT)
BEGIN

SELECT AdGroupEventId FROM pixel_adgroup_events WHERE PixelId = inPixelId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupFrequencyCappingSettingsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupFrequencyCappingSettingsGet`(in inAdGroupId int)
BEGIN

IF EXISTS (SELECT 1 FROM campaign_frequency_capping_settings WHERE AdGroupId = inAdGroupId) THEN

SELECT a.AdGroupId, b.Code EventCode, a.FrequencyCappingType, a.FrequencyCappingNumber, a.FrequencyCappingInterval
FROM campaign_frequency_capping_settings a 
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id 
WHERE a.AdGroupId = inAdGroupId;

ELSE

SET @CampaignId = (SELECT CampaignId FROM adgroups WHERE Id = inAdGroupId AND IsDeleted = 0);

SELECT a.AdGroupId, b.Code EventCode, a.FrequencyCappingType, a.FrequencyCappingNumber, a.FrequencyCappingInterval
FROM campaign_frequency_capping_settings a 
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id
WHERE a.CampaignId = @CampaignId AND a.AdGroupId IS NULL;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupGetById`(IN id INT)
BEGIN

SELECT G.Id AdGroupId, G.UniqueId, G.Name AdGroupName, G.CampaignId, G.CreationDate, G.DisableProxyTraffic, G.OpenInExternalBrowser, G.CPMValue, G.AllowOpenAuction, 
G.StickToDealBidFloor, G.ViewabilityVendorId, G.DisableViewabilityVendors, G.ConnectionType, G.Budget, G.DailyBudget, G.DataPrice, G.MaxDataPrice, G.LogAdMarkup, G.CostModelWrapperId,
G.MinimumUnitPrice, G.BiddingStrategy, G.AdPosition, G.AttributionType, G.ImpressionAttributionWindow, G.ClickAttributionWindow, G.AllowAllGeoTypeSources, 
AGO.ObjectiveTypeId
FROM adgroups G
INNER JOIN adgroupobjectives AGO ON AGO.AdGroupId = G.Id
WHERE G.Id = id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupIdsGetByCostItemId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupIdsGetByCostItemId`(in inCostItemId INT)
BEGIN

Select ACI.AdGroupId 
From adgroup_cost_items ACI
Where ACI.CostItemId = inCostItemId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupsGetByCampaignId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupsGetByCampaignId`(IN inCampaignId INT)
BEGIN

SELECT G.Id FROM adgroups G
INNER JOIN campaigns C ON G.CampaignId = C.Id 
WHERE C.Id = inCampaignId AND G.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdGroupTargetingGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdGroupTargetingGetAll`(IN inAdGroupId INT)
BEGIN

SELECT x.LocationId CountryId FROM geographictargetings x 
INNER JOIN targetings t ON x.id = t.id 
INNER JOIN locations l ON x.LocationId = l.Id
WHERE t.adgroupid = inAdGroupId AND l.LocationType = 2;

SELECT x.LocationId RegionId FROM geographictargetings x 
INNER JOIN targetings t ON x.id = t.id 
INNER JOIN locations l ON x.LocationId = l.Id
WHERE t.adgroupid = inAdGroupId AND l.LocationType = 3;

SELECT x.OperatorId FROM operatortargetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.KeywordId, x.Include FROM keywordtargetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.Id DemographicId, x.GenderId, x.AgeGroupId FROM demographictargeting x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.IPRangeStart, x.IPRangeEnd FROM ip_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.ManufacturerId, x.IsAll FROM devicetargetingmanufacturers x INNER JOIN devicetargetings dt ON dt.Id = x.DeviceTargetingId INNER JOIN targetings t ON t.id = dt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.DeviceId ModelId, x.Include FROM devicetargetingdevices x INNER JOIN devicetargetings dt ON dt.Id = x.DeviceTargetingId INNER JOIN targetings t ON t.id = dt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.PlatformId, x.PlatformMinimumVersion, x.PlatformMaximumVersion, x.IsAll FROM devicetargetingplatforms x INNER JOIN devicetargetings dt ON dt.Id = x.DeviceTargetingId INNER JOIN targetings t ON t.id = dt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.CapabilityId, x.Include FROM device_targeting_device_capabilities x INNER JOIN devicetargetings dt ON dt.Id = x.DeviceTargetingId INNER JOIN targetings t ON t.id = dt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.DeviceTypeId FROM device_targeting_type x INNER JOIN devicetargetings dt ON dt.Id = x.DeviceTargetingId INNER JOIN targetings t ON t.id = dt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.URL FROM url_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.Latitude, x.Longitude, x.Radius FROM geofencing_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT c.Code RequestVersionTypeCode, d.Code RequestVersionPlatformCode, a.MinimumVersion 
FROM adrequest_version_targetings a 
INNER JOIN targetings b ON a.Id = b.Id 
INNER JOIN adrequest_version_types c ON a.RequestVersionTypeId = c.Id 
INNER JOIN adrequest_version_platforms d ON a.RequestVersionPlatformId = d.Id 
WHERE b.AdGroupId = inAdGroupId;

SELECT x.DealId FROM buyer_deal_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.RulesJson, x.DataPrice, x.MaxDataPrice, x.Options FROM audience_segment_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.ImpressionMetricId, x.MetricVendorId, x.MinValue, x.IgnoreIfNotAvailable FROM impression_metric_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.LanguageId FROM language_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.AllowRewardedAd, x.RewardedAdOnly, x.MatchDeviceOrientation FROM video_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.PlacementTypeId FROM video_targeting_placement_types x INNER JOIN video_targetings vt ON vt.Id = x.VideoTargetingId INNER JOIN targetings t ON t.id = vt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.InstreamPositionId FROM video_targeting_instream_positions x INNER JOIN video_targetings vt ON vt.Id = x.VideoTargetingId INNER JOIN targetings t ON t.id = vt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.SkippableAdOptionId FROM video_targeting_skippable_ad_options x INNER JOIN video_targetings vt ON vt.Id = x.VideoTargetingId INNER JOIN targetings t ON t.id = vt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.PlaybackMethodId FROM video_targeting_playback_methods x INNER JOIN video_targetings vt ON vt.Id = x.VideoTargetingId INNER JOIN targetings t ON t.id = vt.id
WHERE t.adgroupid = inAdGroupId;

SELECT x.ListId FROM content_list_targeting x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

SELECT x.ContextualSegmentId, x.Include FROM contextual_segment_targetings x INNER JOIN targetings t ON x.id = t.id 
WHERE t.adgroupid = inAdGroupId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdServerBroadcastReceiverGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdServerBroadcastReceiverGetAll`()
BEGIN

SELECT Id, BroadcastReceiverServiceUrl FROM adserver_broadcast_receivers;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdserverFailedBroadcastEntityUpdateDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdserverFailedBroadcastEntityUpdateDelete`(IN inId INT)
BEGIN

DELETE FROM adserver_failed_broadcast_entity_updates WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdServerFailedBroadcastEntityUpdateGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdServerFailedBroadcastEntityUpdateGetAll`()
BEGIN

SELECT Id, EntityType, EntityIdentifier, BroadcastReceiverId FROM adserver_failed_broadcast_entity_updates;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdserverFailedBroadcastEntityUpdateInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdserverFailedBroadcastEntityUpdateInsert`(IN inEntityType INT, IN inEntityIdentifier VARCHAR(5000),IN inBroadcastReceiverId INT)
BEGIN

INSERT INTO adserver_failed_broadcast_entity_updates (EntityType, EntityIdentifier, BroadcastReceiverId)
VALUES (inEntityType, inEntityIdentifier, inBroadcastReceiverId);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdServerMaintenanceJobClosedDateGetByType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdServerMaintenanceJobClosedDateGetByType`(in inType int)
BEGIN
SELECT LastClosedDate, Type
FROM adserver_maintenance_job_closed_dates
WHERE Type = inType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdServerMaintenanceJobClosedDateUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdServerMaintenanceJobClosedDateUpdate`(in inType int, in inLastClosedDate DATETIME)
BEGIN

Update adserver_maintenance_job_closed_dates SET LastClosedDate = inLastClosedDate WHERE Type = inType;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdsGetByAdGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdsGetByAdGroupId`(IN inAdGroupId INT)
BEGIN

Select Id AdId From ads Where AdGroupId = inAdGroupId and IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdStatGetByDateTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdStatGetByDateTime`(in closedDateId int, in closedTimeId int,in toDateId int, in toTimeId int)
BEGIN

Select AccountID, DimCampaignID, adsGroupID, adsID, AdsSpend, DimDateID, DimTimeKey, Impression, Clicks,
DimManufacturerID,DimDeviceID,DimPlatformID,DimCountryID,DimOperatorID,DimCityID,DimChannelID 
FROM fact_stat_campaign 
WHERE 
((closedDateId IS NULL AND closedTimeId IS NULL) OR (DimDateID > closedDateId) OR (DimDateID = closedDateId AND DimTimeKey > closedTimeId))
AND (DimDateID < toDateId OR (DimDateID = toDateId AND DimTimeKey <= toTimeId));


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdStatGetByPaging` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdStatGetByPaging`(in pageIndex int, in pageSize int,in toDateId int, in toTimeId int)
BEGIN

Select AccountID, DimCampaignID, adsGroupID, adsID, AdsSpend, DimDateID, DimTimeKey, Impression, Clicks,
DimManufacturerID,DimDeviceID,DimPlatformID,DimCountryID,DimOperatorID,DimCityID,DimChannelID
from fact_stat_campaign 
WHERE (DimDateID < toDateId OR (DimDateID = toDateId AND DimTimeKey <= toTimeId)) limit pageIndex,pageSize;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdStatusGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdStatusGetAll`()
BEGIN

select S.Id, S.Code from  adstatus S;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdStatusGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdStatusGetById`(in inStatusId INT)
BEGIN

select S.Id, S.Code from  adstatus S where S.Id = inStatusId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdTrackingInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdTrackingInsert`(in inRequestId varchar(64), in inRequestDate DateTime, in inIP int(15))
BEGIN

 INSERT INTO ad_tracking (RequestId,RequestDate,IP) VALUES (inRequestId,inRequestDate,inIP);
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdTypeGetAll`()
BEGIN

Select T.Id, T.Code from adtypes T ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdvertiserAccountIdsGetByODCZoneNames` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdvertiserAccountIdsGetByODCZoneNames`(in inODCZoneNames varchar(5000))
BEGIN

SET @STMT_TEXT := CONCAT("select Id,ODCZoneName from advertiser_account where ODCZoneName in (", inODCZoneNames, ");");

PREPARE stmt FROM @STMT_TEXT;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdvertiserGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdvertiserGetAll`()
BEGIN

SELECT a.Id, a.UniqueId, a.DomainUrl, 
(select b.value from localizedstrings b where a.NameId = b.localizedstringid and b.Culture = 'ar-JO') NameAR,
(select b.value from localizedstrings b where a.NameId = b.localizedstringid and b.Culture = 'en-US') NameEN 
FROM advertisers a;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdvertiserGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdvertiserGetById`(IN inId int)
BEGIN

SELECT a.Id, a.UniqueId, a.DomainUrl, 
(select b.value from localizedstrings b where a.NameId = b.localizedstringid and b.Culture = 'ar-JO') NameAR,
(select b.value from localizedstrings b where a.NameId = b.localizedstringid and b.Culture = 'en-US') NameEN 
FROM advertisers a WHERE a.Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdViewGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdViewGetAll`()
BEGIN

SELECT 
AD.Id AdId,
AD.StatusId,
G.Id AdGroupId,
G.Budget AdGroupBudget,
G.DailyBudget AdGroupDailyBudget,
(SELECT GP1.BillableCost FROM adgroupsperformance GP1 where GP1.AdGroupId = G.Id AND GP1.Day = (SELECT MAX(GP2.Day) FROM adgroupsperformance GP2 WHERE GP2.AdGroupId = G.Id)) AdGroupDailySpend,
(SELECT SUM(GP.BillableCost) FROM adgroupsperformance GP WHERE GP.AdGroupId = G.Id) AdGroupSpend,
(SELECT MAX(GP.Day) FROM adgroupsperformance GP WHERE GP.AdGroupId = G.Id) AdGroupMaxDay,
C.Id CampaignId,
C.Budget CampaignBudget,
C.DailyBudget CampaignDailyBudget,
C.IsRuntime,
C.StartDate,
C.EndDate,
(SELECT CP1.BillableCost FROM campaignsperformance CP1 where CP1.CampaignId = C.Id AND CP1.Day = (SELECT MAX(CP2.Day) FROM campaignsperformance CP2 WHERE CP2.CampaignId = C.Id)) CampaignDailySpend,
(SELECT SUM(CP.BillableCost) FROM campaignsperformance CP WHERE CP.CampaignId = C.Id) CampaignSpend,
(SELECT MAX(CP.Day) FROM campaignsperformance CP WHERE CP.CampaignId = C.Id) CampaignMaxDay,
C.AccountId,
ACCS.Funds,
ACCS.Credit
FROM ads AD
INNER JOIN adgroups G ON AD.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
INNER JOIN accountsummary ACCS ON C.AccountId = ACCS.AccountId
WHERE AD.StatusId NOT IN (6,1,2,3) 
AND AD.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AdViewGetAll_New` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AdViewGetAll_New`(IN inCheckDate DateTime)
BEGIN

SELECT 
A.Id AdId,
A.StatusId,
G.Id AdGroupId,
C.Id CampaignId,
C.IsRuntime,
C.StartDate,
C.EndDate,
C.AccountId
FROM ads A
INNER JOIN adgroups G ON A.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
WHERE  (C.EndDate IS NULL OR DATE_FORMAT(inCheckDate, '%Y%m%d') <= DATE_FORMAT(C.EndDate, '%Y%m%d'))
AND A.StatusId NOT IN (6, 1, 2, 3)  
AND A.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AgeGroupGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AgeGroupGetAll`()
BEGIN

Select AG.ID, AG.MinValue, AG.MaxValue, AG.Id_Hex from agegroup AG ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AlterLogTables` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AlterLogTables`(IN inStartDate DATETIME,IN inEndDate DATETIME)
BEGIN

WHILE inStartDate <= inEndDate DO

SET @STMT_TEXT := CONCAT("ALTER TABLE trans_ad_log_", DATE_FORMAT(inStartDate, '%Y_%m_%d'), " ADD COLUMN CampaignType TINYINT NULL  AFTER TransType") ;

PREPARE stmt FROM @STMT_TEXT;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET inStartDate := DATE_ADD(inStartDate, INTERVAL 1 DAY);

END WHILE;

SELECT 'Tables altered successfully';

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppMarketingPartnerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppMarketingPartnerGetAll`()
BEGIN

SELECT Id, Code, AppSiteId FROM app_marketing_partners;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppMarketingPartnerGetByCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppMarketingPartnerGetByCode`(IN inCode VARCHAR(10))
BEGIN

SELECT Id, Code, AppSiteId FROM app_marketing_partners WHERE Code = inCode;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppMarketingPartnerGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppMarketingPartnerGetById`(IN inId INT)
BEGIN

SELECT Id, Code, AppSiteId FROM app_marketing_partners WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppMarketingPartnerTrackerGetByAppMarketingPartnerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppMarketingPartnerTrackerGetByAppMarketingPartnerId`(IN inAppMarketingPartnerId INT)
BEGIN

SELECT PlatformId, 'ClickTracker' ClickTrackerUrlTemplate, 'EventTracker' EventPostbackUrlTemplate 
FROM app_marketing_partner_trackers WHERE AppMarketingPartnerId = inAppMarketingPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppMarketingPartnerTrackerGetByPartnerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppMarketingPartnerTrackerGetByPartnerId`(IN inAppMarketingPartnerId INT)
BEGIN

SELECT PlatformId, AdGroupId, Type, EventCode, TrackerUrlTemplate 
FROM app_marketing_partner_trackers WHERE AppMarketingPartnerId = inAppMarketingPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteAdQueueGetByAppSiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteAdQueueGetByAppSiteId`(in inAppSiteId int)
BEGIN

SELECT AdId FROM appsite_ad_queue WHERE AppsiteId = inAppSiteId AND Include = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteEventGetByAppSiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteEventGetByAppSiteId`(IN inAppSiteId int)
BEGIN

SELECT a.Id, b.Code EventCode, a.IsBillable, a.MinBid
FROM appsite_events a 
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id
WHERE a.AppSiteId = inAppSiteId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteGetAllWatchTraffic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteGetAllWatchTraffic`()
BEGIN 

Select app.Id AppSiteId
FROM appsite app
INNER JOIN appsite_adserver_settings settings ON app.Id = settings.AppsiteId
Where settings.WatchTraffic = 1 AND app.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteGetById`(IN id Int)
BEGIN 

Select app.Id, app.Name, app.PublisherId, app.ThemeId, app.AccountId, app.TypeId, app.StatusId, app.URL, app.DomainURL, app.BundleId, app.StoreId, app.RegistrationDate, app.IsApp, app.IsContainer, app.IsDeleted,
s.AllowBlindAds, s.GenerateSystemUniqueId, s.ImpressionCountMode, s.SupportedAdTypes, s.SupportedBannerImageTypes, s.WatchTraffic, s.DontStoreUserData, s.AdRequestCachedDataLifeTime,
s.NativeAdLayoutId, s.RewardedVideoItemName, s.RewardedVideoItemValue, s.VastExcludedExtensions
FROM appsite app
LEFT JOIN appsite_adserver_settings s ON app.Id = s.AppsiteId
Where app.Id = id; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteGetByPublisherId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteGetByPublisherId`(IN publisherId varchar(64))
BEGIN

Select app.Id, app.Name, app.PublisherId, app.ThemeId, app.AccountId, app.TypeId, app.StatusId, app.URL, app.DomainURL, app.BundleId, app.StoreId, app.RegistrationDate, app.IsApp, app.IsContainer, app.IsDeleted,
s.AllowBlindAds, s.GenerateSystemUniqueId, s.ImpressionCountMode, s.SupportedAdTypes, s.SupportedBannerImageTypes, s.WatchTraffic, s.DontStoreUserData, s.AdRequestCachedDataLifeTime,
s.NativeAdLayoutId, s.RewardedVideoItemName, s.RewardedVideoItemValue, s.VastExcludedExtensions
FROM appsite app
LEFT JOIN appsite_adserver_settings s ON app.Id = s.AppsiteId
Where app.PublisherId = publisherId; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteKeywordGetByAppSiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteKeywordGetByAppSiteId`(IN inAppsiteId int)
BEGIN

SELECT KeywordId
FROM appsitekeywords
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteRefreshModeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteRefreshModeGetAll`()
BEGIN

Select R.Id, R.Code from appsiterefreshmodes R;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteRevenueCalculationModeGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteRevenueCalculationModeGetByAppsiteId`(in inAppSiteId int)
BEGIN
SELECT CalculationModeType,Value,FromDate,ToDate 
FROM appsite_revenue_calculation_modes
WHERE AppSiteId = inAppSiteId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteSettingGetByAppSiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteSettingGetByAppSiteId`(in appSiteId int)
BEGIN

Select 
AppS.AppSiteId Id,
AppS.TestingModeId,
AppS.RefreshInterval,
AppS.RefreshModeId 
FROM appsitesettings AppS 
WHERE AppS.AppSiteId = appSiteId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteStatusGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteStatusGetAll`()
BEGIN

select S.Id, S.Code from  appsitestatus S;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppsiteThirdPartyInfoGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppsiteThirdPartyInfoGet`(IN inAppsiteId int)
BEGIN

SELECT Id, TrackingId, ThirdPartyId
FROM appsite_thirdparty_info
WHERE AppsiteId = inAppsiteId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppSiteTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppSiteTypeGetAll`()
BEGIN

SELECT Id, Code FROM appsitetypes;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppStatGetByDateTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppStatGetByDateTime`(in closedDateId int, in closedTimeId int,in toDateId int, in toTimeId int)
BEGIN

Select AppAccountID, AppSiteID, Revenue, DimDateID, DimTimeKey,Request, Impression, Clicks,
DimManufacturerID,DimDeviceID,DimPlatformID,DimCountryID,DimOperatorID,DimCityID,DimChannelID 
FROM fact_stat_app 
WHERE 
((closedDateId IS NULL AND closedTimeId IS NULL) OR (DimDateID > closedDateId) OR (DimDateID = closedDateId AND DimTimeKey > closedTimeId))
AND (DimDateID < toDateId OR (DimDateID = toDateId AND DimTimeKey <= toTimeId));


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppStatGetByPaging` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AppStatGetByPaging`(in pageIndex int, in pageSize int,in toDateId int, in toTimeId int)
BEGIN

Select AppAccountID, AppSiteID, Revenue, DimDateID, DimTimeKey,Request, Impression, Clicks, 
DimManufacturerID,DimDeviceID,DimPlatformID,DimCountryID,DimOperatorID,DimCityID,DimChannelID 
from fact_stat_app 
WHERE (DimDateID < toDateId OR (DimDateID = toDateId AND DimTimeKey <= toTimeId)) limit pageIndex,pageSize;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AudienceSegmentGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AudienceSegmentGetAll`()
BEGIN

SELECT Id, ParentId, SegmentCode, Price, ProviderId, Activated, BinIndex, IsDeleted FROM audience_segments; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AudienceSegmentsGetByPixelId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `AudienceSegmentsGetByPixelId`(IN inPixelId INT)
BEGIN

SELECT AudienceSegmentId FROM pixel_audience_segments WHERE PixelId = inPixelId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BidAuthorizeTimeoutGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BidAuthorizeTimeoutGetAll`()
BEGIN

SELECT Id, AdTypeFormatId, IsRTB, BillableEventCode, Timeout FROM bid_authorize_timeouts;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BidExtendTimeoutGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BidExtendTimeoutGetAll`()
BEGIN

SELECT Id, EventCode, BillableEventCode, Timeout FROM bid_extend_timeouts;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BlackBerryVendorGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BlackBerryVendorGetAll`()
BEGIN
Select Id, VendorId, OperatorId from blackberryvendors;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BlockedUrlGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BlockedUrlGetAll`()
BEGIN
Select Url from blocked_urls;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BusinessPartnerGetByCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BusinessPartnerGetByCode`(IN inCode VARCHAR(32))
BEGIN

Select A.Id, A.AccountId, A.Code, P.Name, 
B.Code TypeCode, 
C.AppSiteId DSPAppSiteId,
D.AppSiteId SSPAppSiteId, D.OpenRtbVersion, D.NumberOfSupportedImpressionTrackersInNative, D.NumberOfSupportedClickTrackersInNative, D.NumberOfSupportedVastWrapperLevels, 
D.NumberOfSupportedImpressionTrackersInPartnerMechanism, D.AuctionPricePricingUnitId, D.AuctionPriceEncryptionAlgorithmId, D.AuctionPriceEncryptionKey, D.AuctionPriceIntegrityKey, 
D.AuctionPriceMacroName, D.AuctionPriceTestValue, D.EncodedClickTrackerMacroName, D.DoubleEncodedClickTrackerMacroName, D.SupportWinNotice, D.FingerPrintAllowed, D.TaggingAllowed,
D.DisallowGeofenceLessThanRadius, D.GeofenceRadius, D.DeviceOSIdsIncludeValidUserId, D.ImpressionSource, D.RequestThirdPartyAdSources, D.ThirdPartyAdSourcesMaximumResponseTime, D.SupportUserSync, D.UserSyncPixel, D.ResyncUserPeriod, D.NeedsCreativeApproval
FROM business_partners A
INNER JOIN business_partner_type B ON A.TypeId = B.Id
INNER JOIN party P ON A.Id = P.Id
LEFT JOIN dsp_partners C ON A.Id = C.Id
LEFT JOIN ssp_partners D ON A.Id = D.Id
WHERE A.Code = inCode; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BusinessPartnerGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BusinessPartnerGetById`(IN inId int)
BEGIN

Select A.Id, A.AccountId, A.Code, P.Name,
B.Code TypeCode, 
C.AppSiteId DSPAppSiteId,
D.AppSiteId SSPAppSiteId, D.OpenRtbVersion, D.NumberOfSupportedImpressionTrackersInNative, D.NumberOfSupportedClickTrackersInNative, D.NumberOfSupportedVastWrapperLevels, 
D.NumberOfSupportedImpressionTrackersInPartnerMechanism, D.AuctionPricePricingUnitId, D.AuctionPriceEncryptionAlgorithmId, D.AuctionPriceEncryptionKey, D.AuctionPriceIntegrityKey, 
D.AuctionPriceMacroName, D.AuctionPriceTestValue, D.EncodedClickTrackerMacroName, D.DoubleEncodedClickTrackerMacroName, D.SupportWinNotice, D.FingerPrintAllowed, D.TaggingAllowed,
D.DisallowGeofenceLessThanRadius, D.GeofenceRadius, D.DeviceOSIdsIncludeValidUserId, D.ImpressionSource, D.RequestThirdPartyAdSources, D.ThirdPartyAdSourcesMaximumResponseTime, D.SupportUserSync, D.UserSyncPixel, D.ResyncUserPeriod, D.NeedsCreativeApproval
FROM business_partners A
INNER JOIN business_partner_type B ON A.TypeId = B.Id
INNER JOIN party P ON A.Id = P.Id
LEFT JOIN dsp_partners C ON A.Id = C.Id
LEFT JOIN ssp_partners D ON A.Id = D.Id
WHERE A.Id = inId; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BuyerGetByCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BuyerGetByCode`(IN inCode varchar(6))
BEGIN

Select Id, Code, Name FROM buyers Where Code = inCode;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BuyerGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `BuyerGetById`(IN inId int)
BEGIN

Select Id, Code, Name FROM buyers Where Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CampaignBidConfigGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CampaignBidConfigGet`(in inCampaignId int)
BEGIN

SELECT AccountId,AppsiteId,SubPublisherId,Bid 
FROM campaign_bid_config
WHERE CampaignId = inCampaignId and IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CampaignGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CampaignGetById`(IN id int)
BEGIN

Select C.Id CampaignId, C.Name CampaignName, C.AccountId, C.Discount, C.DiscountType, C.DiscountFromDate, C.DiscountToDate,
C.Budget, C.DailyBudget, C.StartDate, C.EndDate, C.StartTime, C.EndTime, C.TypeId, C.KeywordId, C.UniqueId, C.TrackConversions, C.AdvertiserId, C.CPMValue, C.PriceMode, C.DomainURL, C.AssociationAdvId AccountAdvertiserAssociationId,
S.AdRequestCachedDataLifeTime, S.AgencyCommissionModel, S.AgencyCommissionModelValue, S.CountImpressionFrequencyCappingOnRequest, S.UserLifetimeInDays, S.TrackUnfilled  
FROM campaigns C 
LEFT JOIN campaign_adserver_settings S ON C.Id = S.CampaignId
Where C.Id = id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CampaignGetByUniqueId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CampaignGetByUniqueId`(IN inCampaignUniqueId varchar(50))
BEGIN

Select C.Id CampaignId, C.Name CampaignName, C.AccountId, C.Discount, C.DiscountType, C.DiscountFromDate, C.DiscountToDate,
C.Budget, C.DailyBudget, C.StartDate, C.EndDate, C.StartTime, C.EndTime, C.TypeId, C.KeywordId, C.UniqueId, C.TrackConversions, C.AdvertiserId, C.CPMValue, C.PriceMode, C.DomainURL, C.AssociationAdvId AccountAdvertiserAssociationId,
S.AdRequestCachedDataLifeTime, S.AgencyCommissionModel, S.AgencyCommissionModelValue, S.CountImpressionFrequencyCappingOnRequest, S.UserLifetimeInDays, S.TrackUnfilled  
FROM campaigns C 
LEFT JOIN campaign_adserver_settings S ON C.Id = S.CampaignId
Where C.UniqueId = inCampaignUniqueId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CityNameToCodeMappingGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CityNameToCodeMappingGetAll`()
BEGIN
SELECT Id, CountryCode, RegionCode_ISO, RegionCode_FIPS, CityName, CityCode FROM city_name_to_code_mapping;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ConfigurationsettingsGetByKey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ConfigurationsettingsGetByKey`(in configKey VARCHAR(100), in hostId int(11), in appId int(11), out configValue VARCHAR(2000) )
BEGIN
   
set configValue = (SELECT value FROM
       (
           SELECT value, 1 as OrderNumber FROM configurationsettings
		   WHERE configurationsettings.Key = configKey and configurationsettings.ApplicationId = appId and configurationsettings.HostId = hostId 
           
           UNION

           SELECT value, 2 as OrderNumber FROM configurationsettings
           WHERE configurationsettings.Key = configKey and configurationsettings.ApplicationId = appId and configurationsettings.HostId IS NULL

           UNION

           SELECT value, 3 as OrderNumber FROM configurationsettings
           WHERE configurationsettings.Key = configKey and configurationsettings.ApplicationId IS NULL and configurationsettings.HostId IS NULL
      ) T1 ORDER BY OrderNumber LIMIT 0,1);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContentListAppSitesGetByListId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContentListAppSitesGetByListId`(IN inContentListId INT)
BEGIN

SELECT DISTINCT(Code)
FROM content_list_appsites WHERE LinkId = inContentListId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContentListGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContentListGetById`(IN inId INT)
BEGIN

SELECT Id, Type, Status, IsDeleted FROM content_list WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContextualPartnerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContextualPartnerGetAll`()
BEGIN

Select A.Id FROM contextual_partners A 
INNER JOIN business_partners B ON A.Id = B.Id
INNER JOIN party C ON B.Id = C.Id
WHERE C.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContextualSegmentGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContextualSegmentGetAll`()
BEGIN

SELECT Id, Code FROM contextual_segments WHERE IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContextualSegmentInsertOrUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContextualSegmentInsertOrUpdate`(
    in inProviderId int(11),
	in inAccountId int(11),
	in inAdvertiserAccId int(11),
	in inName varchar(500),
    in inRootProviderSegmentCode varchar(200),
	in inProviderSegmentCode varchar(200),
	in inDescription varchar(500),
    in inType varchar(200),
    in inSubType varchar(200),
    in inTargetingIntent varchar(200))
BEGIN 
  -- DECLARE NameId INT(11);
  -- DECLARE SegmentCode INT(11); 
  -- DECLARE AudienceSegmentId INT(11); 
  
  SET @SegmentCode = (SELECT SegmentCode FROM audience_segments WHERE ProviderId = inProviderId AND OperatorSegmentCode = inProviderSegmentCode);
  
  IF @SegmentCode IS NULL THEN
      CALL CounterGetByName2('Oracle Contextual Segments', @SegmentCode);
           
      INSERT INTO localizedstringids (`GroupKey`) VALUES ('AudienceSegment');
      SET @NameId = LAST_INSERT_ID();
      INSERT INTO localizedstrings (LocalizedStringID, Culture, `Value`) VALUES (@NameId, 'en-US', inName);
      INSERT INTO localizedstrings (LocalizedStringID, Culture, `Value`) VALUES (@NameId, 'ar-JO', inName);
      
      INSERT INTO audience_segments (AccountId, AdvertiserAccId, NameId, ParentId, SegmentCode, OperatorSegmentCode, Description, ProviderId, Selectable, Activated, Price, Type) VALUES (                                               
                  inAccountId, inAdvertiserAccId, @NameId, 
                  (SELECT x.Id FROM (SELECT Id From audience_segments s WHERE s.ProviderId = inProviderId AND s.OperatorSegmentCode = inRootProviderSegmentCode) as x),
				  @SegmentCode, inProviderSegmentCode, inDescription, inProviderId, 1, 1, 0, 2);
                  
	  SET @AudienceSegmentId = LAST_INSERT_ID();
	  INSERT INTO contextual_segments (Id, Type, SubType, TargetingIntent) VALUES (@AudienceSegmentId, inType, inSubType, inTargetingIntent);
            
  ELSE
	  -- UPDATE localizedstrings SET `Value` = inName WHERE LocalizedStringID = (SELECT NameId FROM audience_segments WHERE SegmentCode = @SegmentCode);
      
      UPDATE audience_segments
	  SET AccountId = inAccountId,
		  AdvertiserAccId = inAdvertiserAccId,
          -- ParentId = (SELECT Id From audience_segments WHERE ProviderId = inProviderId AND OperatorSegmentCode = inRootProviderSegmentCode),
		  Description = inDescription           
      WHERE SegmentCode = @SegmentCode;
      
      UPDATE contextual_segments 
      SET Type = inType,
      SubType = inSubType,
      TargetingIntent = inTargetingIntent
      WHERE Id = (SELECT Id FROM audience_segments WHERE SegmentCode = @SegmentCode);
           
  END IF;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ContextualSegmentsDeleteNotExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ContextualSegmentsDeleteNotExist`(in inProviderId int(11), in inExistProviderSegmentCodes text)
BEGIN

SET @STMT_TEXT := CONCAT("UPDATE audience_segments a INNER JOIN contextual_segments b ON b.Id = a.Id SET a.IsDeleted = 1 WHERE a.ProviderId = ", inProviderId, " AND a.OperatorSegmentCode NOT IN (", inExistProviderSegmentCodes , ") AND b.Type != 'system';");

PREPARE stmt FROM @STMT_TEXT;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CostItemsGetByAdGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CostItemsGetByAdGroupId`(in inAdGroupId INT)
BEGIN

Select ACI.CostItemId, ACI.Value, ACI.FromDate, ACI.ToDate, ACI.Scope, ACI.DataProviderId, ACI.BeneficiaryPartyId, 
CI.Type, CI.CalculationType, CI.Category,
CE.CalculatedFrom CostElementCalculatedFrom, CE.CalculatedFromFeeCategory,    
F.CalculatedFrom FeeCalculatedFrom, F.IsBillable 
FROM adgroup_cost_items ACI 
INNER JOIN cost_items CI ON ACI.CostItemId = CI.Id
LEFT JOIN cost_elements CE ON CI.Id = CE.Id
LEFT JOIN fees F ON CI.Id = F.Id
WHERE ACI.AdGroupId = inAdGroupId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CounterGetByName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CounterGetByName`(in CounterName varchar(250))
BEGIN
SELECT  Counter  FROM counters
where name =CounterName
for update;

update counters
set Counter=Counter+1
where name =CounterName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CounterGetByName2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CounterGetByName2`(in CounterName varchar(250), out Id int(11))
BEGIN
SELECT  Counter INTO Id FROM counters
where name =CounterName
for update;

update counters
set Counter=Counter+1
where name =CounterName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CounterGetByYear` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CounterGetByYear`(in YearId smallint, in CounterName varchar(250))
BEGIN
SELECT  Counter  FROM counters
where year=YearId and name =CounterName
for update;

update counters
set Counter=Counter+1
where year=YearId and name =CounterName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeAttributeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeAttributeGetAll`()
BEGIN

SELECT Id, Code FROM creative_attributes;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeAttributesGetByAdCreativeId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeAttributesGetByAdCreativeId`(IN inAdCreativeUnitId INT)
BEGIN

Select att.CreativeAttributeId From ad_creative_unit_attributes att Where att.AdCreativeUnitId = inAdCreativeUnitId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeFormatGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeFormatGetAll`()
BEGIN

SELECT Id, Code FROM creative_formats;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeProtocolGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeProtocolGetAll`()
BEGIN

SELECT Id, Code FROM creative_protocols;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeUnitGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeUnitGetAll`()
BEGIN



SELECT a.Id, a.Width, a.Height, a.Code 
FROM creativeunits a
inner join creativeunit_groups_mapping b on a.Id = b.CreativeUnitId
inner join creativeunit_groups c on b.GroupId = c.Id
where c.Code = 11; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeUnitGroupGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeUnitGroupGetAll`()
BEGIN

SELECT Id, Code FROM creativeunit_groups;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeUnitGroupMappingGetByGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeUnitGroupMappingGetByGroupId`(IN inGroupId INT)
BEGIN

SELECT CreativeUnitId, Priority FROM creativeunit_groups_mapping WHERE GroupId = inGroupId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeVendorGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeVendorGetAll`()
BEGIN

SELECT Id, Code, Description FROM creative_vendors;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreativeVendorsGetByAdCreativeId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `CreativeVendorsGetByAdCreativeId`(IN inAdCreativeUnitId INT)
BEGIN

Select CreativeVendorId From ad_creative_unit_vendors Where AdCreativeUnitId = inAdCreativeUnitId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DataProviderRevenueCalculationModeGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DataProviderRevenueCalculationModeGet`(IN inDataProviderId INT)
BEGIN

SELECT CalculationModeType, Value, FromDate, ToDate 
FROM dp_revenue_calculation_modes
WHERE DataProviderId = inDataProviderId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DealGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DealGetAll`()
BEGIN

Select Id, UniqueId, Code, Name, AccountId, ExchangeId, StartDate, EndDate, Price, IsDeleted FROM buyer_deals;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_keyword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `delete_keyword`(keyword_id int)
BEGIN

delete from appsitekeywords
where KeywordId=keyword_id  and id>0;

delete from  keywordtargetings
where KeywordId=keyword_id  and id>0;

delete from  keywordsfilters
where KeywordId=keyword_id  and id>0;

update campaigns set KeywordId=null where KeywordId=keyword_id and id>0;

update ads set KeywordId=null where KeywordId=keyword_id and id>0;

delete from localizedstrings  
where localizedstringid in (select nameid from keywords where id=keyword_id) and id>0;

delete from localizedstringids  
where localizedstringid in (select nameid from keywords where id=keyword_id) and localizedstringid>0;

DELETE from  keywords where id=keyword_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceAtlasDeviceGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceAtlasDeviceGetAll`()
BEGIN

SELECT Id, Device, MatchWurflValue FROM device_atlas_devices;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceAtlasManufacturerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceAtlasManufacturerGetAll`()
BEGIN

SELECT Id, Manufacturer, MatchWurflValue FROM device_atlas_manufacturers;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceAtlasPlatformGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceAtlasPlatformGetAll`()
BEGIN

SELECT Id, Platform, MatchWurflValue FROM device_atlas_platforms;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceCapabilityGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceCapabilityGetAll`()
BEGIN

Select Id, WurflCapabilities, WurflValue from device_capabilities where IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceCodesGetByDeviceId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceCodesGetByDeviceId`(IN inDeviceId INT)
BEGIN

Select Code From device_codes WHERE DeviceId = inDeviceId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceGetAll`()
BEGIN

Select Id, ManufacturerId, PlatformId From devices Where IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceOrientationGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceOrientationGetAll`()
BEGIN

SELECT Id, Code FROM device_orientations;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceTargetingsUpdateGroupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceTargetingsUpdateGroupId`()
BEGIN

UPDATE devicetargetingplatforms DTP
INNER JOIN devicetargetings DT ON DT.Id = DTP.DeviceTargetingId
INNER JOIN targetings T ON T.Id = DT.Id
SET DTP.GroupId = T.AdGroupId;

UPDATE devicetargetingmanufacturers DTM
INNER JOIN devicetargetings DT ON DT.Id = DTM.DeviceTargetingId
INNER JOIN targetings T ON T.Id = DT.Id
SET DTM.GroupId = T.AdGroupId;

UPDATE devicetargetingdevices DTD
INNER JOIN devicetargetings DT ON DT.Id = DTD.DeviceTargetingId
INNER JOIN targetings T ON T.Id = DT.Id
INNER JOIN devices D ON DTD.DeviceId = D.Id
SET DTD.GroupId = T.AdGroupId, DTD.ManufacturerId = D.ManufacturerId, DTD.PlatformId = D.PlatformId;

UPDATE device_targeting_device_capabilities DTDC
INNER JOIN devicetargetings DT ON DT.Id = DTDC.DeviceTargetingId
INNER JOIN targetings T ON T.Id = DT.Id
SET DTDC.GroupId = T.AdGroupId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeviceTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DeviceTypeGetAll`()
BEGIN
Select D.Id, D.Code from devicetypes D;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DimDateGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DimDateGetAll`()
BEGIN

Select * from dimdate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DimHoursTimeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DimHoursTimeGetAll`()
BEGIN

Select * from dimhourstime;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DimTimeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DimTimeGetAll`()
BEGIN

Select * from dimtime;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DSPPartnerCampaignIdsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DSPPartnerCampaignIdsGet`(IN inDSPPartnerId INT)
BEGIN

SELECT C.Id FROM campaigns C
INNER JOIN account AC ON C.AccountId = AC.Id 
INNER JOIN business_partners BP ON AC.Id = BP.AccountId 
WHERE BP.Id = inDSPPartnerId AND C.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DSPPartnerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DSPPartnerGetAll`()
BEGIN

Select A.Id FROM dsp_partners A 
INNER JOIN business_partners B ON A.Id = B.Id
INNER JOIN party C ON B.Id = C.Id
WHERE C.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DynamicBiddingAdGroupConfig_ListAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `DynamicBiddingAdGroupConfig_ListAll`()
BEGIN

	SELECT 
		agdb.`AdGroupId`,
		agdb.`BidOptimizationType`,
		agdb.`BidOptimizationValue`,
		agdb.`DefaultBidPrice`,
		agdb.`MaxBidPrice`,
		agdb.`MinBidPrice`,
		agdb.`BidStep`
	FROM
		`adgroup_dynamic_bidding_config` agdb;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `etisalat_block_news` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `etisalat_block_news`()
BEGIN
   
                INSERT INTO etisalat_news_apps(code_key, code, appid, domain, appsitename, type, State)
                SELECT unhex(md5(Code)), Code, AppId, Domain, AppSiteName, Type, 2  FROM adfalcon.content_list_appsites where linkid in (3838, 2424)
                ON DUPLICATE KEY UPDATE type=etisalat_news_apps.type;

                
                INSERT INTO etisalat_news_apps(code_key, code, appid, domain, appsitename, type, keywords, name, url, State)
                SELECT unhex(md5(code)), code, appid, domain, appsitename, type, keywords, name, url, 0  FROM
                _staging_news_apps
                ON DUPLICATE KEY UPDATE type=etisalat_news_apps.type,
                                        etisalat_news_apps.keywords = keywords,
                                        etisalat_news_apps.name = name,
                                        etisalat_news_apps.url = url;

                
                INSERT INTO `adfalcon`.`content_list_appsites` (`Code`, `AppID`, `Domain`, `Type`, `AppSiteName`, `LinkId`, IsDeleted)
                SELECT code, appid, domain, type, appsitename, 3838, 0
                FROM etisalat_news_apps
                WHERE State = 0;

                
                UPDATE etisalat_news_apps
                SET AddedToContentListOn= CURRENT_TIMESTAMP , State = 1
                WHERE State = 0;

				
				select ROW_COUNT();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `EventFrequencyCappingSettingGetByCampaignId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `EventFrequencyCappingSettingGetByCampaignId`(IN inCampaignId INT)
BEGIN

SELECT b.Code EventCode, a.FrequencyCappingType, a.FrequencyCappingNumber, a.FrequencyCappingInterval
FROM campaign_frequency_capping_settings a 
INNER JOIN ad_events_definition b ON a.AdEventDefinitionId = b.Id
WHERE a.CampaignId = inCampaignId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `executeScript` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `executeScript`(in script TEXT )
BEGIN





	DECLARE vString Text;

  DECLARE vSeparator VARCHAR(5);

	DECLARE vDone tinyint(1) DEFAULT 1;

	DECLARE vIndex INT DEFAULT 1;

	DECLARE vSubString Text;

	SET vString = script;

	SET vSeparator = ';';

	WHILE vDone > 0 DO

		SET vSubString = SUBSTRING(vString, vIndex,

											IF(LOCATE(vSeparator, vString, vIndex) > 0,

												LOCATE(vSeparator, vString, vIndex) - vIndex,

												LENGTH(vString)

											));

		IF LENGTH(vSubString) > 0 THEN

				SET vIndex = vIndex + LENGTH(vSubString) + 1;

        SET @SQL_interval13 = CONCAT(vSubString,';');

        

				PREPARE n_StrSQL FROM @SQL_interval13;

        EXECUTE n_StrSQL;

        DEALLOCATE PREPARE n_StrSQL;

		ELSE

				SET vDone = 0;

		END IF;

	END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GenderGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GenderGetAll`()
BEGIN

Select G.Id, G.Code from genders G;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetEmailSenderEventsEmails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GetEmailSenderEventsEmails`()
BEGIN

SELECT eventname as EventName,emails as Emails,sendtodefault as SendToDefault
FROM emailsender_events_emails;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetEvents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GetEvents`()
BEGIN
SELECT Id,EventName,isActive,UpdateStats
FROM events
where isActive=true;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetEventStats` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GetEventStats`(in inEventId int, in inInstanceId varchar(50))
BEGIN

SELECT Id,EventId,InstanceId,NumberOfRaises,LastRaiseDate 
FROM events_stat 
WHERE EventId = inEventId AND InstanceId = inInstanceId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSubscribers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GetSubscribers`(in Application_Id int)
BEGIN
set @ApplicationStr=concat('%,',Application_Id,',%');
SELECT `Id`,`Name` as EventName,`TypeResolver`,`isActive` FROM subscribers
where isActive=true and (Application_Id is null or ApplicationId like  @ApplicationStr);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSubscriptions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `GetSubscriptions`(in Application_Id int)
BEGIN
set @ApplicationStr=concat('%,',Application_Id,',%');
SELECT s.Id,s.EventId,s.SubscriberId,s.MethodName,s.isActive,s.IsAsync,s.IsTransactional
FROM subscriptions as s
INNER JOIN subscribers ON s.SubscriberId = subscribers.Id
WHERE s.isActive = true AND subscribers.isActive=true  AND (Application_Id is null or subscribers.ApplicationId like  @ApplicationStr);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `HasOfferTracking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `HasOfferTracking`()
BEGIN

declare pageIndex int;
declare count int;

delete from _requestids_log;

set count = 
(
select count(*) from ad_tracking 
where requestid not like '%-%' 
and requestid not like '%APPIA%' 
and requestdate >= '2013-06-27 00:00:00'

);
set pageIndex = 0;

WHILE pageIndex <= count DO

delete from _requestids_tracking;

insert into _requestids_tracking
select requestid from ad_tracking 
where requestid not like '%-%' 
and requestid not like '%APPIA%' 
and requestdate >= '2013-06-27 00:00:00'

limit pageIndex,10;

set pageIndex = pageIndex + 10;

insert into _requestids_log
select requestid,adid
from trans_ad_log_2013_06_27
where transtype = 0 and requestid in (SELECT requestid FROM _requestids_tracking);

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `HttpRefererGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `HttpRefererGetAll`()
BEGIN

SELECT Id,Domain,SampleUrl,SampleAppsiteId FROM http_referers;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `HttpRefererInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `HttpRefererInsert`(in inDomain nvarchar(250), in inSampleUrl nvarchar(5000), in inSampleAppsiteId int, out outId int)
BEGIN

INSERT INTO http_referers (Domain,SampleUrl,SampleAppsiteId) 
VALUES (inDomain,inSampleUrl,inSampleAppsiteId)
ON DUPLICATE KEY UPDATE Id = LAST_INSERT_ID(Id), Domain = inDomain, SampleUrl = inSampleUrl, SampleAppsiteId = inSampleAppsiteId;

Set outId = LAST_INSERT_ID();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IABContentCategoryGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `IABContentCategoryGetAll`()
BEGIN

Select Id, IABCategory, IsBlocked
FROM iab_content_categories;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IABContentCategoryMappingGetByKeywordId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `IABContentCategoryMappingGetByKeywordId`(IN inKeywordId INT)
BEGIN

Select IABContentCategoryId
FROM keywords_to_iab_content_categories_mapping
WHERE KeywordId =  inKeywordId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ImportAdCreativeUnitTrackers_deleted` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ImportAdCreativeUnitTrackers_deleted`()
BEGIN

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ImportAdGroupEvents_deleted` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ImportAdGroupEvents_deleted`()
BEGIN

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ImportCPIGroupEvents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ImportCPIGroupEvents`(IN inAdGroupId INT)
BEGIN

update adgroup_events set IsBillable = 0 where AdGroupId = inAdGroupId and Code = '000imp';
SET @ImpressionEventId = (Select Id from adgroup_events where Code = '000imp' and AdGroupId = inAdGroupId);

update adgroup_events set IsBillable = 0 where AdGroupId = inAdGroupId and Code = '000clk';
SET @ClickEventId = (Select Id from adgroup_events where Code = '000clk' and AdGroupId = inAdGroupId);

SET @InstallEventId = (Select Id from adgroup_events where Code = 'instll' and AdGroupId = inAdGroupId);
IF @InstallEventId IS NULL THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`,`PrerequisiteIds`,`AllPrerequisitesRequired`,`AllowDuplicate`) values (inAdGroupId,'instll','install','e3',1,concat(@ImpressionEventId, ',', @ClickEventId),1,0);
ELSE
update adgroup_events set PrerequisiteIds = concat(@ImpressionEventId, ',', @ClickEventId), IsBillable = 1, AllPrerequisitesRequired = 1, AllowDuplicate = 0, StatColumnName = 'e3' where AdGroupId = inAdGroupId and Code = 'instll';
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ImportVideoAdGroupEvents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ImportVideoAdGroupEvents`(IN inAdGroupId INT)
BEGIN


update adgroup_events set IsBillable = 0 where AdGroupId = inAdGroupId and Code = '000imp';
SET @ImpressionEventId = (Select Id from adgroup_events where Code = '000imp' and AdGroupId = inAdGroupId);

SET @CreativeViewEventId = (Select Id from adgroup_events where Code = 'creatv' and AdGroupId = inAdGroupId);
IF @CreativeViewEventId IS NULL THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'creatv','creativeview','e3',1);
SET @CreativeViewEventId = (Select Id from adgroup_events where Code = 'creatv' and AdGroupId = inAdGroupId);
END IF;

SET @StartEventId = (Select Id from adgroup_events where Code = '0start' and AdGroupId = inAdGroupId);
IF @StartEventId IS NULL THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'0start','start','e4',0);
SET @StartEventId = (Select Id from adgroup_events where Code = '0start' and AdGroupId = inAdGroupId);
END IF;

SET @HasFirstQuartile = EXISTS (SELECT 1 from adgroup_events where Code = 'firstq' and AdGroupId = inAdGroupId);
IF NOT @HasFirstQuartile THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'firstq','firstquartile','e5',0);
END IF;

SET @HasMidPoint = EXISTS (SELECT 1 from adgroup_events where Code = 'midpnt' and AdGroupId = inAdGroupId);
IF NOT @HasMidPoint THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'midpnt','midpoint','e6',0);
END IF;

SET @HasThirdQuartile = EXISTS (SELECT 1 from adgroup_events where Code = 'thirdq' and AdGroupId = inAdGroupId);
IF NOT @HasThirdQuartile THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'thirdq','thirdquartile','e7',0);
END IF;

SET @HasComplete = EXISTS (SELECT 1 from adgroup_events where Code = 'complt' and AdGroupId = inAdGroupId);
IF NOT @HasComplete THEN
insert into adgroup_events (`AdGroupId`,`Code`,`Name`,`StatColumnName`,`IsBillable`) values (inAdGroupId,'complt','complete','e8',0);
END IF;


update adgroup_events set PrerequisiteIds = concat(@ImpressionEventId, ',', @CreativeViewEventId, ',' , @StartEventId), IsBillable = 0, AllPrerequisitesRequired = 0 where AdGroupId = inAdGroupId and Code = '000clk';

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ImpressionMetricGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ImpressionMetricGetAll`()
BEGIN

SELECT Id, Code FROM impression_metrics;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inserLookupRowsCreativeVendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `inserLookupRowsCreativeVendor`()
BEGIN

DECLARE cursor_ID INT;
  DECLARE cursor_VAL VARCHAR(500);
  DECLARE done INT DEFAULT FALSE;
  DECLARE cursor_i CURSOR FOR select description from creative_vendors;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cursor_i;
  read_loop: LOOP
    FETCH cursor_i INTO cursor_VAL;
    IF done THEN
      LEAVE read_loop;
    END IF;
    
    
    INSERT INTO `localizedstringids` (`GroupKey`) VALUES ('CreativeVendor');
set @lookupid= (select max(localizedstringid) from `localizedstringids` where `GroupKey`='CreativeVendor' );
INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) VALUES (@lookupid, 'en-US', cursor_VAL);
INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) VALUES (@lookupid, 'ar-JO', cursor_VAL);
UPDATE creative_vendors  set NameId=@lookupid where description=cursor_VAL;


  END LOOP;
  CLOSE cursor_i;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertCSVIntoActionTable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `InsertCSVIntoActionTable`(csv varchar(200))
BEGIN

DECLARE cur_position INT DEFAULT 1 ;
DECLARE remainder TEXT;
DECLARE cur_string VARCHAR(10);
DECLARE delimiter_length TINYINT UNSIGNED;
    
SET delimiter_length = CHAR_LENGTH(",");

   
IF TRIM(csv) != '' THEN
    SET remainder = csv;
    SET cur_position = 1;
    WHILE CHAR_LENGTH(remainder) > 0 AND cur_position > 0 DO
        SET cur_position = INSTR(remainder, ",");
        IF cur_position = 0 THEN
            SET cur_string = remainder;
        ELSE
            SET cur_string = LEFT(remainder, cur_position - 1);
        END IF;
        IF TRIM(cur_string) != '' THEN
            INSERT INTO tblActionTypes VALUES (cur_string);
        END IF;
        SET remainder = SUBSTRING(remainder, cur_position + delimiter_length);
    END WHILE;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertCSVIntoKeywordsTable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `InsertCSVIntoKeywordsTable`(csv varchar(200))
BEGIN

DECLARE cur_position INT DEFAULT 1 ;
DECLARE remainder TEXT;
DECLARE cur_string VARCHAR(10);
DECLARE delimiter_length TINYINT UNSIGNED;
    
SET delimiter_length = CHAR_LENGTH(",");

   
IF TRIM(csv) != '' THEN
    SET remainder = csv;
    SET cur_position = 1;
    WHILE CHAR_LENGTH(remainder) > 0 AND cur_position > 0 DO
        SET cur_position = INSTR(remainder, ",");
        IF cur_position = 0 THEN
            SET cur_string = remainder;
        ELSE
            SET cur_string = LEFT(remainder, cur_position - 1);
        END IF;
        IF TRIM(cur_string) != '' THEN
            INSERT INTO tblKeywords VALUES (cur_string);
        END IF;
        SET remainder = SUBSTRING(remainder, cur_position + delimiter_length);
    END WHILE;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertDevice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `InsertDevice`(in ManufacturerId int,in PlatformId int,in DeviceTypeId int ,in deviceName varchar(255) ,in deviceCode varchar(255) )
BEGIN
DECLARE localizedStringId int ;
set localizedStringId=0;
INSERT INTO `localizedstringids` (`GroupKey`) VALUES ('Device');
set localizedStringId= LAST_INSERT_ID();
INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) 
VALUES (localizedStringId, 'en-US', deviceName);
INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) 
VALUES (localizedStringId, 'ar-JO', deviceName);
INSERT INTO `devices` (`NameId`, `ManufacturerId`, `PlatformId`, `DeviceTypeId`, `Code`) 
VALUES (localizedStringId, ManufacturerId, PlatformId, DeviceTypeId, deviceCode);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertOrUpdateAudienceSegments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `InsertOrUpdateAudienceSegments`(
	in `AccountId` int(11),
	in `AdvertiserAccId` int(11),
	in `NameId` int(11),
    in `RootSegmentCode` int(11),
	in `OperatorSegmentCode` varchar(200),
	in `Description` varchar(500),
	in `CostModelId` int(11),
    in `BillCat` tinyint(4),
	in `Price` decimal(21,12), 
	in `ProviderId` int(11),
	in `Selectable` bit(1),
	in `IsDeleted` bit(1),
	in `IsPermissionNeed` bit(1),
	in `Activated` bit(1))
BEGIN 
  DECLARE LookupId INT(11);
  DECLARE SegCode INT(11); 
  
  SET @SegCode = NULL; 

 
  SELECT s.SegmentCode INTO @SegCode FROM adfalcon.audience_segments s WHERE s.ProviderId = ProviderId AND s.OperatorSegmentCode = OperatorSegmentCode;
  
  IF @SegCode IS NULL THEN
      
      CALL adfalcon.CounterGetByName2('Custom Audience Segments',  @SegCode);
           
      INSERT INTO adfalcon.localizedstringids(`GroupKey`) VALUES ('AudienceSegment');
      
      SET @LookupId = LAST_INSERT_ID();
      
      INSERT INTO adfalcon.localizedstrings (ID, LocalizedStringID, Culture, `Value`) VALUES (NULL, @LookupId, 'en-US', OperatorSegmentCode);
	  
      INSERT INTO adfalcon.localizedstrings (ID, LocalizedStringID, Culture, `Value`) VALUES (NULL,@LookupId, 'ar-JO', OperatorSegmentCode);
      
      INSERT INTO adfalcon.audience_segments(AccountId, 
											 AdvertiserAccId, 
                                             NameId, 
                                             ParentId, 
                                             SegmentCode, 
                                             OperatorSegmentCode, 
                                             Description, 
											 CostModelId,
                                             BillCat,
                                             Price, 
                                             ProviderId, 
                                             Selectable, 
                                             IsDeleted, 
                                             IsPermissionNeed, 
                                             Activated) 
                                             
                                             VALUES (                                             
                                             
                                             AccountId, 
                                             AdvertiserAccId, 
                                             @LookupId, 
                                             (SELECT x.Id FROM (SELECT Id From adfalcon.audience_segments s WHERE s.SegmentCode = RootSegmentCode AND s.ProviderId = ProviderId) as x),
                                             @SegCode,
                                             OperatorSegmentCode,
                                             Description,
                                             CostModelId,
                                             BillCat,
                                             Price,
                                             ProviderId,
                                             Selectable,
                                             IsDeleted,
                                             IsPermissionNeed,
                                             Activated);
  ELSE
      UPDATE adfalcon.audience_segments s
	  SET   s.AccountId = AccountId,
			s.AdvertiserAccId = AdvertiserAccId,
            s.Description = Description,
            s.CostModelId = CostModelId,
            s.BillCat = BillCat,
            s.Price = Price           
      WHERE s.ProviderId = ProviderId AND s.SegmentCode = @SegCode;
           
  END IF;
  
  SELECT @SegCode;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertPlatform` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `InsertPlatform`(in platformName varchar(255))
BEGIN

DECLARE localizedStringId int ;
set localizedStringId=0;

INSERT INTO `localizedstringids` (`GroupKey`) VALUES ('PlatForm');
set localizedStringId= LAST_INSERT_ID();

INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) 
VALUES (localizedStringId, 'en-US', platformName);

INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) 
VALUES (localizedStringId, 'ar-JO', platformName);

INSERT INTO `platforms` (`PlatformNameId`) VALUES (localizedStringId);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_ip_targetings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `insert_ip_targetings`(id int ,adgroupId int,IPRangeStart long,IPRangeEnd long,description varchar(100))
BEGIN

INSERT INTO `targetings`(`Id`,`IsDeleted`,`TypeId`,`AdGroupId`)
VALUES (id,0,6,adgroupId);


INSERT INTO `ip_targetings`
(`Id`,`IPRangeStart`,`IPRangeEnd`,`description`)
VALUES
(id,IPRangeStart,IPRangeEnd,description);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `KeywordFilterGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `KeywordFilterGetByAppsiteId`(IN inAppsiteId int)
BEGIN

SELECT KeywordId
FROM keywordsfilters
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `KeywordGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `KeywordGetAll`()
BEGIN

Select K.Id, LS.Value Name, K.Code from keywords K 
Inner Join localizedstrings LS On K.NameId = LS.LocalizedStringID
WHERE LS.Culture = 'en-US';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `KeywordMappingGetByIABContentCategoryId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `KeywordMappingGetByIABContentCategoryId`(IN inContentCategoryId INT)
BEGIN

Select KeywordId
FROM iab_content_categories_to_keywords_mapping
WHERE IABContentCategoryId =  inContentCategoryId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LanguageFilterGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `LanguageFilterGetByAppsiteId`(IN inAppsiteId int)
BEGIN

SELECT LanguageId
FROM languagefilters
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LanguageGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `LanguageGetAll`()
BEGIN

Select L.Id,  L.Code, L.Id_Hex from languages L;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LocationGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `LocationGetAll`()
BEGIN

Select Id, LocationType, Code1, Code2, Code3, ParentId from locations;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LogFilterGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `LogFilterGetAll`()
BEGIN

Select Id, FilterTypeId, FilterValues from log_filters;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ManufacturerCodeGetByManufacturerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ManufacturerCodeGetByManufacturerId`(IN inManufacturerId INT)
BEGIN

Select Code From manufacturercodes WHERE ManufacturerId = inManufacturerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ManufacturerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ManufacturerGetAll`()
BEGIN

Select ManufacturerId From manufacturers;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MetricVendorCreativePluginsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MetricVendorCreativePluginsGet`(IN inMetricVendorId INT)
BEGIN

SELECT CreativeFormatId, ApiFramework, SdkPlugin, NonSdkPlugin, Priority FROM metric_vendor_creative_plugins WHERE VendorId = inMetricVendorId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MetricVendorGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MetricVendorGetAll`()
BEGIN

SELECT m.Id, m.Type, m.Code, v.DefaultApiFramework
FROM metric_vendors m
LEFT JOIN viewability_vendors v on v.Id = m.Id
WHERE m.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MetricVendorWhitelistAccountsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MetricVendorWhitelistAccountsGet`(IN inMetricVendorId INT)
BEGIN

SELECT AccountId FROM metric_vendor_whitelist_accounts WHERE VendorId = inMetricVendorId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `migrateDateAccountAdvertiser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `migrateDateAccountAdvertiser`(in inAccountId int, in inAdvertiserId int )
BEGIN

  DECLARE done INT DEFAULT FALSE;

  DECLARE ValueAdvertiser INT(11);

 

   

 

 

set ValueAdvertiser =(SELECT id from advertiser_account where  AdvertiserID=inAdvertiserId and AccountId=inAccountId) ;

 

 

 

 

IF  ValueAdvertiser IS NULL THEN

 

 

INSERT INTO `advertiser_account` (`AccountId`, `AdvertiserId`,`IsDeleted`) VALUES (inAccountId,inAdvertiserId ,b'0' );

 

 

 

    END IF;

   

 

 

 

 

 

   

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `migrateDateAvertiser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `migrateDateAvertiser`()
BEGIN
  DECLARE done INT DEFAULT FALSE;

  DECLARE URLV VARCHAR(1024);
    DECLARE URLV2 VARCHAR(1024);
	  DECLARE URLNEWV VARCHAR(1024);
  DECLARE ArabicDescriptionV VARCHAR(500);
  DECLARE EnglishDescriptionV VARCHAR(500);
    
  DECLARE CampaignIDV  int(11);
  DECLARE cur1 CURSOR FOR SELECT TRIM(URL),TRIM(NewURL),TRIM(ArabicDescription),TRIM(EnglishDescription) FROM  MigationDomainURLAdvertiser;
DECLARE cur2 CURSOR FOR SELECT CampaignID,TRIM(DomainURL) FROM MigationCampaignAdvertiser;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cur1;
 
set sql_safe_updates=0;
  read_loop: LOOP
    FETCH cur1 INTO URLV, URLNEWV, ArabicDescriptionV,EnglishDescriptionV;
    
    IF done THEN
      LEAVE read_loop;
    END IF;

 IF  URLNEWV != '' AND URLNEWV IS NOT NULL THEN 
  INSERT INTO `localizedstringids` (`GroupKey`) VALUES ('Advertiser');

set @lookupid= (select max(localizedstringid) from `localizedstringids` where `GroupKey`='Advertiser' );

INSERT INTO `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) VALUES (@lookupid, 'ar-JO',ArabicDescriptionV );
INSERT INTO  `localizedstrings` (`LocalizedStringID`, `Culture`, `Value`) VALUES (@lookupid, 'en-US', EnglishDescriptionV);

 INSERT INTO `advertisers` (`NameId`, `DomainURL`) VALUES (@lookupid,  URLNEWV);
 set @advertiserId= (select max(Id) from `advertisers`);

 UPDATE MigationDomainURLAdvertiser
 SET AdvertiserID=@advertiserId where URL=URLV;

    END IF;
    
 
  END LOOP;

  CLOSE cur1;
  
   commit;

    
	
	   OPEN cur2;
        SET done = FALSE;
	  read_loop2: LOOP
    FETCH cur2 INTO CampaignIDV, URLV2;
    
    IF done THEN
      LEAVE read_loop2;
    END IF;
 set @advertiserId= (select AdvertiserID from `MigationDomainURLAdvertiser` where URL = URLV2);
 IF  @advertiserId> 0 THEN 
 UPDATE campaigns SET AdvertiserId=@advertiserId WHERE Id=CampaignIDV;
      END IF;
  END LOOP;
	
  CLOSE cur2;
   commit;
  set sql_safe_updates=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `migrateDateAvertiserClean` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `migrateDateAvertiserClean`()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE ValueAdvertiser INT(11);
   DECLARE ValueNameID INT(11);
  DECLARE URLV VARCHAR(1024);
    DECLARE URLV2 VARCHAR(1024);
	  DECLARE URLNEWV VARCHAR(1024);
  DECLARE ArabicDescriptionV VARCHAR(500);
  DECLARE EnglishDescriptionV VARCHAR(500);
    
DECLARE CampaignIDV  int(11);
DECLARE cur1 CURSOR FOR SELECT AdvertiserId,Trim(NewURL) FROM MigationDomainURLAdvertiser mig where AdvertiserId>0  group by Trim(mig.NewURL) having Count(*)>1;
DECLARE cur2 CURSOR FOR SELECT c.Id, Trim(adv.DomainURL) FROM campaigns c inner join advertisers adv on c.AdvertiserId=adv.Id where c.AdvertiserId>0 
and adv.Id>0 and  adv.DomainURL in (SELECT Trim(NewURL) FROM MigationDomainURLAdvertiser mig where AdvertiserId>0  group by Trim(mig.NewURL) having Count(*)>1);
DECLARE cur3 CURSOR FOR SELECT NameID, ID from advertisers where  ID not in (Select AdvertiserID from campaigns where AdvertiserID>0 );



  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cur1;
 
set sql_safe_updates=0;
  read_loop: LOOP
    FETCH cur1 INTO ValueAdvertiser,URLNEWV;
    
    IF done THEN
      LEAVE read_loop;
    END IF;

 IF  URLNEWV != '' AND URLNEWV IS NOT NULL THEN 


 INSERT INTO `MigationDomainURLAdvertiserClean` (`NewURL`, `AdvertiserID`) VALUES (URLNEWV,ValueAdvertiser  );



    END IF;
    
 
  END LOOP;

  CLOSE cur1;
  
   commit;

    
	
	   OPEN cur2;
        SET done = FALSE;
	  read_loop2: LOOP
    FETCH cur2 INTO CampaignIDV, URLV2;
    
    IF done THEN
      LEAVE read_loop2;
    END IF;
 set @advertiserId= (select AdvertiserID from `MigationDomainURLAdvertiserClean` where NewURL = URLV2);
 IF  @advertiserId> 0 THEN 
 UPDATE campaigns SET AdvertiserId=@advertiserId WHERE Id=CampaignIDV;
      END IF;
  END LOOP;
	
  CLOSE cur2;
   commit;
   
   	   OPEN cur3;
        SET done = FALSE;
	  read_loop3: LOOP
    FETCH cur3 INTO ValueNameID,ValueAdvertiser;
    
    IF done THEN
      LEAVE read_loop3;
    END IF;

	DELETE From advertisers where ID=ValueAdvertiser;
    
	DELETE FROM localizedstrings where localizedStringID=ValueNameID;
DELETE FROM localizedstringids where localizedStringID=ValueNameID and groupkey='Advertiser';


	
      
  END LOOP;
	
  CLOSE cur3;
   
      commit;
  set sql_safe_updates=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MIMETypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MIMETypeGetAll`()
BEGIN

Select Id, MIME, AdTypeId
FROM mime_types;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MobileUserExists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MobileUserExists`(in inUserId varchar(100) , in inType int, out isExists bool)
BEGIN

set isExists =  exists(select 1 from mobileusers MU where MU.UserId = inUserId and MU.Type = inType);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MobileUserInsertOrUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `MobileUserInsertOrUpdate`(in inUserId nvarchar(100), in inType int,in inAppsiteId int, in inExpiryDate datetime,
in inLastAccess datetime, in inCountryId int, in inOperatorId int, in inDeviceId int, in inManufacturerId int, in inPlatformId int)
BEGIN

Declare _userId int;

INSERT INTO mobileusers (UserId, Type, ExpiryDate, LastAccess,AccessCount) VALUES (inUserId, inType, inExpiryDate, inLastAccess, 1)
ON DUPLICATE KEY UPDATE Id = LAST_INSERT_ID(Id),expiryDate = inExpiryDate, LastAccess = inLastAccess, AccessCount = Accesscount + 1;

Set _userId = LAST_INSERT_ID();

INSERT INTO appsite_mobileusers (AppsiteId, MobileUserId, LastAccess) VALUES (inAppsiteId, _userId , inLastAccess)
ON DUPLICATE KEY UPDATE LastAccess = inLastAccess;

INSERT INTO mobileusers_details (MobileUserId, CountryId, OperatorId, DeviceId, ManufacturerId, PlatformId) VALUES (_userId,inCountryId,inOperatorId,inDeviceId,inManufacturerId,inPlatformId)
ON DUPLICATE KEY UPDATE CountryId = inCountryId, OperatorId =  inOperatorId, DeviceId = inDeviceId, ManufacturerId = inManufacturerId , PlatformId = inPlatformId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NativeAdIconGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `NativeAdIconGetByAdId`(IN inNativeAdId INT)
BEGIN

SELECT Id, CreativeUnitId, MIMETypeId, Url FROM native_ad_icons WHERE NativeAdId = inNativeAdId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NativeAdIconSizeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `NativeAdIconSizeGetAll`()
BEGIN

SELECT a.Id, a.Width, a.Height, a.Code, b.Priority 
FROM creativeunits a
inner join creativeunit_groups_mapping b on a.Id = b.CreativeUnitId
inner join creativeunit_groups c on b.GroupId = c.Id
where c.Code = 9; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NativeAdImageGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `NativeAdImageGetByAdId`(IN inNativeAdId INT)
BEGIN

SELECT Id, CreativeUnitId, MIMETypeId, Url FROM native_ad_images WHERE NativeAdId = inNativeAdId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NativeAdImageSizeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `NativeAdImageSizeGetAll`()
BEGIN

SELECT a.Id, a.Width, a.Height, a.Code, b.Priority 
FROM creativeunits a
inner join creativeunit_groups_mapping b on a.Id = b.CreativeUnitId
inner join creativeunit_groups c on b.GroupId = c.Id
where c.Code = 10; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NativeAdLayoutGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `NativeAdLayoutGetAll`()
BEGIN

SELECT Id, Code FROM native_ad_layouts;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ObjectiveTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ObjectiveTypeGetAll`()
BEGIN

SELECT Id, Code FROM adgroupobjectivetypes;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ODCCallsGetPerTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ODCCallsGetPerTime`(IN inTime DateTime)
BEGIN

SELECT TotalCalls, FirstRetries, ManyRetries, InfiniteRetries, NoMatches, Errors FROM odc_calls WHERE Time = inTime;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ODCCallsGetPerTimeRange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ODCCallsGetPerTimeRange`(IN inStartTime DateTime, IN inEndTime DateTime)
BEGIN

SELECT SUM(TotalCalls) TotalCalls, SUM(FirstRetries) FirstRetries, SUM(ManyRetries) ManyRetries, SUM(InfiniteRetries) InfiniteRetries, SUM(NoMatches) NoMatches, SUM(Errors) Errors FROM odc_calls WHERE Time >= inStartTime AND Time <= inEndTime;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ODCCountersSave` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ODCCountersSave`(IN inTime DateTime, IN inTotalCalls int, IN inFirstRetries int, IN inManyRetries int, IN inInfiniteRetries int, IN inNoMatches int, IN inErrors int)
BEGIN

INSERT INTO odc_calls (Time, TotalCalls, FirstRetries, ManyRetries, InfiniteRetries, NoMatches, Errors) VALUES (inTime, inTotalCalls, inFirstRetries, inManyRetries, inInfiniteRetries, inNoMatches, inErrors)
ON DUPLICATE KEY UPDATE 
TotalCalls = TotalCalls + VALUES(TotalCalls),
FirstRetries = FirstRetries + VALUES(FirstRetries),
ManyRetries = ManyRetries + VALUES(ManyRetries),
InfiniteRetries = InfiniteRetries + VALUES(InfiniteRetries),
NoMatches = NoMatches + VALUES(NoMatches),
Errors = Errors + VALUES(Errors);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OperatorGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `OperatorGetAll`()
BEGIN

Select OperatorId, LocationId CountryId, MobileNetworkCodes from operators;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OperatorIPGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `OperatorIPGetAll`()
BEGIN

Select OperatorId, IPRangeStart, IPRangeEnd from operator_ips;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OperatorMappingGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `OperatorMappingGetAll`()
BEGIN
Select Id, OperatorId, ISP, ORG from operatorsmapping Where IsDeleted  = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PixelGetByCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PixelGetByCode`(IN inCode INT)
BEGIN

SELECT Id, Code, Name, Status, IsDeleted FROM pixels WHERE Code = inCode;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PixelGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PixelGetById`(IN inId INT)
BEGIN

SELECT Id, Code, Name, Status, IsDeleted FROM pixels WHERE Id = inId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PlatformCodeGetByPlatformId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PlatformCodeGetByPlatformId`(IN inPlatformId INT)
BEGIN

Select PC.Code 
From  platformcodes PC
WHERE PC.PlatformId = inPlatformId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PlatformGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PlatformGetAll`()
BEGIN

Select PlatformId From platforms;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PlatformVersionMappingGetByPlatformId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PlatformVersionMappingGetByPlatformId`(IN inPlatformId INT)
BEGIN

SELECT PM.Id, PM.InputValue, PM.StandardValue 
FROM platform_version_mapping PM
Where PM.PlatformId = inPlatformId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PopulateFactTables` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `PopulateFactTables`()
BEGIN
DECLARE Startv	INT;
DECLARE Endv	INT; 
DECLARE RowNum INT;
DECLARE AppRowNum INT;
DECLARE AdsID INT;
DECLARE MaxTempID INT;
DECLARE MaxTempAppID INT;
DECLARE AppSiteID INT;
DECLARE AppName VARCHAR(200);


DROP TEMPORARY TABLE IF EXISTS TempAdsTable;
 

CREATE TEMPORARY TABLE TempAdsTable
(
	RowNum	int AUTO_INCREMENT NOT NULL ,
	AdsID	INT(11),
PRIMARY KEY (`RowNum`) 
) ENGINE=MEMORY;

Insert Into TempAdsTable( AdsID)
Select  ID
From ads;

DROP TEMPORARY TABLE IF EXISTS TempAppTable;
 

CREATE TEMPORARY TABLE TempAppTable
(
	RowNum	int AUTO_INCREMENT NOT NULL ,
	AppSiteID	INT(11),
PRIMARY KEY (`RowNum`) 
) ENGINE=MEMORY;

Insert Into TempAppTable( AppSiteID)
Select  ID
From AppSite;


SET MaxTempID = (Select Count(1) From TempAdsTable);
SET MaxTempAppID = (Select Count(1) From TempAppTable);

SET Startv = 1;
    SET Endv = 5;

    WHILE Startv <= Endv DO

				
				
				SET @RowNum := (Select (1+ FLOOR((RAND() * MaxTempID))));
SET @AppRowNum := (Select (1+ FLOOR((RAND() * MaxTempAppID))));

				
				SET @adsID := (Select TempAdsTable.AdsID From TempAdsTable Where TempAdsTable.RowNum = @RowNum);
				SET @adsGroupID := (SELECT AdGroupID From ads WHERE ID = @adsID);				
				SET @AdsSpend := (SELECT Spend From ads WHERE ID = @adsID);
				SET @DimCampaignID := (SELECT CampaignID From adgroups WHERE ID = @adsGroupID);
				SET @adsName := (SELECT Name From ads WHERE ID = @adsID);
				SET @adsGroupName := (SELECT Name From adgroups WHERE ID = @adsGroupID);	
				SET @CampaignName := (SELECT Name From campaigns WHERE ID = @DimCampaignID);
				SET @AppID := (Select TempAppTable.AppSiteID From TempAppTable Where TempAppTable.RowNum = @AppRowNum);
				SET @AppName := (SELECT Name From appsite WHERE appsite.ID = @AppID);

 
				
        INSERT INTO fact_stat_app_copy
        (AppStatID, DimCountryID, DimDateID, DimDeviceID, DimManufacturerID, DimOperatorID,
					DimPlatformID, DimTimeKey, DimHoursTimeKey, Request, Impression, Clicks, Revenue, AppSiteID, AppName,
					AppAccountID, FillRate, CTR, ECPM)
        VALUES (MD5(RAND() +  Startv), (809+ FLOOR((RAND() * 285))), 
				DATE_FORMAT(('2011-01-01' + interval rand()*365 day), '%Y%m%d'), 
				(1+ FLOOR((RAND() * 305))), (1+ FLOOR((RAND() * 38))), (1+ FLOOR((RAND() * 604))), (1+ FLOOR((RAND() * 8))), 
				(1+ FLOOR((RAND() * 23))), (1+ FLOOR((RAND() * 3))), FLOOR((RAND() * 10000)), FLOOR((RAND() * 10000)), 
				FLOOR((RAND() * 10000)), FLOOR((RAND() * 10000)), 
				@AppID, @AppName, (1+ FLOOR((RAND() * 35))), 0, 0, 0);	

				INSERT INTO fact_stat_campaign_copy
        (CampaignStatID, DimCampaignID, DimCountryID, DimDateID, DimDeviceID, DimManufacturerID, DimOperatorID, DimPlatformID,
					DimTimeKey, DimHoursTimeKey, Impression, Clicks, adsGroupID, AccountID, adsID, AdsSpend, CampaignName, adsName, adsGroupName, CTR, AvgCPC)
        VALUES (MD5(RAND()), @DimCampaignID, (809+ FLOOR((RAND() * 285))), 
				DATE_FORMAT(('2011-01-01' + interval rand()*365 day), '%Y%m%d'), 
				(1+ FLOOR((RAND() * 305))), (1+ FLOOR((RAND() * 38))), (1+ FLOOR((RAND() * 604))), (1+ FLOOR((RAND() *8))), 
				FLOOR((RAND() * 24)), (1+ FLOOR((RAND() * 3))), FLOOR((RAND() * 10000)), FLOOR((RAND() * 10000)), @adsGroupID, (1+ FLOOR((RAND() * 35))),
				@adsID, @AdsSpend, @CampaignName, @adsName, @adsGroupName, 0, 0);	

        SET Startv = Startv + 1;
    END WHILE;


drop table TempAdsTable;
drop table TempAppTable;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ReadAllTransactionLogs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ReadAllTransactionLogs`()
BEGIN



DECLARE EXIT HANDLER FOR SQLEXCEPTION   
BEGIN
select 'exception has occured';
ROLLBACK;   
END;

START TRANSACTION;

SET @@session.max_join_size = 100000000;
SET @StartDate := '2011-12-19 00:00:00';
SET @NoOfTables := 7;
SET @TableIndex := 0; 


DROP TEMPORARY TABLE IF EXISTS tblCounters;
CREATE TEMPORARY TABLE tblCounters (
        Requests int NOT NULL DEFAULT 0,
        Clicks int NOT NULL DEFAULT 0,
        Impressions int NOT NULL DEFAULT 0
    ) ENGINE=Memory;
    
WHILE @TableIndex <= @NoOfTables DO

SET @stmt_text1 := CONCAT("INSERT INTO tblCounters (Requests) select sum(transtype) Requests from adfalcon_logs.trans_ad_log_", DATE_FORMAT(@StartDate, '%Y_%m_%d'),
" where transtype = 0 and adid in (23937,23938,23939,23940);");
PREPARE stmt1 FROM @stmt_text1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

SET @stmt_text2 := CONCAT("INSERT INTO tblCounters (Impressions) select sum(transtype) Impressions from adfalcon_logs.trans_ad_log_", DATE_FORMAT(@StartDate, '%Y_%m_%d'),
" where transtype = 1 and adid in (23937,23938,23939,23940);");
PREPARE stmt2 FROM @stmt_text2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

SET @stmt_text3 := CONCAT("INSERT INTO tblCounters (Clicks) select sum(transtype) Clicks from adfalcon_logs.trans_ad_log_", DATE_FORMAT(@StartDate, '%Y_%m_%d'),
" where transtype = 2 and adid in (23937,23938,23939,23940);");
PREPARE stmt3 FROM @stmt_text3;
EXECUTE stmt3;
DEALLOCATE PREPARE stmt3;


SET @StartDate := DATE_ADD(@StartDate, INTERVAL 1 DAY);
SET @TableIndex := @TableIndex + 1;

END WHILE;

select  sum(Requests) from tblCounters;
select  sum(Impressions) from tblCounters;
select  sum(Clicks) from tblCounters;

COMMIT;
SET @@Session.MAX_JOIN_SIZE=default;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RegionNameToCodeMappingGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RegionNameToCodeMappingGetAll`()
BEGIN
SELECT Id, CountryId, Name, FIPS_Code FROM region_name_to_code_mapping;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `replace_keyword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `replace_keyword`(old_keyword_id int,new_keyword_id int)
BEGIN
update appsitekeywords set KeywordId=new_keyword_id
where KeywordId=old_keyword_id  and id>0;

update keywordtargetings set keywordId=new_keyword_id
where KeywordId=old_keyword_id  and id>0;

update keywordsfilters set KeywordId=new_keyword_id
where KeywordId=old_keyword_id  and id>0;

update campaigns set KeywordId=new_keyword_id where KeywordId=old_keyword_id  and id>0;

update ads set KeywordId=new_keyword_id where KeywordId=old_keyword_id  and id>0;

delete from localizedstrings  
where localizedstringid in (select nameid from keywords where id=old_keyword_id) and id>0;

delete from localizedstringids  
where localizedstringid in (select nameid from keywords where id=old_keyword_id) and localizedstringid>0;

DELETE from  keywords where id=old_keyword_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `report_SpendByCampaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `report_SpendByCampaign`(in targetDate int, in queryType varchar(10))
begin 
	SET group_concat_max_len = 1000000;
	select upper(queryType) into @qt;
	select targetDate into @targetDate;
	select 
		case 
			when @qt = 'WTD' then common_schema.date_weekid(@targetDate) 
            when @qt IN('YTD', 'ALL') then FLOOR((@targetDate / 10000)) * 10000
			else FLOOR((@targetDate / 100)) * 100 
        end into @startDate;

	with ciids as (select costitemid from adfalcon.cost_items_performance where day between @startDate and @targetDate group by 1)
	select GROUP_CONCAT(CONCAT(' SUM(case when costitemid = ', costitemid, ' then Amount else 0 end) as `', costitemid, ' - ', Value, '`')) s, 
		GROUP_CONCAT(CONCAT(' ci.`', costitemid, ' - ', Value, '`')) ss
	into @agg, @cols
	from ciids 
	inner join adfalcon.cost_items ci on ci.id = ciids.costitemid
	inner join adfalcon.localizedstrings s1 ON NameId = s1.LocalizedStringID AND s1.Culture = 'en-US';

-- 	select  @agg, @cols;
	select  CONCAT('with 
		cids as (select distinct Campaignid from adfalcon.campaignsperformance where day between @startDate and @targetDate),
		agids as (select distinct AdGroupId from adfalcon.adgroupsperformance where day between @startDate and @targetDate)
	select 
		cm.Name as `Campaign Name`, 
		ca.*, 
		case when ca.BillableCost <> 0 then (ca.AdFalconRevenue + ifnull(ci.afcirevenue, 0)) / ca.BillableCost else 0 end `Gross Margin`,
		ifnull(ci.afcirevenue, 0) `Cost Items AdFalcon Revenue`,
        ', ifnull(@cols, ' 0 as `N/A`'), '
	from 
	(
		select 
			cids.Campaignid,
			case when sum(Impressions) <> 0 then sum(Clicks) / sum(Impressions) else 0 end as CTR,
			sum(BillableCost) BillableCost,
			sum(NetCost) NetCost,
			sum(AdjustedNetCost) AdjustedNetCost,
			sum(AdFalconRevenue) AdFalconRevenue,
			sum(DataFee) DataFee
		from 
			cids
			inner join adfalcon.campaignsperformance cp on cp.Campaignid = cids.Campaignid', 
			case 
				when @qt IN ('MTD', 'WTD', 'YTD', 'ALL') then ' where cp.day between @startDate and @targetDate '
				-- when @qt = 'ALL' then ' '
				else ' where  cp.day = @targetDate '
			end, '
		group by 1
	) ca left join 
	(
		select 
			CampaignId, 
            SUM(case when ci.Category & 32 = 32 then Amount else 0 end) as afcirevenue,
            ' , ifnull(@agg, '0 as `N/A`') , '
		from 
			agids 
			inner join adfalcon.adgroups ag on agids.AdGroupId = ag.Id
			inner join adfalcon.cost_items_performance cip on cip.AdGroupId = ag.id 
            left join adfalcon.cost_items ci on cip.CostItemId = ci.Id ',
					case 
				when @qt IN ('MTD', 'WTD', 'YTD', 'ALL') then ' where cip.day between @startDate and @targetDate '
				-- when @qt = 'ALL' then ' '
				else ' where cip.day = @targetDate '
			end,'
		group by 1
	) ci on ca.CampaignId = ci.CampaignId
	inner join adfalcon.campaigns cm on cm.id = ca.CampaignId;') into @sql_st;

 
-- SELECT @sql_st, @agg, @cols;

	PREPARE stmt from @sql_st;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `report_SpendTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `report_SpendTotal`(in targetDate int, in queryType varchar(10))
begin 
	SET group_concat_max_len = 1000000;
	select upper(queryType) into @qt;
	select targetDate into @targetDate;
	select 
		case 
			when @qt = 'WTD' then common_schema.date_weekid(@targetDate) 
            when @qt IN('YTD', 'ALL') then FLOOR((@targetDate / 10000)) * 10000
			else FLOOR((@targetDate / 100)) * 100 
        end into @startDate;

	with ciids as (select costitemid from adfalcon.cost_items_performance where day between @startDate and @targetDate group by 1)
	select GROUP_CONCAT(CONCAT(' SUM(case when costitemid = ', costitemid, ' then Amount else 0 end) as `', costitemid, ' - ', Value, '`')) s, 
		GROUP_CONCAT(CONCAT(' ci.`', costitemid, ' - ', Value, '`')) ss
	into @agg, @cols
	from ciids 
	inner join adfalcon.cost_items ci on ci.id = ciids.costitemid
	inner join adfalcon.localizedstrings s1 ON NameId = s1.LocalizedStringID AND s1.Culture = 'en-US';

	-- 	select  @agg, @cols;
	select  CONCAT('with 
		cids as (select distinct Campaignid from adfalcon.campaignsperformance where day between @startDate and @targetDate),
		agids as (select distinct AdGroupId from adfalcon.adgroupsperformance where day between @startDate and @targetDate)
	select ca.*, 
		case when ca.BillableCost <> 0 then (ca.AdFalconRevenue + ifnull(ci.afcirevenue, 0)) / ca.BillableCost else 0 end `Gross Margin`,
		ifnull(ci.afcirevenue, 0) `Cost Items AdFalcon Revenue`,
		', ifnull(@cols, ' 0 as `N/A`'), '
	from 
	(
		select 
			sum(BillableCost) BillableCost,
			sum(NetCost) NetCost,
			sum(AdjustedNetCost) AdjustedNetCost,
			sum(AdFalconRevenue) AdFalconRevenue,
			sum(DataFee) DataFee
		from 
			cids
			inner join adfalcon.campaignsperformance cp on cp.Campaignid = cids.Campaignid', 
			case 
				when @qt IN ('MTD', 'WTD', 'ALL', 'YTD') then ' where cp.day between @startDate and @targetDate '
-- 				when @qt = 'ALL' then ' '
				else ' where  cp.day = @targetDate '
			end, '
	) ca' , case when @agg is null then ', (select 0 as afcirevenue) ci;' 
    else 
    CONCAT(',
	(
		select SUM(case when ci.Category & 32 = 32 then Amount else 0 end) as afcirevenue, 
			' , @agg , '
		from 
			agids 
			inner join adfalcon.cost_items_performance cip on cip.AdGroupId = agids.AdGroupId
            left join adfalcon.cost_items ci on (cip.CostItemId = ci.Id) ',
					case 
				when @qt IN ('MTD', 'WTD', 'ALL', 'YTD') then ' where cip.day between @startDate and @targetDate '
-- 				when @qt = 'ALL' then ' '
				else ' where cip.day = @targetDate '
			end,'
	) ci ;') end ) into @sql_st;

	-- 	SELECT @sql_st;

	PREPARE stmt from @sql_st;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResourceAdd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ResourceAdd`(
      ResourceSetVar varchar(64), 
	  ResourceKeyVar varchar(64),
	  ResourceValueVar varchar(512),
	  CultureCodeVar char(5)
     )
BEGIN

	INSERT INTO Resources
                         (ResourceSet, ResourceKey, CultureCode, ResourceValue)
VALUES        (ResourceSetVar, ResourceKeyVar, CultureCodeVar, ResourceValueVar);
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResourceByCultureAndKeyGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ResourceByCultureAndKeyGet`(
      ResourceSetVar varchar(64), 
	 ResourceKeyVar varchar(64),
	 CultureCodeVar char(5)
     )
BEGIN

	SELECT        ResourceID, ResourceSet, ResourceKey, CultureCode, ResourceValue
FROM            resources 
where ResourceSet=ResourceSetVar and CultureCode=CultureCodeVar and ResourceKey = ResourceKeyVar;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResourcesByCultureAndResourceSetGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ResourcesByCultureAndResourceSetGet`(
      ResourceSetVar varchar(64), 
	 CultureCodeVar char(5)
     )
Begin

	SELECT        ResourceID, ResourceSet, ResourceKey, CultureCode, ResourceValue
FROM            resources
where ResourceSet= CONVERT(ResourceSetVar USING utf8) COLLATE utf8_general_ci   
and CultureCode = CONVERT(CultureCodeVar USING utf8)  COLLATE utf8_general_ci
COLLATE utf8_general_ci   ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RtbPartnerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RtbPartnerGetAll`()
BEGIN

Select RP.Id, RP.Code, RP.AppsiteId, RP.DefaultSeatId, RP.OpenRtbVersion From rtb_partners RP ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RubiconDefaultAdCreativeUnitGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RubiconDefaultAdCreativeUnitGet`(IN inRubiconDefaultCampaignId INT)
BEGIN

SELECT Id FROM adcreativeunits WHERE AdId IN (select Id from ads where AdGroupId IN (SELECT Id FROM adgroups WHERE CampaignId = inRubiconDefaultCampaignId));

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeAdDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeAdDelete`(IN inTrackEndDate datetime)
BEGIN

DELETE FROM runtime_ad WHERE TrackEndDate <= NOW();
UPDATE runtime_ad SET IsDeleted = 1, TrackEndDate = inTrackEndDate WHERE AdId NOT IN (SELECT Id FROM ads WHERE StatusId = 10 AND IsDeleted = 0) AND IsDeleted = 0;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeAdGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeAdGetAll`()
BEGIN

SELECT AdId, DisplayCount, IsDeleted, TrackEndDate FROM runtime_ad;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeAdInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeAdInsert`()
BEGIN

INSERT INTO runtime_ad (AdId, AdGroupId ,LanguageId, URL, KeywordId, Text, TypeId, SubTypeId, DisableProxyTraffic, EnvironmentTypeId, OrientationTypeId) 
SELECT AD.Id,
G.Id AS AdGroupId,
AD.LanguageId,
ADV.Value AS URL,
C.KeywordId,
AD.AdText AS Text,
AD.TypeId,
AD.SubTypeId,
G.DisableProxyTraffic,
AD.EnvironmentTypeId,
AD.OrientationTypeId
FROM ads AD 
INNER JOIN adgroups G ON AD.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
INNER JOIN account AC ON C.AccountId = AC.Id 
LEFT JOIN business_partners BP ON AC.Id = BP.AccountId 
LEFT JOIN adactionvalues ADV ON ADV.AdId = AD.Id
WHERE AD.StatusId = 10 /*Running*/ AND AD.TypeId NOT IN (7,8) /*Tracking, Companion*/  AND (BP.AccountId IS NULL OR BP.TypeId != 5 /*DSP*/ OR C.TypeId = 3 /*PG*/) AND AD.IsDeleted = 0
ON DUPLICATE KEY UPDATE 
AdGroupId=VALUES(AdGroupId),
LanguageId=VALUES(LanguageId),
URL=VALUES(URL),
KeywordId=VALUES(KeywordId),
Text=VALUES(Text), 
TypeId=VALUES(TypeId),
SubTypeId=VALUES(SubTypeId),
DisableProxyTraffic=VALUES(DisableProxyTraffic),
EnvironmentTypeId=VALUES(EnvironmentTypeId),
OrientationTypeId=VALUES(OrientationTypeId),
DisplayCount = 0,
IsDeleted = 0,
TrackEndDate = NULL;

-- UPDATE campaigns SET isRuntime = TRUE WHERE Id in (select CampaignId from adgroups where Id in (select AdGroupId from ads where Id in (select AdId from runtime_ad)));
UPDATE campaigns SET isRuntime = TRUE WHERE Id in (select CampaignId from adgroups where Id in (select AdGroupId from ads where StatusId = 10 and IsDeleted = 0));
-- UPDATE campaigns SET isRuntime = TRUE WHERE Id in (select CampaignId from adgroups where Id in (select AdGroupId from ads where TypeId = 7));

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeAdInsert_Manual` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeAdInsert_Manual`()
BEGIN

INSERT INTO runtime_ad (AdId, AdGroupId ,LanguageId,URL,KeywordId,Text,ActionTypeId,TypeId,SubTypeId,DisableProxyTraffic,EnvironmentTypeId,OrientationTypeId) 
SELECT AD.Id,



G.Id AS AdGroupId,






AD.LanguageId,
ADV.Value AS URL,
C.KeywordId,
AD.AdText AS Text,
GO.ActionTypeId,
AD.TypeId,
AD.SubTypeId,
G.DisableProxyTraffic,
AD.EnvironmentTypeId,
AD.OrientationTypeId
FROM ads AD 
INNER JOIN adgroups G ON AD.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id


LEFT JOIN adgroupobjectives GO ON GO.AdGroupId = G.Id
LEFT JOIN adactionvalues ADV ON ADV.AdId = AD.Id
WHERE AD.StatusId = 10  AND AD.TypeId NOT IN (7,8)  AND AD.IsDeleted = 0 AND AD.Id NOT IN (SELECT AdId FROM runtime_ad)
AND C.Id in (158571);

UPDATE campaigns SET isRuntime = TRUE WHERE Id in (select CampaignId from adgroups where Id in (select AdGroupId from ads where Id in (select AdId from runtime_ad)));
UPDATE campaigns SET isRuntime = TRUE WHERE Id in (select CampaignId from adgroups where Id in (select AdGroupId from ads where TypeId = 7 ));

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeAdUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeAdUpdate`()
BEGIN

UPDATE runtime_ad R
INNER JOIN ads AD ON R.AdId = AD.Id
INNER JOIN adgroups G ON AD.AdGroupId = G.Id
INNER JOIN campaigns C ON G.CampaignId = C.Id
LEFT JOIN adactionvalues ADV ON ADV.AdId = AD.Id
SET
R.AdGroupId=G.Id,
R.LanguageId=AD.LanguageId,
R.URL=ADV.Value,
R.KeywordId=C.KeywordId,
R.Text=AD.AdText, 
R.TypeId=AD.TypeId,
R.SubTypeId=AD.SubTypeId,
R.DisableProxyTraffic=G.DisableProxyTraffic,
R.EnvironmentTypeId=AD.EnvironmentTypeId,
R.OrientationTypeId=AD.OrientationTypeId;

UPDATE runtime_ad R
SET R.DisplayCount = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimePerformanceHasEnoughBudget` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimePerformanceHasEnoughBudget`(in inAdGroupId int, in inSpend DECIMAL(21,12), in inDay int, in inVerifyDailyBudget bool, out hasBudget bool)
BEGIN



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimePerformanceHasEnoughBudget_WithUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimePerformanceHasEnoughBudget_WithUpdate`(in inAdGroupId int, in inCampaignId int, in inAccountId int, in inSpend DECIMAL(21,12), in inDay int, in inVerifyDailyBudget bool, out hasBudget bool)
BEGIN



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeTargetingDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeTargetingDelete`()
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION   
BEGIN
ROLLBACK;  
RESIGNAL; 
END;

START TRANSACTION;


delete from runtime_geographic_targetings 
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_demographic_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_operator_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_device_manufacturer_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_device_platform_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_device_model_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_device_capability_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_device_type_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);


delete from runtime_appsite_ad_queue
where 
adid not in (select id from ads where statusid = 10 and isdeleted = 0);


delete from runtime_language_targetings
where 
groupid not in (select adgroupid from ads where statusid = 10 and isdeleted = 0);

COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeTargetingInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeTargetingInsert`()
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION   
BEGIN
ROLLBACK; 
RESIGNAL;  
END;

START TRANSACTION;


insert into runtime_geographic_targetings(groupid,locationid,locationtype)
select distinct t.adgroupid,g.locationid,l.locationtype from geographictargetings g 
inner join targetings t on g.id = t.id
inner join locations l on g.LocationId = l.Id
where t.adgroupid not in (select groupid from runtime_geographic_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_demographic_targetings(groupid,GenderId,AgeGroupId)
select distinct t.adgroupid,d.GenderId,d.AgeGroupId from demographictargeting d 
inner join targetings t on d.id = t.id
where t.adgroupid not in (select groupid from runtime_demographic_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_operator_targetings(groupid,operatorid)
select distinct t.adgroupid,p.operatorid from operatortargetings p 
inner join targetings t on p.id = t.id
where t.adgroupid not in (select groupid from runtime_operator_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_device_manufacturer_targetings(groupid,manufacturerid)
select distinct t.adgroupid,m.manufacturerid from devicetargetingmanufacturers m 
inner join devicetargetings dt on dt.Id = m.DeviceTargetingId
inner join targetings t on t.id = dt.id
where t.adgroupid not in (select groupid from runtime_device_manufacturer_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_device_platform_targetings(groupid,platformid)
select distinct t.adgroupid,p.platformid from devicetargetingplatforms p 
inner join devicetargetings dt on dt.Id = p.DeviceTargetingId
inner join targetings t on t.id = dt.Id
where t.adgroupid not in (select groupid from runtime_device_platform_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_device_model_targetings(groupid,modelid,manufacturerId,platformId,include)
select distinct t.adgroupid,dd.DeviceId,d.ManufacturerId,d.PlatformId,dd.Include from devicetargetingdevices dd 
inner join devicetargetings dt on dt.Id = dd.DeviceTargetingId
inner join targetings t on t.id = dt.id
inner join devices d on dd.deviceid= d.id
where t.adgroupid not in (select groupid from runtime_device_model_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_device_capability_targetings(groupid,capabilityId,include)
select distinct t.adgroupid,dc.capabilityId,dc.include from device_targeting_device_capabilities dc 
inner join devicetargetings dt on dt.Id = dc.DeviceTargetingId
inner join targetings t on t.id = dt.id
where t.adgroupid not in (select groupid from runtime_device_capability_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_device_type_targetings(groupid,devicetypeId)
select distinct t.adgroupid,dtt.devicetypeId from device_targeting_type dtt 
inner join devicetargetings dt on dt.Id = dtt.DeviceTargetingId
inner join targetings t on t.id = dt.id
where t.adgroupid not in (select groupid from runtime_device_type_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


insert into runtime_appsite_ad_queue(appsiteid,adid ,include)
select distinct q.appsiteid,q.adid,q.include from appsite_ad_queue q 
where q.adid not in (select adid from runtime_appsite_ad_queue where appsiteid = q.appsiteid)
and q.adid in (select id from ads where statusid = 10 and isdeleted = 0);


insert into runtime_language_targetings(groupid,languageId)
select distinct t.adgroupid,l.languageId from language_targetings l 
inner join targetings t on l.id = t.id
where t.adgroupid not in (select groupid from runtime_language_targetings)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RuntimeTargetingUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `RuntimeTargetingUpdate`(in inLastRuntimeTargetingUpdateDate datetime, in inTillDate datetime)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION   

BEGIN
ROLLBACK;   
RESIGNAL;
END;

START TRANSACTION;

-- ------------------------
-- geographic targetings
-- ------------------------

insert into runtime_geographic_targetings(groupid,locationid,locationtype)
select t.adgroupid,g.locationid,l.locationtype from geographictargetings g 
inner join targetings t on g.id = t.id
inner join locations l on g.LocationId = l.Id
where g.modifiedon >= inLastRuntimeTargetingUpdateDate AND g.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_geographic_targetings)
and locationid not in (select locationid from runtime_geographic_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

/*
update runtime_geographic_targetings r
inner join targetings t on r.groupid = t.adgroupid
inner join geographictargetings g on g.id = t.id and g.locationid = r.locationid
inner join locations l on r.LocationId = l.Id
set r.locationid=g.locationid,r.locationtype=l.locationtype;
*/

delete from runtime_geographic_targetings
where 
groupid not in (select t.adgroupid from geographictargetings g inner join targetings t on g.id = t.id where t.isdeleted = 0)
or locationid not in (select g.locationid from geographictargetings g inner join targetings t on g.id = t.id where t.adgroupid = runtime_geographic_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- demographic targetings
-- -------------------------

update runtime_demographic_targetings r
inner join targetings t on r.groupid = t.adgroupid
inner join demographictargeting d on d.id = t.id 
set r.GenderId=d.GenderId, r.AgeGroupId=d.AgeGroupId;

delete from runtime_demographic_targetings
where 
groupid not in (select t.adgroupid from demographictargeting d inner join targetings t on d.id = t.id where t.isdeleted = 0);

-- -------------------------
-- operator targetings
-- -------------------------

insert into runtime_operator_targetings(groupid,operatorid)
select t.adgroupid,p.operatorid from operatortargetings p 
inner join targetings t on p.id = t.id
where p.modifiedon >= inLastRuntimeTargetingUpdateDate AND p.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_operator_targetings)
and operatorid not in (select operatorid from runtime_operator_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

delete from runtime_operator_targetings
where 
groupid not in (select t.adgroupid from operatortargetings p inner join targetings t on p.id = t.id where t.isdeleted = 0)
or operatorid not in (select p.operatorid from operatortargetings p inner join targetings t on p.id = t.id where t.adgroupid = runtime_operator_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- device_manufacturer targetings
-- -------------------------

insert into runtime_device_manufacturer_targetings(groupid,manufacturerid)
select t.adgroupid,m.manufacturerid from devicetargetingmanufacturers m 
inner join devicetargetings dt on dt.Id = m.DeviceTargetingId
inner join targetings t on t.id = dt.id
where m.modifiedon >= inLastRuntimeTargetingUpdateDate AND m.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_device_manufacturer_targetings)
and manufacturerid not in (select manufacturerid from runtime_device_manufacturer_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


delete from runtime_device_manufacturer_targetings
where 
groupid not in (select t.adgroupid from devicetargetingmanufacturers m inner join devicetargetings dt on dt.Id = m.DeviceTargetingId inner join targetings t on dt.id = t.id where t.isdeleted = 0)
or manufacturerid not in (select m.manufacturerid from devicetargetingmanufacturers m inner join devicetargetings dt on dt.Id = m.DeviceTargetingId inner join targetings t on dt.id = t.id where t.adgroupid = runtime_device_manufacturer_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- device_platform targetings
-- -------------------------

insert into runtime_device_platform_targetings(groupid,platformid)
select t.adgroupid,p.platformid from devicetargetingplatforms p 
inner join devicetargetings dt on dt.Id = p.DeviceTargetingId
inner join targetings t on t.id = dt.id
where p.modifiedon >= inLastRuntimeTargetingUpdateDate AND p.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_device_platform_targetings)
and platformid not in (select platformid from runtime_device_platform_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;


delete from runtime_device_platform_targetings
where 
groupid not in (select t.adgroupid from devicetargetingplatforms p inner join devicetargetings dt on dt.Id = p.DeviceTargetingId inner join targetings t on dt.id = t.id where t.isdeleted = 0)
or platformid not in (select p.platformid from devicetargetingplatforms p inner join devicetargetings dt on dt.Id = p.DeviceTargetingId inner join targetings t on dt.id = t.id where t.adgroupid = runtime_device_platform_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- device_model targetings
-- -------------------------

insert into runtime_device_model_targetings(groupid,modelid,manufacturerId,platformId,include)
select t.adgroupid,dd.DeviceId,d.ManufacturerId,d.PlatformId,dd.include from devicetargetingdevices dd 
inner join devicetargetings dt on dt.Id = dd.DeviceTargetingId
inner join targetings t on t.id = dt.id
inner join devices d on dd.deviceid= d.id
where dd.modifiedon >= inLastRuntimeTargetingUpdateDate AND dd.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_device_model_targetings)
and DeviceId not in (select modelid from runtime_device_model_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

update runtime_device_model_targetings r
inner join targetings t on r.groupid = t.adgroupid
inner join devicetargetings dt on dt.Id = t.id
inner join devicetargetingdevices dd on dd.DeviceTargetingId = dt.id and dd.deviceId = r.modelid
set r.include=dd.include;

delete from runtime_device_model_targetings
where 
groupid not in (select t.adgroupid from devicetargetingdevices dd inner join devicetargetings dt on dt.Id = dd.DeviceTargetingId inner join targetings t on dt.id = t.id where t.isdeleted = 0)
or modelid not in (select dd.DeviceId from devicetargetingdevices dd inner join devicetargetings dt on dt.Id = dd.DeviceTargetingId inner join targetings t on dt.id = t.id where t.adgroupid = runtime_device_model_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- device_capability targetings
-- -------------------------

insert into runtime_device_capability_targetings(groupid,capabilityId,include)
select t.adgroupid,dc.capabilityId,dc.include from device_targeting_device_capabilities dc 
inner join devicetargetings dt on dt.Id = dc.DeviceTargetingId
inner join targetings t on t.id = dt.id
where dc.modifiedon >= inLastRuntimeTargetingUpdateDate AND dc.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_device_capability_targetings)
and capabilityId not in (select capabilityId from runtime_device_capability_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

update runtime_device_capability_targetings r
inner join targetings t on r.groupid = t.adgroupid
inner join devicetargetings dt on dt.Id = t.id
inner join device_targeting_device_capabilities dc on dc.DeviceTargetingId = dt.id and dc.capabilityId = r.capabilityId
set r.include=dc.include;

delete from runtime_device_capability_targetings
where 
groupid not in (select t.adgroupid from device_targeting_device_capabilities dc inner join devicetargetings dt on dt.Id = dc.DeviceTargetingId inner join targetings t on dt.id = t.id where t.isdeleted = 0)
or capabilityId not in (select dc.capabilityId from device_targeting_device_capabilities dc inner join devicetargetings dt on dt.Id = dc.DeviceTargetingId inner join targetings t on dt.id = t.id where t.adgroupid = runtime_device_capability_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- device_type targetings
-- -------------------------

insert into runtime_device_type_targetings(groupid,devicetypeId)
select t.adgroupid,dtt.devicetypeId from device_targeting_type dtt 
inner join devicetargetings dt on dt.Id = dtt.DeviceTargetingId
inner join targetings t on t.id = dt.id
where dtt.modifiedon >= inLastRuntimeTargetingUpdateDate AND dtt.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_device_type_targetings)
and devicetypeId not in (select devicetypeId from runtime_device_type_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

delete from runtime_device_type_targetings
where 
groupid not in (select t.adgroupid from device_targeting_type dtt inner join devicetargetings dt on dt.Id = dtt.DeviceTargetingId inner join targetings t on dt.id = t.id where t.isdeleted = 0)
or devicetypeId not in (select dtt.devicetypeId from device_targeting_type dtt inner join devicetargetings dt on dt.Id = dtt.DeviceTargetingId inner join targetings t on dt.id = t.id where t.adgroupid = runtime_device_type_targetings.groupid and t.isdeleted = 0);

-- -------------------------
-- appsite_ad_queue targetings
-- -------------------------

insert into runtime_appsite_ad_queue(appsiteid,adid,include)
select q.appsiteid,q.adid ,q.include from appsite_ad_queue q 
where q.modifiedon >= inLastRuntimeTargetingUpdateDate AND q.modifiedon <= inTillDate
and q.adid in (select adid from runtime_appsite_ad_queue)
and q.appsiteid not in (select r.appsiteid from runtime_appsite_ad_queue r where r.adid = q.adid)
and q.adid in (select id from ads where statusid = 10 and isdeleted = 0);

update runtime_appsite_ad_queue r
inner join appsite_ad_queue q on q.adid = r.adid and q.appsiteid = r.appsiteid
set  r.include = q.include;

delete from runtime_appsite_ad_queue
where 
adid not in (select adid from appsite_ad_queue)
or appsiteid not in (select appsiteid from appsite_ad_queue where adid = runtime_appsite_ad_queue.adid);

-- -------------------------
-- language targetings
-- -------------------------

insert into runtime_language_targetings(groupid,languageid)
select t.adgroupid,l.languageid from language_targetings l 
inner join targetings t on l.id = t.id
where l.modifiedon >= inLastRuntimeTargetingUpdateDate AND l.modifiedon <= inTillDate
and t.adgroupid in (select groupid from runtime_language_targetings)
and languageid not in (select languageid from runtime_language_targetings where groupid = t.adgroupid)
and t.adgroupid in (select adgroupid from ads where statusid = 10 and isdeleted = 0)
and t.isdeleted = 0;

delete from runtime_language_targetings
where 
groupid not in (select t.adgroupid from language_targetings l inner join targetings t on l.id = t.id where t.isdeleted = 0)
or languageid not in (select l.languageid from language_targetings l inner join targetings t on l.id = t.id where t.adgroupid = runtime_language_targetings.groupid and t.isdeleted = 0);

COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SegmentGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SegmentGetAll`()
BEGIN

SELECT a.Id, a.Type, a.ProviderId, a.AccountId, a.AdvertiserAccId, a.ParentId, a.SegmentCode, a.OperatorSegmentCode ProviderSegmentCode, a.Price, a.Activated, a.BinIndex, a.IsDeleted,
       b.Type ContextualType, b.SubType, b.TargetingIntent
FROM audience_segments a
LEFT JOIN contextual_segments b ON b.Id = a.Id; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Fill_Account_Kpis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SP_Fill_Account_Kpis`()
BEGIN

SET sql_safe_updates=0;



set @daymin:= date(date_sub(CURDATE(), interval 7 day )) +0,  @daymax:=date(date_sub(CURDATE(), interval 1 day )) +0, @DR_Default := 0.42, @CTR_Default := 0.0028, @CR_Default := 0.012;


update   adfalcon.account_kpis a,  (SELECT  case when sum(filledrequests) = 0 then @DR_Default     when sum(impressions) / sum(filledrequests) <= 0.0001 then @DR_Default     when sum(impressions) >= sum(filledrequests) then 1     else sum(impressions) / sum(filledrequests) end as dr, case when sum(impressions) = 0 then @CTR_Default     when sum(clicks) / sum(impressions) <= 0.0001 then @CTR_Default     when sum(clicks) >= sum(impressions) then 1     else sum(clicks) / sum(impressions) end as ctr, case when sum(clicks) = 0 then @CR_Default     when sum(conversions) / sum(clicks) <= 0.0001 then @CR_Default     when sum(conversions) >= sum(clicks) then 1     else sum(conversions) / sum(clicks) end as cr FROM adfalcon.adtypeperformance  where dayid between @daymin and @daymax) b set   a.DisplayRate = b.dr, a.CTR = b.ctr, a.ConversionRate = b.cr;


update adfalcon.account_kpis, ( SELECT      b.pubaccountid,      SUM(impressions) / SUM(filledrequests) as dr,     SUM(clicks) / SUM(impressions) as ctr,     SUM(conversions) / SUM(clicks) AS cr FROM     adfalcon.adtypeperformance a         LEFT JOIN     (SELECT 103424 AS pubaccountid UNION SELECT 72233 UNION SELECT 137966 UNION SELECT 137865 UNION SELECT 99384 UNION SELECT 151298 UNION SELECT 78284 UNION SELECT 73132 UNION SELECT 94334) b ON a.pubaccountid = b.pubaccountid WHERE dayid between @daymin and @daymax GROUP BY b.pubaccountid ) c  set      account_kpis.DisplayRate =  	CASE         WHEN c.dr is null then account_kpis.DisplayRate         WHEN c.dr <= 0.0001  then account_kpis.DisplayRate         WHEN c.dr >= 1 then 1         ELSE c.dr     END,  	account_kpis.CTR =  	CASE         WHEN c.ctr is null then account_kpis.CTR         WHEN c.ctr <= 0.0001  then account_kpis.CTR         WHEN c.ctr >= 1 then 1         ELSE c.ctr     END,  	account_kpis.ConversionRate =  	CASE         WHEN c.cr is null then account_kpis.ConversionRate         WHEN c.cr <= 0.0001  then account_kpis.ConversionRate         WHEN c.cr >= 1 then 1         ELSE c.cr     END where c.pubaccountid <=> account_kpis.AccountId ;


update adfalcon.account_kpis, (  SELECT      b.pubaccountid,      case when a.adtypegroupid = 101 then 4 when a.adtypegroupid = 2 then 3 when a.adtypegroupid = 3 then 2 else a.adtypegroupid end as adtype,     SUM(impressions) / SUM(filledrequests) as dr,     SUM(clicks) / SUM(impressions) as ctr,     SUM(conversions) / SUM(clicks) AS cr FROM     adfalcon.adtypeperformance a         LEFT JOIN     (SELECT 103424 AS pubaccountid UNION SELECT 72233 UNION SELECT 137966 UNION SELECT 137865 UNION SELECT 99384 UNION SELECT 151298 UNION SELECT 78284 UNION SELECT 73132 UNION SELECT 94334) b ON a.pubaccountid = b.pubaccountid WHERE  dayid between @daymin and @daymax GROUP BY b.pubaccountid, a.adtypegroupid) c SET      account_kpis.DisplayRate = CASE         WHEN c.dr IS NULL THEN account_kpis.DisplayRate         WHEN c.dr <= 0.0001 THEN account_kpis.DisplayRate         WHEN c.dr >= 1 THEN 1         ELSE c.dr     END,     account_kpis.CTR = CASE         WHEN c.ctr IS NULL THEN account_kpis.CTR         WHEN c.ctr <= 0.0001 THEN account_kpis.CTR         WHEN c.ctr >= 1 THEN 1         ELSE c.ctr     END,     account_kpis.ConversionRate = CASE         WHEN c.cr IS NULL THEN account_kpis.ConversionRate         WHEN c.cr <= 0.0001 THEN account_kpis.ConversionRate         WHEN c.cr >= 1 THEN 1         ELSE c.cr     END WHERE     c.pubaccountid <=> account_kpis.AccountId and AdTypeFormatId <=> c.adtype;

SET sql_safe_updates=1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_FundTransactionsVAT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_FundTransactionsVAT`(`AccountId` INT(11), `PageIndex` INT(11), `SizeTake` INT(11), FromDate DATETIME, ToDate DATETIME)
BEGIN

IF SizeTake > 0 THEN
				
			
					set @TotalCountall=(SELECT COUNT(*) FROM 
                
                (	
                
                
                SELECT  (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0  AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId) as f);
				
	
		SELECT	(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country,  @TotalCountall as  TotalCount, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0 AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId  LIMIT SizeTake  OFFSET PageIndex;
	
		ELSE
        
        
			SELECT	(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName, SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0  AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId;
		END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_FundTransactionsVATDetailed` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_FundTransactionsVATDetailed`(`AccountId` INT(11), `PageIndex` INT(11), `SizeTake` INT(11), FromDate DATETIME, ToDate DATETIME)
BEGIN

IF SizeTake > 0 THEN
				
			
					set @TotalCountall=(SELECT COUNT(*) FROM 
                
                (	
                
                
                SELECT  (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0  AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	) as f);
				
	
		SELECT	FSC.TransactionDate  As TransactionDate ,(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country,  @TotalCountall as  TotalCount, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0 AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	 LIMIT SizeTake  OFFSET PageIndex;
	
		ELSE
        
        
			SELECT	FSC.TransactionDate  As TransactionDate , (select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName, FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_fund_trans_history FSC

	WHERE FSC.StatusId=0  AND (FSC.account_fund_type_Id = 1 OR FSC.account_fund_type_Id=2 )  AND  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	;
		END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAccountTotalRevenue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAccountTotalRevenue`(IN `FromDate` datetime,IN `ToDate` datetime,IN `AccountId` int)
BEGIN

	



SELECT Sum(ap.Earning)

from accountsperformance ap

WHERE ap.AccountId = AccountId

AND (ap.Day BETWEEN  DATE_FORMAT(FromDate, '%Y%m%d') AND  DATE_FORMAT(ToDate, '%Y%m%d')) ;

  

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAccountTotalSpend` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAccountTotalSpend`(IN `FromDate` datetime,IN `ToDate` datetime,IN `AccountId` int)
BEGIN

	



SELECT Sum(ap.Spend)

from accountsperformance ap

WHERE ap.AccountId = AccountId

AND (ap.Day BETWEEN  DATE_FORMAT(FromDate, '%Y%m%d') AND  DATE_FORMAT(ToDate, '%Y%m%d')) ;

  

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdsAllByAccountAdvID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdsAllByAccountAdvID`(IN `AdvIDs` varchar(10000))
BEGIN
	DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = AdvIDs;
	SET vSeparator = ',';
	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;
SELECT     adgroups.CampaignId, adgroups.Id AS AdgroupId, ads.Id AS AdId, camp.AdvertiserId AS AdvertiserId, ads.StatusId
FROM       adgroups INNER JOIN
           ads ON adgroups.Id = ads.AdGroupId
            INNER JOIN   campaigns camp
            ON adgroups.CampaignId = camp.Id 
           
where ads.IsDeleted=0 AND exists (  select advAcc.Id from  tmpIDList inner join  advertiser_account advAcc on tmpIDList.ID= advAcc.Id where  advAcc.AdvertiserId = camp.AdvertiserId and advAcc.AccountId= camp.AccountId  )
Order BY adgroups.CampaignId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdsAllByAdGroupID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdsAllByAdGroupID`(IN `AdGroupIDs` varchar(1000))
BEGIN
	DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = AdGroupIDs;
	SET vSeparator = ',';
	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;

SELECT     adgroups.CampaignId, adgroups.Id AS AdgroupId, ads.Id AS AdId, ads.StatusId
FROM       adgroups INNER JOIN
           ads ON adgroups.Id = ads.AdGroupId
             INNER JOIN tmpIDList ON tmpIDList.ID = adgroups.Id
where ads.IsDeleted=0
Order BY adgroups.CampaignId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdsAllByCampaignID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdsAllByCampaignID`(IN `CampaignIDs` varchar(1000))
BEGIN
	DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = CampaignIDs;
	SET vSeparator = ',';
	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;
SELECT     adgroups.CampaignId, adgroups.Id AS AdgroupId, ads.Id AS AdId, ads.StatusId
FROM       adgroups INNER JOIN
           ads ON adgroups.Id = ads.AdGroupId
             INNER JOIN tmpIDList ON tmpIDList.ID = adgroups.CampaignId
where ads.IsDeleted=0
Order BY adgroups.CampaignId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdvertiserAccountTotalSpend` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdvertiserAccountTotalSpend`(IN `FromDate` datetime,IN `ToDate` datetime,IN `AdvertiserAssociationId` int)
BEGIN

	



SELECT Sum(ap.BillableCost)

from advertisersperformance ap

WHERE ap.AdvertiserAssociationId = AdvertiserAssociationId

AND (ap.Day BETWEEN  DATE_FORMAT(FromDate, '%Y%m%d') AND  DATE_FORMAT(ToDate, '%Y%m%d')) ;

  

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdvertiserAllStatByAdvertiserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdvertiserAllStatByAdvertiserID`(IN `AdvertiserIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN
	
	DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = AdvertiserIDs;
	SET vSeparator = ',';


	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;

		
		SELECT  AdvertiserAssociationId as DimAdvID,
					CAST(SUM(Impressions) AS SIGNED) AS Impress,
					CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                    
		                                  SUM(Clicks)/SUM(Impressions)  AS CTR,
                                                              (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,                                          (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
	FROM advertisersperformance FSC
	
	WHERE FSC.AdvertiserAssociationId IN (SELECT ID FROM tmpIDList)
	AND  ((FromDate IS NULL AND ToDate IS NULL) OR (FSC.Day BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))
	GROUP BY DimAdvID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAdvertiserStatByAdvertiserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAdvertiserStatByAdvertiserID`(IN `AdvertiserIDs` varchar(10000))
BEGIN
	
	DECLARE vString VARCHAR(10000);
	DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);

	SET vString = AdvertiserIDs;
	SET vSeparator = ',';
	
	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;
	
		SELECT  AdvertiserAssociationId as DimAdvID,
					CAST(SUM(Impressions) AS SIGNED) AS Impress,
					CAST(SUM(Clicks) AS SIGNED) AS Clicks,
					SUM(Clicks)/SUM(Impressions) AS CTR,
                     (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
	FROM advertisersperformance FSC
	INNER JOIN tmpIDList ON tmpIDList.ID = FSC.AdvertiserAssociationId
	GROUP BY DimAdvID;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAppAllStatByIds` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAppAllStatByIds`(IN `AppSiteIds` varchar(1000),IN `CampaignType` int,IN `OtherCampaignType` int,IN `DateFrom` DateTime,IN `DateTo` DateTime)
BEGIN
	DECLARE vString VARCHAR(8000);
	DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = AppSiteIds;
	SET vSeparator = ',';
	
	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;
	SELECT AppSiteID,
				 CAST(SUM(Requests) AS SIGNED) AS AdRequests,
				 CAST(SUM(Impressions) AS SIGNED) AS AdImpress,
				 SUM(NetCost)  AS Revenue,
				 CAST(SUM(Clicks) AS SIGNED) AS AdClicks,
				 SUM(Impressions)/SUM(Requests) AS FillRate,
				 SUM(Clicks)/SUM(Impressions)  AS CTR,
				 ((SUM(NetCost)/SUM(Impressions)) * 1000)  AS eCPM
	FROM appsitesperformance FSA
	INNER JOIN tmpIDList ON tmpIDList.ID = FSA.AppSiteID
	Where FSA.CampaignType=CampaignType OR FSA.CampaignType=OtherCampaignType
    AND ((DateFrom IS NULL AND DateTo IS NULL) OR (FSA.Day BETWEEN DATE_FORMAT(DateFrom, '%Y%m%d') AND DATE_FORMAT(DateTo, '%Y%m%d')))
	GROUP BY AppSiteID
	ORDER BY NULL;
	DROP TABLE tmpIDList;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAppStatPerformanceCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAppStatPerformanceCount`(AccountID INT(11), IN `FromDate` datetime,IN `ToDate` datetime)
BEGIN

	

SELECT COUNT(*) AS Counts 
	FROM (  
            SELECT AppSiteID
            FROM fact_stat_app FSA										
            WHERE AppAccountID = AccountID
            AND (DimDateID BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d'))
            GROUP BY AppSiteID
        ) AS T1;

		  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetAudienceAllStatByAdvertiserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetAudienceAllStatByAdvertiserID`(IN `AudienceListIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN
	
	DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
	DECLARE vDone tinyint(1) DEFAULT 1;
	DECLARE vIndex INT DEFAULT 1;
	DECLARE vSubString VARCHAR(15);
	SET vString = AudienceListIDs;
	SET vSeparator = ',';


	DROP TABLE IF EXISTS tmpIDList;
	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
	WHILE vDone > 0 DO
		SET vSubString = SUBSTRING(vString, vIndex,
											IF(LOCATE(vSeparator, vString, vIndex) > 0,
												LOCATE(vSeparator, vString, vIndex) - vIndex,
												LENGTH(vString)
											));
		IF LENGTH(vSubString) > 0 THEN
				SET vIndex = vIndex + LENGTH(vSubString) + 1;
				INSERT INTO tmpIDList VALUES (vSubString);
		ELSE
				SET vDone = 0;
		END IF;
	END WHILE;

	
		SELECT  FSC.AudienceSegmentId as Id,
					CAST(Hits AS SIGNED) AS NoOfHits,
					CAST(unique_users AS SIGNED) AS UniqueUsers
				
                           
                       
	FROM audience_segments_performance FSC
	inner join audience_segments_unique_users FSC2 
	on FSC.audiencesegmentid=FSC2.AudienceSegmentId
	WHERE FSC.AudienceSegmentId IN (SELECT ID FROM tmpIDList)
	AND  ((FromDate IS NULL AND ToDate IS NULL) OR (FSC.Day BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))
	GROUP BY FSC.AudienceSegmentId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignAdsGroupsStatByIDs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignAdsGroupsStatByIDs`(IN `AdsGroupIDs` varchar(1000))
BEGIN
                                
                                
                DECLARE vString VARCHAR(8000);
                DECLARE vSeparator VARCHAR(5);
                DECLARE vDone tinyint(1) DEFAULT 1;
                DECLARE vIndex INT DEFAULT 1;
                DECLARE vSubString VARCHAR(15);

                SET vString = AdsGroupIDs;
                SET vSeparator = ',';
                
                DROP TABLE IF EXISTS tmpIDList;
                CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;

                WHILE vDone > 0 DO
                                SET vSubString = SUBSTRING(vString, vIndex,
                                                                                                                                                                                IF(LOCATE(vSeparator, vString, vIndex) > 0,
                                                                                                                                                                                                LOCATE(vSeparator, vString, vIndex) - vIndex,
                                                                                                                                                                                                LENGTH(vString)
                                                                                                                                                                                ));

                                IF LENGTH(vSubString) > 0 THEN
                                                                SET vIndex = vIndex + LENGTH(vSubString) + 1;
                                                                INSERT INTO tmpIDList VALUES (vSubString);
                                ELSE
                                                                SET vDone = 0;
                                END IF;
                END WHILE;
                
                  
                SELECT  AdGroupID as AdsGroupID,
                                                                                CAST(SUM(Impressions) AS SIGNED) AS Impress,
                                                                                CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                                                                                SUM(Clicks)/SUM(Impressions)  AS CTR,
       (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
                FROM adgroupsperformance FSC
                INNER JOIN tmpIDList ON tmpIDList.ID = FSC.AdGroupID
                GROUP BY AdsGroupID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignAllStatByAdsGroupID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignAllStatByAdsGroupID`(IN `AdsGroupIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN

                                
                DECLARE vString VARCHAR(8000);
                DECLARE vSeparator VARCHAR(5);
                DECLARE vDone tinyint(1) DEFAULT 1;
                DECLARE vIndex INT DEFAULT 1;
                DECLARE vSubString VARCHAR(15);
                
                SET vString = AdsGroupIDs;
                SET vSeparator = ',';
                DROP TABLE IF EXISTS tmpIDList;
                CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
                WHILE vDone > 0 DO
                                SET vSubString = SUBSTRING(vString, vIndex,
                                                                                                                                                                                IF(LOCATE(vSeparator, vString, vIndex) > 0,
                                                                                                                                                                                                LOCATE(vSeparator, vString, vIndex) - vIndex,
                                                                                                                                                                                                LENGTH(vString)
                                                                                                                                                                                ));
                                IF LENGTH(vSubString) > 0 THEN
                                                                SET vIndex = vIndex + LENGTH(vSubString) + 1;
                                                                INSERT INTO tmpIDList VALUES (vSubString);
                                ELSE
                                                                SET vDone = 0;
                                END IF;
                END WHILE;
   
SELECT  AdGroupID as AdsGroupID,
                                                                                CAST(SUM(Impressions) AS SIGNED) AS Impress,
                                                                                CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                                                                                SUM(Clicks)/SUM(Impressions)  AS CTR,
                                                                                                                             (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
                FROM adgroupsperformance FSC
                
                WHERE FSC.AdGroupID IN (SELECT ID FROM tmpIDList)
                AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.Day BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

                GROUP BY AdsGroupID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignAllStatByAdsID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignAllStatByAdsID`(IN `AdsIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN
                
                DECLARE vString VARCHAR(8000);
                DECLARE vSeparator VARCHAR(5);
                DECLARE vDone tinyint(1) DEFAULT 1;
                DECLARE vIndex INT DEFAULT 1;
                DECLARE vSubString VARCHAR(15);

                SET vString = AdsIDs;
                SET vSeparator = ',';
                DROP TABLE IF EXISTS tmpIDList;
                CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
                WHILE vDone > 0 DO
                                SET vSubString = SUBSTRING(vString, vIndex,
                                                                                                                                                                                IF(LOCATE(vSeparator, vString, vIndex) > 0,
                                                                                                                                                                                                LOCATE(vSeparator, vString, vIndex) - vIndex,
                                                                                                                                                                                                LENGTH(vString)
                                                                                                                                                                                ));
                                IF LENGTH(vSubString) > 0 THEN
                                                                SET vIndex = vIndex + LENGTH(vSubString) + 1;
                                                                INSERT INTO tmpIDList VALUES (vSubString);
                                ELSE
                                                                SET vDone = 0;
                                END IF;
                END WHILE;
                   
                SELECT  AdID as AdsID,
                                                                                CAST(SUM(Impressions) AS SIGNED) AS Impress,
                                                                                CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                                                                                SUM(Clicks)/SUM(Impressions)  AS CTR,
                                                                                                       (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
                            
                FROM adsperformance FSC
                
                WHERE FSC.AdID IN (SELECT ID FROM tmpIDList)
                AND ((FromDate IS NULL AND ToDate IS NULL) OR (FSC.Day BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))
                GROUP BY AdsID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignAllStatByAdsID_Temp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignAllStatByAdsID_Temp`(IN `AdsIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN

	



	DECLARE vString VARCHAR(8000);

  DECLARE vSeparator VARCHAR(5);

	DECLARE vDone tinyint(1) DEFAULT 1;

	DECLARE vIndex INT DEFAULT 1;

	DECLARE vSubString VARCHAR(15);



	SET vString = AdsIDs;

	SET vSeparator = ',';

	 

	DROP TABLE IF EXISTS tmpIDList;

	CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;

	 

	WHILE vDone > 0 DO

		SET vSubString = SUBSTRING(vString, vIndex,

											IF(LOCATE(vSeparator, vString, vIndex) > 0,

												LOCATE(vSeparator, vString, vIndex) - vIndex,

												LENGTH(vString)

											));

		IF LENGTH(vSubString) > 0 THEN

				SET vIndex = vIndex + LENGTH(vSubString) + 1;

				INSERT INTO tmpIDList VALUES (vSubString);

		ELSE

				SET vDone = 0;

		END IF;

	END WHILE;

	

	 

	

	SELECT  AdsID,

					CAST(SUM(Impression) AS SIGNED) AS Impress,

					CAST(SUM(Clicks) AS SIGNED) AS Clicks,

					SUM(Clicks)/SUM(Impression) AS CTR,

					SUM(AdsSpend)/SUM(Clicks)  AS AvgCPC,

					SUM(AdsSpend)  AS Spend

	FROM fact_stat_campaign FSC

	INNER JOIN tmpIDList ON tmpIDList.ID = FSC.AdsID

	WHERE  ((FromDate IS NULL AND ToDate IS NULL) OR (DimDateID BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	GROUP BY AdsID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignAllStatByCampaignID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignAllStatByCampaignID`(IN `CampaignIDs` varchar(1000), FromDate DATETIME, ToDate DATETIME)
BEGIN
                
                DECLARE vString VARCHAR(8000);
  DECLARE vSeparator VARCHAR(5);
                DECLARE vDone tinyint(1) DEFAULT 1;
                DECLARE vIndex INT DEFAULT 1;
                DECLARE vSubString VARCHAR(15);
                SET vString = CampaignIDs;
                SET vSeparator = ',';


                DROP TABLE IF EXISTS tmpIDList;
                CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
                WHILE vDone > 0 DO
                                SET vSubString = SUBSTRING(vString, vIndex,
                                                                                                                                                                                IF(LOCATE(vSeparator, vString, vIndex) > 0,
                                                                                                                                                                                                LOCATE(vSeparator, vString, vIndex) - vIndex,
                                                                                                                                                                                                LENGTH(vString)
                                                                                                                                                                                ));
                                IF LENGTH(vSubString) > 0 THEN
                                                                SET vIndex = vIndex + LENGTH(vSubString) + 1;
                                                                INSERT INTO tmpIDList VALUES (vSubString);
                                ELSE
                                                                SET vDone = 0;
                                END IF;
                END WHILE;

        
                                SELECT  CampaignID as DimCampaignID,
                                                                                CAST(SUM(Impressions) AS SIGNED) AS Impress,
                                                                                CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                                                                  SUM(Clicks)/SUM(Impressions) AS CTR,
                                                                              (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
                            
                FROM campaignsperformance FSC
                WHERE FSC.CampaignID IN (SELECT ID FROM tmpIDList)
                AND  ((FromDate IS NULL AND ToDate IS NULL) OR (FSC.Day BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))
                GROUP BY DimCampaignID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetCampaignStatByCampaignID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_GetCampaignStatByCampaignID`(IN `CampaignIDs` varchar(10000))
BEGIN
                
                DECLARE vString VARCHAR(10000);
                DECLARE vSeparator VARCHAR(5);
                DECLARE vDone tinyint(1) DEFAULT 1;
                DECLARE vIndex INT DEFAULT 1;
                DECLARE vSubString VARCHAR(15);

                SET vString = CampaignIDs;
                SET vSeparator = ',';
                
                DROP TABLE IF EXISTS tmpIDList;
                CREATE TEMPORARY TABLE tmpIDList (ID INT PRIMARY KEY) ENGINE=MEMORY;
                WHILE vDone > 0 DO
                                SET vSubString = SUBSTRING(vString, vIndex,
                                                                                                                                                                                IF(LOCATE(vSeparator, vString, vIndex) > 0,
                                                                                                                                                                                                LOCATE(vSeparator, vString, vIndex) - vIndex,
                                                                                                                                                                                                LENGTH(vString)
                                                                                                                                                                                ));
                                IF LENGTH(vSubString) > 0 THEN
                                                                SET vIndex = vIndex + LENGTH(vSubString) + 1;
                                                                INSERT INTO tmpIDList VALUES (vSubString);
                                ELSE
                                                                SET vDone = 0;
                                END IF;
                END WHILE;
                
                       SELECT  CampaignID as DimCampaignID,
                                                                                CAST(SUM(Impressions) AS SIGNED) AS Impress,
                                                                                CAST(SUM(Clicks) AS SIGNED) AS Clicks,
                                                                                SUM(Clicks)/SUM(Impressions) AS CTR,
                                                                                                  (Sum(BillableCost))/SUM(Clicks) AS AvgCPC,
					(Sum(BillableCost)) AS BillableCost,
                    (Sum(NetCost)) AS NetCost,
                     (Sum(GrossCost)) AS GrossCost,
                                         (Sum(PlatformFee)) AS PlatformFee,
                     (Sum(AdjustedNetCost)) AS AdjustedNetCost,
                         (Sum(ThirdPartyFee)) AS ThirdPartyFee,
                            (Sum(dataFee)) AS DataFee
                FROM campaignsperformance FSC
                INNER JOIN tmpIDList ON tmpIDList.ID = FSC.CampaignID
                GROUP BY DimCampaignID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_manage_ads_working_hours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_manage_ads_working_hours`()
BEGIN

DECLARE crnt_time datetime;

DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN END;
    


SET crnt_time = NOW();
SELECT DAYOFWEEK(crnt_time);
SELECT HOUR(crnt_time);





IF DAYOFWEEK(crnt_time) <> 6 AND (HOUR(crnt_time) = 3 OR HOUR(crnt_time) = 4) THEN

UPDATE ads
SET StatusId = PausedStatusId , PausedStatusId=null
WHERE (id in (30704)) AND StatusId = 6;

END IF;


IF HOUR(crnt_time) = 13 OR HOUR(crnt_time) = 12 OR HOUR(crnt_time) = 14 OR HOUR(crnt_time) = 15 THEN


UPDATE ads
SET PausedStatusId = StatusId, StatusId=6
WHERE (id in (30704)) AND StatusId <> 6;

END IF;



IF (HOUR(crnt_time) = 5 OR HOUR(crnt_time) = 6 OR HOUR(crnt_time) = 14 OR HOUR(crnt_time) = 15) THEN

UPDATE ads
SET StatusId = PausedStatusId , PausedStatusId=null
WHERE (id in (33141, 33240, 33239)) AND StatusId = 6;

END IF;


IF HOUR(crnt_time) = 11 OR HOUR(crnt_time) = 12 OR HOUR(crnt_time) = 22 OR HOUR(crnt_time) = 23 THEN


UPDATE ads
SET PausedStatusId = StatusId, StatusId=6
WHERE (id in (33141, 33240, 33239)) AND StatusId <> 6;

END IF;



IF (HOUR(crnt_time) = 4 OR HOUR(crnt_time) = 5) THEN

UPDATE ads
SET StatusId = PausedStatusId , PausedStatusId=null
WHERE (id in (34542,34545, 34544)) AND StatusId = 6;

END IF;



IF HOUR(crnt_time) = 16 OR HOUR(crnt_time) = 17 THEN


UPDATE ads
SET PausedStatusId = StatusId, StatusId=6
WHERE (id in (34542,34545, 34544)) AND StatusId <> 6;

END IF;






END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_PaymentTransactionsVAT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_PaymentTransactionsVAT`(`AccountId` INT(11), `PageIndex` INT(11), `SizeTake` INT(11), FromDate DATETIME, ToDate DATETIME)
BEGIN

IF SizeTake > 0 THEN
				
			
					set @TotalCountall=(SELECT COUNT(*) FROM 
                
                (	
                
                
                SELECT  (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_payment_trans_history FSC

	WHERE  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId) as f);
				
	
		SELECT	(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country,  @TotalCountall as  TotalCount, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_payment_trans_history FSC

	WHERE  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId  LIMIT SizeTake  OFFSET PageIndex;
	
		ELSE
        
        
			SELECT	(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName, SUM(FSC.Amount) As Amount , Sum(FSC.VATAmount) as VATAmount FROM account_payment_trans_history FSC

	WHERE  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	group by FSC.AccountId;
		END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_PaymentTransactionsVATDetailed` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `sp_PaymentTransactionsVATDetailed`(`AccountId` INT(11), `PageIndex` INT(11), `SizeTake` INT(11), FromDate DATETIME, ToDate DATETIME)
BEGIN

IF SizeTake > 0 THEN
				
			
					set @TotalCountall=(SELECT COUNT(*) FROM 
                
                (	
                
                
                SELECT  (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_payment_trans_history FSC

	WHERE ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	) as f);
				
	
		SELECT	FSC.TransactionDate  As TransactionDate ,(select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country,  @TotalCountall as  TotalCount, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName,  FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_payment_trans_history FSC

	WHERE  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	 LIMIT SizeTake  OFFSET PageIndex;
	
		ELSE
        
        
			SELECT	FSC.TransactionDate  As TransactionDate , (select  locString.Value from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id   INNER JOIN locations loc on loc.id=usr.CountryId inner Join localizedstrings locString on loc.NameId=locString.LocalizedStringID  where loc.LocationType=2 and locString.Culture='en-US'  and  FSC.accountid=acc.id ) As Country, (select CONCAT(usr.FirstName ,' ' , usr.LastName) from  account acc  inner join users usr on acc.PrimaryUserId=usr.Id where  FSC.accountid=acc.id ) as AccountName, FSC.Amount As Amount , FSC.VATAmount as VATAmount FROM account_payment_trans_history FSC

	WHERE  ((FSC.AccountId = AccountId) OR (AccountId IS NULL))
	AND((FromDate IS NULL AND ToDate IS NULL) OR (FSC.TransactionDate BETWEEN DATE_FORMAT(FromDate, '%Y%m%d') AND DATE_FORMAT(ToDate, '%Y%m%d')))

	;
		END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Update_WinRateThreshold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SP_Update_WinRateThreshold`()
BEGIN
set @targetdate := date(date_sub(CURDATE(), interval 7 day )) +0;
set @updateID := (select group_concat(id) FROM adfalcon.configurationsettings where adfalcon.configurationsettings.key = 'DynamicBidding_WinRateThreshold');
set @defaultThreashold := 0.3;
update adfalcon.configurationsettings set configurationsettings.Value = (SELECT @WR :=
case 
when sum(filledrequests) = 0 then  @defaultThreashold
when sum(wins) >= sum(filledrequests) then 1
when sum(wins) / sum(filledrequests) <= 0.0001 then @defaultThreashold
else sum(wins) / sum(filledrequests)
end as WR
FROM adfalcon.adtypeperformance where dayid >= @targetdate)
where configurationsettings.id in (@updateID);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerContentCategoriesGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerContentCategoriesGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, Code, MappedIABContentCategoryId FROM ssp_partner_content_categories WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerCreativeAttributesGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerCreativeAttributesGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, Code, MappedCreativeAttributeId FROM ssp_partner_creative_attributes WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerCreativeUnitsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerCreativeUnitsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, Code, Width, Height FROM ssp_partner_creativeunits WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerCreativeVendorsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerCreativeVendorsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, Codes, MappedCreativeVendorId, IsCertified, IsDeclarable FROM ssp_partner_creative_vendors WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerDataSegmentGetMappedAudienceSegments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerDataSegmentGetMappedAudienceSegments`(IN inSSPPartnerDataSegmentId INT)
BEGIN

SELECT AudienceSegmentId FROM ssp_partner_data_segments_mapping WHERE SSPPartnerDataSegmentId = inSSPPartnerDataSegmentId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerDataSegmentsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerDataSegmentsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT Id, PartnerId, Code, MinAcceptableWeight FROM ssp_partner_data_segments WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerGetAll`()
BEGIN

Select A.Id FROM ssp_partners A 
INNER JOIN business_partners B ON A.Id = B.Id
INNER JOIN party C ON B.Id = C.Id
WHERE C.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerMobileOperatorsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerMobileOperatorsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, Code, MappedOperatorId FROM ssp_partner_mobile_operators WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerSupportedCreativeFormatsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerSupportedCreativeFormatsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT EnvironmentType, CreativeFormatId FROM ssp_partner_supported_creative_formats WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerWhiteListIPsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerWhiteListIPsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT PartnerId, IP FROM ssp_partner_whitelist_ips WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SSPPartnerWhitelistOrgISPsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SSPPartnerWhitelistOrgISPsGet`(IN inSSPPartnerId INT)
BEGIN

SELECT Organization, ISP FROM ssp_partner_whitelist_org_isps WHERE PartnerId = inSSPPartnerId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubAppsiteGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SubAppsiteGetAll`()
BEGIN

select Id, SubPublisherId, SubPublisherName, SubPublisherUrl, SubPublisherMarketId, SubPublisherPartnerId, AppsiteId FROM sub_appsites;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubAppSiteGetByIds` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SubAppSiteGetByIds`(IN inSubAppSiteIds text)
BEGIN

set @sql = concat("select Id, SubPublisherId, SubPublisherName, SubPublisherUrl, SubPublisherMarketId, SubPublisherPartnerId, AppsiteId FROM sub_appsites where Id in (", inSubAppSiteIds , ");");
prepare stmt from @sql;
execute stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubAppSiteInsertOrUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SubAppSiteInsertOrUpdate`(in inAppsiteId int, in inSubPublisherId varchar(1000), in inSubPublisherName varchar(5000) CHARACTER SET utf8mb4, 
																		   in inSubPublisherUrl varchar(5000), in inSubPublisherMarketId varchar(5000), in inSubPublisherPartnerId varchar(1000), in inKeywordIds varchar(5000),
                                                                           out outId int)
BEGIN

INSERT INTO sub_appsites (SubPublisherId, SubPublisherName, SubPublisherUrl, SubPublisherMarketId, SubPublisherPartnerId, AppsiteId) 
VALUES (inSubPublisherId, inSubPublisherName, inSubPublisherUrl, inSubPublisherMarketId, inSubPublisherPartnerId, inAppsiteId)
ON DUPLICATE KEY UPDATE Id = LAST_INSERT_ID(Id), AppsiteId = inAppsiteId, SubPublisherId = inSubPublisherId, SubPublisherName = inSubPublisherName,
                        SubPublisherUrl = inSubPublisherUrl, SubPublisherMarketId = inSubPublisherMarketId, SubPublisherPartnerId = inSubPublisherPartnerId;

Set outId = LAST_INSERT_ID();


IF inKeywordIds IS NOT NULL AND inKeywordIds != '' THEN

set @sql = concat("insert into sub_appsite_keywords (SubAppSiteId, KeywordId) values (", outId, ",", replace(inKeywordIds, ",", concat("),(", outId, ",")),") on duplicate key update SubAppSiteId = " , outId, ";");
prepare stmt from @sql;
execute stmt;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubAppSiteKeywordGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SubAppSiteKeywordGetAll`()
BEGIN

select Id, SubAppSiteId, KeywordId FROM sub_appsite_keywords WHERE IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubAppSiteKeywordGetBySubAppSiteIds` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SubAppSiteKeywordGetBySubAppSiteIds`(IN inSubAppSiteIds text)
BEGIN

set @sql = concat("select Id, SubAppSiteId, KeywordId FROM sub_appsite_keywords where SubAppSiteId in (", inSubAppSiteIds , ") and IsDeleted = 0;");
prepare stmt from @sql;
execute stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SupportedAdTypesGetByCreativeUnitId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `SupportedAdTypesGetByCreativeUnitId`(IN inCreativeUnitId INT)
BEGIN

SELECT DISTINCT T.Id, LS.Value Name, T.Code 
FROM ad_supported_creativeunits ASCU 
INNER JOIN adtypes T ON ASCU.AdTypeId = T.Id
INNER JOIN localizedstrings LS ON T.NameId = LS.LocalizedStringID
WHERE ASCU.CreativeUnitId = inCreativeUnitId AND LS.Culture = 'en-US';

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `test01`(IN id int)
BEGIN

select * from keywords;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestNativeAdGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestNativeAdGetAll`()
BEGIN

Select Id, ActionTypeId, AdTitle, Description, AppOpenUrl, StarRating, ActionText, ShowIfInstalled
FROM test_native_ads;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestNativeAdIconGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestNativeAdIconGetByAdId`(IN inTestNativeAdId INT)
BEGIN

SELECT CreativeUnitId, MIMETypeId, Url FROM test_native_ad_icons WHERE TestNativeAdId = inTestNativeAdId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestNativeAdImageGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestNativeAdImageGetByAdId`(IN inTestNativeAdId INT)
BEGIN

SELECT CreativeUnitId, MIMETypeId, Url FROM test_native_ad_images WHERE TestNativeAdId = inTestNativeAdId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestRichMediaAdGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestRichMediaAdGetAll`()
BEGIN

SELECT AdSubTypeId, CreativeUnitId, EnvironmentTypeId, OrientationTypeId, MraidProtocol, Content FROM test_richmedia_ads;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestTextBannerPlainHtmlAdGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestTextBannerPlainHtmlAdGetAll`()
BEGIN

SELECT AdTypeId, CreativeUnitId, Content FROM test_text_banner_plainhtml_ads;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TestVideoAdGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TestVideoAdGetAll`()
BEGIN

SELECT AdTitle, Description, DurationInSeconds, VideoTypeId, DeliveryMethodId, BitRate, Width, Height, Url FROM test_video_ads;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TextAdThemeGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TextAdThemeGetById`(in id int)
BEGIN

Select TAT.TextAdThemeId Id, LS.Value Name, TAT.TextColor, TAT.BackgroundColor, TAT.AdFalconTextColor, TAT.IsCustom from textadthemes TAT 
left Join localizedstrings LS On TAT.NameId = LS.LocalizedStringID
WHERE TAT.TextAdThemeId = id AND (LS.Culture = 'en-US' OR LS.Culture IS NULL);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TextFilterGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TextFilterGetByAppsiteId`(IN inAppsiteId int)
BEGIN

SELECT Id, Text, MatchTypeId
FROM textfilters
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TileImageGetAllDefault` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TileImageGetAllDefault`()
BEGIN
Select TI.Id,LS.Value Name,TI.IsCustom,TI.IsClickAction from tileimages TI
Inner Join localizedstrings LS On TI.NameId = LS.LocalizedStringID
Where TI.IsCustom = 0 AND LS.Culture = 'en-US';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TileImageGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TileImageGetById`(IN id Int)
BEGIN
Select TI.Id,LS.Value Name,TI.IsCustom,TI.IsClickAction from tileimages TI
Left Join localizedstrings LS On TI.NameId = LS.LocalizedStringID
Where TI.Id = id AND (LS.Culture IS NULL OR LS.Culture = 'en-US');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TileImageSizeDocumentGetById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TileImageSizeDocumentGetById`(IN id Int)
BEGIN
Select TISD.Id, TISD.TileImageId, TISD.TileImageSizeId, TISD.DocumentId, TISD.URL from tileimagesizedocuments TISD
Where TISD.Id = id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TileImageSizeDocumentGetByTileImageId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TileImageSizeDocumentGetByTileImageId`(IN tileImageId Int)
BEGIN
Select TISD.Id, TISD.TileImageId, TISD.TileImageSizeId, TISD.DocumentId, TISD.URL from tileimagesizedocuments TISD
Where TISD.TileImageId = tileImageId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TileImageSizeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `TileImageSizeGetAll`()
BEGIN

Select TI.Id, TI.Width, TI.Height, TI.DeviceTypeId from tileimagesizes TI 
Where TI.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateAdGroupBidConfig` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UpdateAdGroupBidConfig`(IN inAdGroupId INT, IN inAppSiteId INT, IN inBid DECIMAL(21,12))
BEGIN

SET @HasConfiguredBid = EXISTS (SELECT 1 from adgroup_bid_config where AdGroupId = inAdGroupId and AppSiteId = inAppSiteId);

IF NOT @HasConfiguredBid THEN

insert into adgroup_bid_config (`AdGroupId`,`AccountId`,`AppsiteId`,`Bid`) values (inAdGroupId, (select AccountId from appsite where id = inAppSiteId), inAppSiteId, inBid);

ELSE

update adgroup_bid_config set Bid = inBid where AdGroupId = inAdGroupId and AppSiteId = inAppSiteId;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateCampaignBidConfig` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UpdateCampaignBidConfig`(IN inCampaignId INT, IN inAppSiteId INT, IN inBid DECIMAL(21,12))
BEGIN

SET @HasConfiguredBid = EXISTS (SELECT 1 from campaign_bid_config where CampaignId = inCampaignId and AppSiteId = inAppSiteId);

IF NOT @HasConfiguredBid THEN

insert into campaign_bid_config (`CampaignId`,`AccountId`,`AppsiteId`,`Bid`) values (inCampaignId, (select AccountId from appsite where id = inAppSiteId), inAppSiteId, inBid);

ELSE

update campaign_bid_config set Bid = inBid where CampaignId = inCampaignId and AppSiteId = inAppSiteId;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateDeltaStatSummary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UpdateDeltaStatSummary`()
BEGIN
	INSERT INTO delta_stat_summary (DateId, AdId, Demand_MappingId, Requests, Impressions, Spend, AppSiteRevenue, AdFalconRevenue)
    SELECT 
		day, adid, demandmappingid, ifnull(requests,0), ifnull(impressions, 0), ifnull(spend, 0), ifnull(appsiterevenue, 0), ifnull(adfalconrevenue, 0)
    FROM 
		hdp_delta_stat_summary
    ON DUPLICATE KEY UPDATE 
		delta_stat_summary.Requests = delta_stat_summary.Requests + values(Requests),
		delta_stat_summary.Impressions = delta_stat_summary.Impressions + values(Impressions),
		delta_stat_summary.Spend = delta_stat_summary.Spend + values(Spend),
		delta_stat_summary.AppSiteRevenue = delta_stat_summary.AppSiteRevenue + values(AppSiteRevenue),
		delta_stat_summary.AdFalconRevenue = delta_stat_summary.AdFalconRevenue + values(AdFalconRevenue)
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateEventStat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UpdateEventStat`(in inEventId int, in inInstanceId varchar(50))
BEGIN

INSERT INTO events_stat (EventId,InstanceId,NumberOfRaises,LastRaiseDate) VALUES (inEventId, inInstanceId, 1, Now())
ON DUPLICATE KEY UPDATE NumberOfRaises = NumberOfRaises + 1,LastRaiseDate = Now();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UrlFilterGetByAppsiteId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UrlFilterGetByAppsiteId`(IN inAppsiteId int)
BEGIN

SELECT Url
FROM urlfilters
WHERE AppsiteId = inAppsiteId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UserAgentGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UserAgentGetAll`()
BEGIN

select Id, MD5Key FROM useragents;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UserAgentGetAllByPageIndex` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UserAgentGetAllByPageIndex`(IN inPageIndex int, IN inPageSize int)
BEGIN

SELECT Id, MD5Key FROM useragents limit inPageIndex, inPageSize;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UserAgentInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `UserAgentInsert`(inMD5Key nvarchar(32), in inName nvarchar(5000), out outId int)
BEGIN

INSERT INTO useragents (MD5Key,Name) 
VALUES (inMD5Key,inName)
ON DUPLICATE KEY UPDATE Id = LAST_INSERT_ID(Id), MD5Key = inMD5Key, Name = inName;

Set outId = LAST_INSERT_ID();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoAdMediaFileGetByAdCreativeUnitId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoAdMediaFileGetByAdCreativeUnitId`(IN inVideoAdCreativeUnitId INT)
BEGIN

SELECT Id, MIMETypeId, DeliveryMethodId, CreativeUnitId, BitRate, Url FROM video_ad_media_files WHERE VideoAdCreativeUnitId = inVideoAdCreativeUnitId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoAdMediaFileSizeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoAdMediaFileSizeGetAll`()
BEGIN

SELECT a.Id, a.Width, a.Height, a.Code, b.Priority 
FROM creativeunits a
inner join creativeunit_groups_mapping b on a.Id = b.CreativeUnitId
inner join creativeunit_groups c on b.GroupId = c.Id
where c.Code = 12; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoAdThirdPartyOMVerificationsGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoAdThirdPartyOMVerificationsGetByAdId`(IN inVideoAdId INT)
BEGIN

SELECT Id, VendorId, ScriptUrl, UrlParameters, ExecutionErrorTracker FROM video_ad_third_party_om_verifications WHERE VideoAdId = inVideoAdId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoCompanionAdsGetByAdId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoCompanionAdsGetByAdId`(IN inVideoAdId INT)
BEGIN

SELECT Id VideoCompanionAdId FROM ads WHERE ParentId = inVideoAdId AND IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoDeliveryMethodGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoDeliveryMethodGetAll`()
BEGIN

SELECT Id, Code FROM video_delivery_methods;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoInstreamPositionGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoInstreamPositionGetAll`()
BEGIN

SELECT Id, Code FROM video_instream_positions;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoPlacementTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoPlacementTypeGetAll`()
BEGIN

SELECT Id, Code FROM video_placement_types;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoPlaybackMethodGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoPlaybackMethodGetAll`()
BEGIN

SELECT Id, Code FROM video_playback_methods;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoSkippableAdOptionGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoSkippableAdOptionGetAll`()
BEGIN

SELECT Id, Code FROM video_skippable_ad_options;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoTrackingEventGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoTrackingEventGetAll`()
BEGIN

SELECT Id, Code, ConversionName FROM video_ad_tracking_events;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VideoTypeGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `VideoTypeGetAll`()
BEGIN

SELECT Id, Code FROM video_types;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ViewabilityVendorCreativePluginsGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ViewabilityVendorCreativePluginsGet`(IN inViewabilityVendorId INT)
BEGIN

SELECT CreativeFormatId, SdkPlugin, NonSdkPlugin FROM viewability_vendor_creative_plugins WHERE ViewabilityVendorId = inViewabilityVendorId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ViewabilityVendorGetAll` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`adminuser`@`172.22.%` PROCEDURE `ViewabilityVendorGetAll`()
BEGIN

SELECT V.Id, M.Code 
FROM viewability_vendors V
INNER JOIN metric_vendors M ON V.Id = M.Id
WHERE M.IsDeleted = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-07  8:29:11
