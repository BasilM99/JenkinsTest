-- MariaDB dump 10.17  Distrib 10.5.5-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: adfalcon_report
-- ------------------------------------------------------
-- Server version	10.5.5-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qb_bridge_dimension_column`
--

DROP TABLE IF EXISTS `qb_bridge_dimension_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_dimension_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dimensionId` int(11) NOT NULL,
  `columnId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bridge_dimensions_d_idx` (`dimensionId`),
  KEY `bridge_column_c_idx` (`columnId`),
  CONSTRAINT `bridge_column_c` FOREIGN KEY (`columnId`) REFERENCES `qb_columns` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_dimension_c` FOREIGN KEY (`dimensionId`) REFERENCES `qb_dimensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_column`
--

DROP TABLE IF EXISTS `qb_bridge_fact_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factid` int(11) DEFAULT NULL,
  `colid` int(11) DEFAULT NULL,
  `isdeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=350 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_dimension`
--

DROP TABLE IF EXISTS `qb_bridge_fact_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_dimension` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factId` int(11) NOT NULL,
  `dimId` int(11) NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `fact_dim_idx` (`factId`),
  KEY `dim_fact_idx` (`dimId`),
  CONSTRAINT `bridge_dim_d` FOREIGN KEY (`dimId`) REFERENCES `qb_dimensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_fact_d` FOREIGN KEY (`factId`) REFERENCES `qb_facts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_bridge_fact_measure`
--

DROP TABLE IF EXISTS `qb_bridge_fact_measure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_bridge_fact_measure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factId` int(11) NOT NULL,
  `measurId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bridge_fact_idx` (`factId`),
  KEY `bridge_measure_idx` (`measurId`),
  CONSTRAINT `bridge_fact_m` FOREIGN KEY (`factId`) REFERENCES `qb_facts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `bridge_measure_m` FOREIGN KEY (`measurId`) REFERENCES `qb_measures` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_columns`
--

DROP TABLE IF EXISTS `qb_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `attribute` varchar(250) DEFAULT NULL,
  `dataType` int(11) DEFAULT 0,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `tableName` varchar(250) DEFAULT NULL,
  `fkSelector` varchar(250) DEFAULT NULL,
  `isSql` bit(1) NOT NULL DEFAULT b'1',
  `parentId` int(11) DEFAULT NULL,
  `orderNumber` int(11) NOT NULL DEFAULT 0,
  `isHidden` bit(1) DEFAULT b'0',
  `isDuplicated` bit(1) DEFAULT b'0',
  `alias` varchar(45) DEFAULT NULL,
  `homeIdSelector` varchar(45) DEFAULT 'id',
  `displayName` varchar(250) DEFAULT NULL,
  `source` varchar(250) DEFAULT NULL,
  `formatSQL` varchar(250) DEFAULT NULL,
  `NameId` int(11) NOT NULL,
  `supportedbypublisher` bit(1) DEFAULT b'0',
  `minWidth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qb_columns_localizedstringids` (`NameId`),
  CONSTRAINT `qb_columns_localizedstringids` FOREIGN KEY (`NameId`) REFERENCES `adfalcon`.`localizedstringids` (`LocalizedStringId`)
) ENGINE=InnoDB AUTO_INCREMENT=29024 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_dimensions`
--

DROP TABLE IF EXISTS `qb_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_dimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `source` varchar(500) NOT NULL,
  `isSql` bit(1) NOT NULL DEFAULT b'1',
  `attributes` varchar(250) DEFAULT NULL,
  `filterCol` varchar(250) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `tableName` varchar(250) DEFAULT NULL,
  `selector` varchar(250) DEFAULT NULL,
  `customget` varchar(250) DEFAULT NULL,
  `isenum` bit(1) DEFAULT b'0',
  `isgrouped` bit(1) DEFAULT b'0',
  `isscoped` bit(1) DEFAULT b'0',
  `scopetablename` varchar(250) DEFAULT NULL,
  `dimensiontype` int(11) DEFAULT 0,
  `dimensiontypestr` varchar(250) DEFAULT NULL,
  `NameId` int(11) NOT NULL,
  `supportedbypublisher` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`,`isDeleted`),
  KEY `qb_dimensions_localizedstringids` (`NameId`),
  CONSTRAINT `qb_dimensions_localizedstringids` FOREIGN KEY (`NameId`) REFERENCES `adfalcon`.`localizedstringids` (`LocalizedStringId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_facts`
--

DROP TABLE IF EXISTS `qb_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_facts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `displayname` varchar(250) NOT NULL,
  `webdisplayname` varchar(250) NOT NULL,
  `isforweb` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qb_measures`
--

DROP TABLE IF EXISTS `qb_measures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qb_measures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `attribute` varchar(250) DEFAULT NULL,
  `substituteattribute` varchar(250) DEFAULT NULL,
  `rawattribute` varchar(250) DEFAULT NULL,
  `dataType` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `orderNumber` int(11) NOT NULL DEFAULT 0,
  `isHidden` bit(1) DEFAULT b'1',
  `displayName` varchar(250) DEFAULT NULL,
  `requestsmapping` varchar(250) DEFAULT NULL,
  `dealsrequestsmapping` varchar(250) DEFAULT NULL,
  `NameId` int(11) NOT NULL,
  `supportedbyadvertiser` bit(1) DEFAULT b'1',
  `supportedbypublisher` bit(1) DEFAULT b'0',
  `minWidth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qb_measures_localizedstringids` (`NameId`),
  CONSTRAINT `qb_measures_localizedstringids` FOREIGN KEY (`NameId`) REFERENCES `adfalcon`.`localizedstringids` (`LocalizedStringId`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-07  8:25:51
