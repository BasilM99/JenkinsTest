-- MariaDB dump 10.17  Distrib 10.5.5-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: adfalcon_dsp
-- ------------------------------------------------------
-- Server version	10.5.5-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adfalcon_appsite_adserver_settings_extensions`
--

DROP TABLE IF EXISTS `adfalcon_appsite_adserver_settings_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adfalcon_appsite_adserver_settings_extensions` (
  `AppSiteId` int(11) NOT NULL,
  `WatchFillRate` bit(1) NOT NULL DEFAULT b'0',
  `MinAllowedTrafficRate` double DEFAULT NULL,
  `AcceptedFillRate` double DEFAULT NULL,
  PRIMARY KEY (`AppSiteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_deals`
--

DROP TABLE IF EXISTS `dsp_deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_deals` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `DealId` varchar(50) NOT NULL,
  `AdFalconCampaignId` int(11) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `DeletedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `dsp_deals_adfalcon_campaigns_fk_idx` (`AdFalconCampaignId`),
  CONSTRAINT `dsp_deals_adfalcon_campaigns_fk` FOREIGN KEY (`AdFalconCampaignId`) REFERENCES `adfalcon`.`campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13336 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_site_floor_price_config`
--

DROP TABLE IF EXISTS `dsp_site_floor_price_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_site_floor_price_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SiteId` int(11) NOT NULL,
  `ZoneId` int(11) DEFAULT NULL,
  `TypeId` tinyint(4) NOT NULL,
  `TargetingId` int(11) DEFAULT NULL,
  `Value` decimal(21,12) NOT NULL DEFAULT 0.000000000000,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `dp_sites_mapping_dp_sites_fk_idx` (`SiteId`),
  KEY `dp_sites_mapping_dp_zones_fk_idx` (`ZoneId`),
  CONSTRAINT `dsp_site_floor_price_config_dsp_sites_fk` FOREIGN KEY (`SiteId`) REFERENCES `dsp_sites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_site_floor_price_config_dsp_zones_fk` FOREIGN KEY (`ZoneId`) REFERENCES `dsp_site_zones` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_site_zones`
--

DROP TABLE IF EXISTS `dsp_site_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_site_zones` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SiteId` int(11) NOT NULL,
  `DSPZoneId` varchar(50) NOT NULL,
  `DSPZoneName` varchar(100) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `zones_sites_fk_idx` (`SiteId`),
  CONSTRAINT `dsp_zones_dsp_sites_fk` FOREIGN KEY (`SiteId`) REFERENCES `dsp_sites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_sites`
--

DROP TABLE IF EXISTS `dsp_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_sites` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `DSPSiteId` varchar(50) NOT NULL,
  `DSPSiteName` varchar(100) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5962 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_sites_mapping`
--

DROP TABLE IF EXISTS `dsp_sites_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_sites_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SiteId` int(11) NOT NULL,
  `ZoneId` int(11) NOT NULL,
  `AdFalconCampaignId` int(11) DEFAULT NULL,
  `AdFalconAdGroupId` int(11) DEFAULT NULL,
  `AdFalconAppSiteId` int(11) DEFAULT NULL,
  `AdFalconSubAppSiteId` int(11) DEFAULT NULL,
  `DeviceTypeId` int(11) DEFAULT NULL,
  `AdTypeId` int(11) DEFAULT NULL,
  `IsInterstitial` bit(1) DEFAULT NULL,
  `PMPDealIds` varchar(500) DEFAULT NULL,
  `Sequence` int(11) NOT NULL DEFAULT 1000,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  `DeletedOn` datetime DEFAULT NULL,
  `ModifiedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Id`),
  KEY `dp_site_mapping_adfalcon_appsites_fk_idx` (`AdFalconAppSiteId`),
  KEY `dp_site_mapping_dp_sites_fk_idx` (`SiteId`),
  KEY `dp_site_mapping_dp_zones_fk_idx` (`ZoneId`),
  KEY `dp_sites_mapping_device_types_fk_idx` (`DeviceTypeId`),
  KEY `dp_sites_mapping_ad_types_fk_idx` (`AdTypeId`),
  KEY `dsp_sites_mapping_sub_appsites_fk_idx` (`AdFalconSubAppSiteId`),
  KEY `IX_UNIQUE` (`AdFalconAppSiteId`,`AdFalconSubAppSiteId`,`DeviceTypeId`,`AdTypeId`,`IsInterstitial`),
  KEY `dsp_sites_mapping_adfalcon_campaigns_fk_idx` (`AdFalconCampaignId`),
  KEY `dsp_sites_mapping_adfalcon_adgroups_fk_idx` (`AdFalconAdGroupId`),
  CONSTRAINT `dsp_sites_mapping_ad_types_fk` FOREIGN KEY (`AdTypeId`) REFERENCES `adfalcon`.`adtypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_adfalcon_adgroups_fk` FOREIGN KEY (`AdFalconAdGroupId`) REFERENCES `adfalcon`.`adgroups` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_adfalcon_appsites_fk` FOREIGN KEY (`AdFalconAppSiteId`) REFERENCES `adfalcon`.`appsite` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_adfalcon_campaigns_fk` FOREIGN KEY (`AdFalconCampaignId`) REFERENCES `adfalcon`.`campaigns` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_device_types_fk` FOREIGN KEY (`DeviceTypeId`) REFERENCES `adfalcon`.`devicetypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_dsp_sites_fk` FOREIGN KEY (`SiteId`) REFERENCES `dsp_sites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_dsp_zones_fk` FOREIGN KEY (`ZoneId`) REFERENCES `dsp_site_zones` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dsp_sites_mapping_sub_appsites_fk` FOREIGN KEY (`AdFalconSubAppSiteId`) REFERENCES `adfalcon`.`sub_appsites` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=91627 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dsp_sizes`
--

DROP TABLE IF EXISTS `dsp_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dsp_sizes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerId` int(11) NOT NULL,
  `SizeId` varchar(50) NOT NULL,
  `Width` int(11) NOT NULL,
  `Height` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UNIQUE` (`PartnerId`,`SizeId`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `targeting_rule_geofencing`
--

DROP TABLE IF EXISTS `targeting_rule_geofencing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_rule_geofencing` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TargetingRuleId` int(11) NOT NULL,
  `Latitude` decimal(20,18) NOT NULL,
  `Longitude` decimal(20,18) NOT NULL,
  `Radius` decimal(14,7) NOT NULL,
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`),
  KEY `targeting_rules__targeting_rule_geofencing_fk_idx` (`TargetingRuleId`),
  CONSTRAINT `targeting_rules__targeting_rule_geofencing_fk` FOREIGN KEY (`TargetingRuleId`) REFERENCES `targeting_rules` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `targeting_rules`
--

DROP TABLE IF EXISTS `targeting_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_rules` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `CustomParameterName` varchar(50) NOT NULL,
  `CustomParameterAddedValues` varchar(1000) NOT NULL,
  `IsActive` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Name_UNIQUE` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-07  8:25:47
